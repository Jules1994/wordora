function Yt(A) {
  return A && A.__esModule && Object.prototype.hasOwnProperty.call(A, "default") ? A.default : A;
}
var _r = { exports: {} }, Ze = {}, br = { exports: {} }, m = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var yt;
function Bt() {
  if (yt) return m;
  yt = 1;
  var A = Symbol.for("react.element"), v = Symbol.for("react.portal"), Ce = Symbol.for("react.fragment"), X = Symbol.for("react.strict_mode"), pe = Symbol.for("react.profiler"), ne = Symbol.for("react.provider"), ae = Symbol.for("react.context"), Q = Symbol.for("react.forward_ref"), L = Symbol.for("react.suspense"), ee = Symbol.for("react.memo"), M = Symbol.for("react.lazy"), U = Symbol.iterator;
  function re(n) {
    return n === null || typeof n != "object" ? null : (n = U && n[U] || n["@@iterator"], typeof n == "function" ? n : null);
  }
  var G = { isMounted: function() {
    return !1;
  }, enqueueForceUpdate: function() {
  }, enqueueReplaceState: function() {
  }, enqueueSetState: function() {
  } }, ce = Object.assign, $e = {};
  function oe(n, i, g) {
    this.props = n, this.context = i, this.refs = $e, this.updater = g || G;
  }
  oe.prototype.isReactComponent = {}, oe.prototype.setState = function(n, i) {
    if (typeof n != "object" && typeof n != "function" && n != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, n, i, "setState");
  }, oe.prototype.forceUpdate = function(n) {
    this.updater.enqueueForceUpdate(this, n, "forceUpdate");
  };
  function ue() {
  }
  ue.prototype = oe.prototype;
  function D(n, i, g) {
    this.props = n, this.context = i, this.refs = $e, this.updater = g || G;
  }
  var ge = D.prototype = new ue();
  ge.constructor = D, ce(ge, oe.prototype), ge.isPureReactComponent = !0;
  var ie = Array.isArray, N = Object.prototype.hasOwnProperty, K = { current: null }, le = { key: !0, ref: !0, __self: !0, __source: !0 };
  function ve(n, i, g) {
    var b, E = {}, k = null, O = null;
    if (i != null) for (b in i.ref !== void 0 && (O = i.ref), i.key !== void 0 && (k = "" + i.key), i) N.call(i, b) && !le.hasOwnProperty(b) && (E[b] = i[b]);
    var T = arguments.length - 2;
    if (T === 1) E.children = g;
    else if (1 < T) {
      for (var C = Array(T), V = 0; V < T; V++) C[V] = arguments[V + 2];
      E.children = C;
    }
    if (n && n.defaultProps) for (b in T = n.defaultProps, T) E[b] === void 0 && (E[b] = T[b]);
    return { $$typeof: A, type: n, key: k, ref: O, props: E, _owner: K.current };
  }
  function Se(n, i) {
    return { $$typeof: A, type: n.type, key: i, ref: n.ref, props: n.props, _owner: n._owner };
  }
  function Te(n) {
    return typeof n == "object" && n !== null && n.$$typeof === A;
  }
  function Be(n) {
    var i = { "=": "=0", ":": "=2" };
    return "$" + n.replace(/[=:]/g, function(g) {
      return i[g];
    });
  }
  var Oe = /\/+/g;
  function q(n, i) {
    return typeof n == "object" && n !== null && n.key != null ? Be("" + n.key) : i.toString(36);
  }
  function Z(n, i, g, b, E) {
    var k = typeof n;
    (k === "undefined" || k === "boolean") && (n = null);
    var O = !1;
    if (n === null) O = !0;
    else switch (k) {
      case "string":
      case "number":
        O = !0;
        break;
      case "object":
        switch (n.$$typeof) {
          case A:
          case v:
            O = !0;
        }
    }
    if (O) return O = n, E = E(O), n = b === "" ? "." + q(O, 0) : b, ie(E) ? (g = "", n != null && (g = n.replace(Oe, "$&/") + "/"), Z(E, i, g, "", function(V) {
      return V;
    })) : E != null && (Te(E) && (E = Se(E, g + (!E.key || O && O.key === E.key ? "" : ("" + E.key).replace(Oe, "$&/") + "/") + n)), i.push(E)), 1;
    if (O = 0, b = b === "" ? "." : b + ":", ie(n)) for (var T = 0; T < n.length; T++) {
      k = n[T];
      var C = b + q(k, T);
      O += Z(k, i, g, C, E);
    }
    else if (C = re(n), typeof C == "function") for (n = C.call(n), T = 0; !(k = n.next()).done; ) k = k.value, C = b + q(k, T++), O += Z(k, i, g, C, E);
    else if (k === "object") throw i = String(n), Error("Objects are not valid as a React child (found: " + (i === "[object Object]" ? "object with keys {" + Object.keys(n).join(", ") + "}" : i) + "). If you meant to render a collection of children, use an array instead.");
    return O;
  }
  function Y(n, i, g) {
    if (n == null) return n;
    var b = [], E = 0;
    return Z(n, b, "", "", function(k) {
      return i.call(g, k, E++);
    }), b;
  }
  function se(n) {
    if (n._status === -1) {
      var i = n._result;
      i = i(), i.then(function(g) {
        (n._status === 0 || n._status === -1) && (n._status = 1, n._result = g);
      }, function(g) {
        (n._status === 0 || n._status === -1) && (n._status = 2, n._result = g);
      }), n._status === -1 && (n._status = 0, n._result = i);
    }
    if (n._status === 1) return n._result.default;
    throw n._result;
  }
  var f = { current: null }, fe = { transition: null }, Pe = { ReactCurrentDispatcher: f, ReactCurrentBatchConfig: fe, ReactCurrentOwner: K };
  function ye() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return m.Children = { map: Y, forEach: function(n, i, g) {
    Y(n, function() {
      i.apply(this, arguments);
    }, g);
  }, count: function(n) {
    var i = 0;
    return Y(n, function() {
      i++;
    }), i;
  }, toArray: function(n) {
    return Y(n, function(i) {
      return i;
    }) || [];
  }, only: function(n) {
    if (!Te(n)) throw Error("React.Children.only expected to receive a single React element child.");
    return n;
  } }, m.Component = oe, m.Fragment = Ce, m.Profiler = pe, m.PureComponent = D, m.StrictMode = X, m.Suspense = L, m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Pe, m.act = ye, m.cloneElement = function(n, i, g) {
    if (n == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + n + ".");
    var b = ce({}, n.props), E = n.key, k = n.ref, O = n._owner;
    if (i != null) {
      if (i.ref !== void 0 && (k = i.ref, O = K.current), i.key !== void 0 && (E = "" + i.key), n.type && n.type.defaultProps) var T = n.type.defaultProps;
      for (C in i) N.call(i, C) && !le.hasOwnProperty(C) && (b[C] = i[C] === void 0 && T !== void 0 ? T[C] : i[C]);
    }
    var C = arguments.length - 2;
    if (C === 1) b.children = g;
    else if (1 < C) {
      T = Array(C);
      for (var V = 0; V < C; V++) T[V] = arguments[V + 2];
      b.children = T;
    }
    return { $$typeof: A, type: n.type, key: E, ref: k, props: b, _owner: O };
  }, m.createContext = function(n) {
    return n = { $$typeof: ae, _currentValue: n, _currentValue2: n, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, n.Provider = { $$typeof: ne, _context: n }, n.Consumer = n;
  }, m.createElement = ve, m.createFactory = function(n) {
    var i = ve.bind(null, n);
    return i.type = n, i;
  }, m.createRef = function() {
    return { current: null };
  }, m.forwardRef = function(n) {
    return { $$typeof: Q, render: n };
  }, m.isValidElement = Te, m.lazy = function(n) {
    return { $$typeof: M, _payload: { _status: -1, _result: n }, _init: se };
  }, m.memo = function(n, i) {
    return { $$typeof: ee, type: n, compare: i === void 0 ? null : i };
  }, m.startTransition = function(n) {
    var i = fe.transition;
    fe.transition = {};
    try {
      n();
    } finally {
      fe.transition = i;
    }
  }, m.unstable_act = ye, m.useCallback = function(n, i) {
    return f.current.useCallback(n, i);
  }, m.useContext = function(n) {
    return f.current.useContext(n);
  }, m.useDebugValue = function() {
  }, m.useDeferredValue = function(n) {
    return f.current.useDeferredValue(n);
  }, m.useEffect = function(n, i) {
    return f.current.useEffect(n, i);
  }, m.useId = function() {
    return f.current.useId();
  }, m.useImperativeHandle = function(n, i, g) {
    return f.current.useImperativeHandle(n, i, g);
  }, m.useInsertionEffect = function(n, i) {
    return f.current.useInsertionEffect(n, i);
  }, m.useLayoutEffect = function(n, i) {
    return f.current.useLayoutEffect(n, i);
  }, m.useMemo = function(n, i) {
    return f.current.useMemo(n, i);
  }, m.useReducer = function(n, i, g) {
    return f.current.useReducer(n, i, g);
  }, m.useRef = function(n) {
    return f.current.useRef(n);
  }, m.useState = function(n) {
    return f.current.useState(n);
  }, m.useSyncExternalStore = function(n, i, g) {
    return f.current.useSyncExternalStore(n, i, g);
  }, m.useTransition = function() {
    return f.current.useTransition();
  }, m.version = "18.3.1", m;
}
var Xe = { exports: {} };
/**
 * @license React
 * react.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
Xe.exports;
var ht;
function zt() {
  return ht || (ht = 1, function(A, v) {
    process.env.NODE_ENV !== "production" && function() {
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
      var Ce = "18.3.1", X = Symbol.for("react.element"), pe = Symbol.for("react.portal"), ne = Symbol.for("react.fragment"), ae = Symbol.for("react.strict_mode"), Q = Symbol.for("react.profiler"), L = Symbol.for("react.provider"), ee = Symbol.for("react.context"), M = Symbol.for("react.forward_ref"), U = Symbol.for("react.suspense"), re = Symbol.for("react.suspense_list"), G = Symbol.for("react.memo"), ce = Symbol.for("react.lazy"), $e = Symbol.for("react.offscreen"), oe = Symbol.iterator, ue = "@@iterator";
      function D(e) {
        if (e === null || typeof e != "object")
          return null;
        var r = oe && e[oe] || e[ue];
        return typeof r == "function" ? r : null;
      }
      var ge = {
        /**
         * @internal
         * @type {ReactComponent}
         */
        current: null
      }, ie = {
        transition: null
      }, N = {
        current: null,
        // Used to reproduce behavior of `batchedUpdates` in legacy mode.
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1
      }, K = {
        /**
         * @internal
         * @type {ReactComponent}
         */
        current: null
      }, le = {}, ve = null;
      function Se(e) {
        ve = e;
      }
      le.setExtraStackFrame = function(e) {
        ve = e;
      }, le.getCurrentStack = null, le.getStackAddendum = function() {
        var e = "";
        ve && (e += ve);
        var r = le.getCurrentStack;
        return r && (e += r() || ""), e;
      };
      var Te = !1, Be = !1, Oe = !1, q = !1, Z = !1, Y = {
        ReactCurrentDispatcher: ge,
        ReactCurrentBatchConfig: ie,
        ReactCurrentOwner: K
      };
      Y.ReactDebugCurrentFrame = le, Y.ReactCurrentActQueue = N;
      function se(e) {
        {
          for (var r = arguments.length, a = new Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++)
            a[o - 1] = arguments[o];
          fe("warn", e, a);
        }
      }
      function f(e) {
        {
          for (var r = arguments.length, a = new Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++)
            a[o - 1] = arguments[o];
          fe("error", e, a);
        }
      }
      function fe(e, r, a) {
        {
          var o = Y.ReactDebugCurrentFrame, c = o.getStackAddendum();
          c !== "" && (r += "%s", a = a.concat([c]));
          var d = a.map(function(l) {
            return String(l);
          });
          d.unshift("Warning: " + r), Function.prototype.apply.call(console[e], console, d);
        }
      }
      var Pe = {};
      function ye(e, r) {
        {
          var a = e.constructor, o = a && (a.displayName || a.name) || "ReactClass", c = o + "." + r;
          if (Pe[c])
            return;
          f("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", r, o), Pe[c] = !0;
        }
      }
      var n = {
        /**
         * Checks whether or not this composite component is mounted.
         * @param {ReactClass} publicInstance The instance we want to test.
         * @return {boolean} True if mounted, false otherwise.
         * @protected
         * @final
         */
        isMounted: function(e) {
          return !1;
        },
        /**
         * Forces an update. This should only be invoked when it is known with
         * certainty that we are **not** in a DOM transaction.
         *
         * You may want to call this when you know that some deeper aspect of the
         * component's state has changed but `setState` was not called.
         *
         * This will not invoke `shouldComponentUpdate`, but it will invoke
         * `componentWillUpdate` and `componentDidUpdate`.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {?function} callback Called after component is updated.
         * @param {?string} callerName name of the calling function in the public API.
         * @internal
         */
        enqueueForceUpdate: function(e, r, a) {
          ye(e, "forceUpdate");
        },
        /**
         * Replaces all of the state. Always use this or `setState` to mutate state.
         * You should treat `this.state` as immutable.
         *
         * There is no guarantee that `this.state` will be immediately updated, so
         * accessing `this.state` after calling this method may return the old value.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {object} completeState Next state.
         * @param {?function} callback Called after component is updated.
         * @param {?string} callerName name of the calling function in the public API.
         * @internal
         */
        enqueueReplaceState: function(e, r, a, o) {
          ye(e, "replaceState");
        },
        /**
         * Sets a subset of the state. This only exists because _pendingState is
         * internal. This provides a merging strategy that is not available to deep
         * properties which is confusing. TODO: Expose pendingState or don't use it
         * during the merge.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {object} partialState Next partial state to be merged with state.
         * @param {?function} callback Called after component is updated.
         * @param {?string} Name of the calling function in the public API.
         * @internal
         */
        enqueueSetState: function(e, r, a, o) {
          ye(e, "setState");
        }
      }, i = Object.assign, g = {};
      Object.freeze(g);
      function b(e, r, a) {
        this.props = e, this.context = r, this.refs = g, this.updater = a || n;
      }
      b.prototype.isReactComponent = {}, b.prototype.setState = function(e, r) {
        if (typeof e != "object" && typeof e != "function" && e != null)
          throw new Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, e, r, "setState");
      }, b.prototype.forceUpdate = function(e) {
        this.updater.enqueueForceUpdate(this, e, "forceUpdate");
      };
      {
        var E = {
          isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
          replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
        }, k = function(e, r) {
          Object.defineProperty(b.prototype, e, {
            get: function() {
              se("%s(...) is deprecated in plain JavaScript React classes. %s", r[0], r[1]);
            }
          });
        };
        for (var O in E)
          E.hasOwnProperty(O) && k(O, E[O]);
      }
      function T() {
      }
      T.prototype = b.prototype;
      function C(e, r, a) {
        this.props = e, this.context = r, this.refs = g, this.updater = a || n;
      }
      var V = C.prototype = new T();
      V.constructor = C, i(V, b.prototype), V.isPureReactComponent = !0;
      function Rr() {
        var e = {
          current: null
        };
        return Object.seal(e), e;
      }
      var Qe = Array.isArray;
      function Le(e) {
        return Qe(e);
      }
      function Er(e) {
        {
          var r = typeof Symbol == "function" && Symbol.toStringTag, a = r && e[Symbol.toStringTag] || e.constructor.name || "Object";
          return a;
        }
      }
      function Me(e) {
        try {
          return _e(e), !1;
        } catch {
          return !0;
        }
      }
      function _e(e) {
        return "" + e;
      }
      function ke(e) {
        if (Me(e))
          return f("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", Er(e)), _e(e);
      }
      function er(e, r, a) {
        var o = e.displayName;
        if (o)
          return o;
        var c = r.displayName || r.name || "";
        return c !== "" ? a + "(" + c + ")" : a;
      }
      function je(e) {
        return e.displayName || "Context";
      }
      function de(e) {
        if (e == null)
          return null;
        if (typeof e.tag == "number" && f("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof e == "function")
          return e.displayName || e.name || null;
        if (typeof e == "string")
          return e;
        switch (e) {
          case ne:
            return "Fragment";
          case pe:
            return "Portal";
          case Q:
            return "Profiler";
          case ae:
            return "StrictMode";
          case U:
            return "Suspense";
          case re:
            return "SuspenseList";
        }
        if (typeof e == "object")
          switch (e.$$typeof) {
            case ee:
              var r = e;
              return je(r) + ".Consumer";
            case L:
              var a = e;
              return je(a._context) + ".Provider";
            case M:
              return er(e, e.render, "ForwardRef");
            case G:
              var o = e.displayName || null;
              return o !== null ? o : de(e.type) || "Memo";
            case ce: {
              var c = e, d = c._payload, l = c._init;
              try {
                return de(l(d));
              } catch {
                return null;
              }
            }
          }
        return null;
      }
      var xe = Object.prototype.hasOwnProperty, Ne = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
      }, rr, tr, Ve;
      Ve = {};
      function ze(e) {
        if (xe.call(e, "ref")) {
          var r = Object.getOwnPropertyDescriptor(e, "ref").get;
          if (r && r.isReactWarning)
            return !1;
        }
        return e.ref !== void 0;
      }
      function be(e) {
        if (xe.call(e, "key")) {
          var r = Object.getOwnPropertyDescriptor(e, "key").get;
          if (r && r.isReactWarning)
            return !1;
        }
        return e.key !== void 0;
      }
      function wr(e, r) {
        var a = function() {
          rr || (rr = !0, f("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", r));
        };
        a.isReactWarning = !0, Object.defineProperty(e, "key", {
          get: a,
          configurable: !0
        });
      }
      function nr(e, r) {
        var a = function() {
          tr || (tr = !0, f("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", r));
        };
        a.isReactWarning = !0, Object.defineProperty(e, "ref", {
          get: a,
          configurable: !0
        });
      }
      function ar(e) {
        if (typeof e.ref == "string" && K.current && e.__self && K.current.stateNode !== e.__self) {
          var r = de(K.current.type);
          Ve[r] || (f('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', r, e.ref), Ve[r] = !0);
        }
      }
      var Ae = function(e, r, a, o, c, d, l) {
        var y = {
          // This tag allows us to uniquely identify this as a React Element
          $$typeof: X,
          // Built-in properties that belong on the element
          type: e,
          key: r,
          ref: a,
          props: l,
          // Record the component responsible for creating this element.
          _owner: d
        };
        return y._store = {}, Object.defineProperty(y._store, "validated", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: !1
        }), Object.defineProperty(y, "_self", {
          configurable: !1,
          enumerable: !1,
          writable: !1,
          value: o
        }), Object.defineProperty(y, "_source", {
          configurable: !1,
          enumerable: !1,
          writable: !1,
          value: c
        }), Object.freeze && (Object.freeze(y.props), Object.freeze(y)), y;
      };
      function Cr(e, r, a) {
        var o, c = {}, d = null, l = null, y = null, R = null;
        if (r != null) {
          ze(r) && (l = r.ref, ar(r)), be(r) && (ke(r.key), d = "" + r.key), y = r.__self === void 0 ? null : r.__self, R = r.__source === void 0 ? null : r.__source;
          for (o in r)
            xe.call(r, o) && !Ne.hasOwnProperty(o) && (c[o] = r[o]);
        }
        var P = arguments.length - 2;
        if (P === 1)
          c.children = a;
        else if (P > 1) {
          for (var j = Array(P), x = 0; x < P; x++)
            j[x] = arguments[x + 2];
          Object.freeze && Object.freeze(j), c.children = j;
        }
        if (e && e.defaultProps) {
          var I = e.defaultProps;
          for (o in I)
            c[o] === void 0 && (c[o] = I[o]);
        }
        if (d || l) {
          var W = typeof e == "function" ? e.displayName || e.name || "Unknown" : e;
          d && wr(c, W), l && nr(c, W);
        }
        return Ae(e, d, l, y, R, K.current, c);
      }
      function Sr(e, r) {
        var a = Ae(e.type, r, e.ref, e._self, e._source, e._owner, e.props);
        return a;
      }
      function Tr(e, r, a) {
        if (e == null)
          throw new Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
        var o, c = i({}, e.props), d = e.key, l = e.ref, y = e._self, R = e._source, P = e._owner;
        if (r != null) {
          ze(r) && (l = r.ref, P = K.current), be(r) && (ke(r.key), d = "" + r.key);
          var j;
          e.type && e.type.defaultProps && (j = e.type.defaultProps);
          for (o in r)
            xe.call(r, o) && !Ne.hasOwnProperty(o) && (r[o] === void 0 && j !== void 0 ? c[o] = j[o] : c[o] = r[o]);
        }
        var x = arguments.length - 2;
        if (x === 1)
          c.children = a;
        else if (x > 1) {
          for (var I = Array(x), W = 0; W < x; W++)
            I[W] = arguments[W + 2];
          c.children = I;
        }
        return Ae(e.type, d, l, y, R, P, c);
      }
      function Re(e) {
        return typeof e == "object" && e !== null && e.$$typeof === X;
      }
      var or = ".", Or = ":";
      function Pr(e) {
        var r = /[=:]/g, a = {
          "=": "=0",
          ":": "=2"
        }, o = e.replace(r, function(c) {
          return a[c];
        });
        return "$" + o;
      }
      var We = !1, ur = /\/+/g;
      function he(e) {
        return e.replace(ur, "$&/");
      }
      function De(e, r) {
        return typeof e == "object" && e !== null && e.key != null ? (ke(e.key), Pr("" + e.key)) : r.toString(36);
      }
      function Ee(e, r, a, o, c) {
        var d = typeof e;
        (d === "undefined" || d === "boolean") && (e = null);
        var l = !1;
        if (e === null)
          l = !0;
        else
          switch (d) {
            case "string":
            case "number":
              l = !0;
              break;
            case "object":
              switch (e.$$typeof) {
                case X:
                case pe:
                  l = !0;
              }
          }
        if (l) {
          var y = e, R = c(y), P = o === "" ? or + De(y, 0) : o;
          if (Le(R)) {
            var j = "";
            P != null && (j = he(P) + "/"), Ee(R, r, j, "", function(Ut) {
              return Ut;
            });
          } else R != null && (Re(R) && (R.key && (!y || y.key !== R.key) && ke(R.key), R = Sr(
            R,
            // Keep both the (mapped) and old keys if they differ, just as
            // traverseAllChildren used to do for objects as children
            a + // $FlowFixMe Flow incorrectly thinks React.Portal doesn't have a key
            (R.key && (!y || y.key !== R.key) ? (
              // $FlowFixMe Flow incorrectly thinks existing element's key can be a number
              // eslint-disable-next-line react-internal/safe-string-coercion
              he("" + R.key) + "/"
            ) : "") + P
          )), r.push(R));
          return 1;
        }
        var x, I, W = 0, z = o === "" ? or : o + Or;
        if (Le(e))
          for (var gr = 0; gr < e.length; gr++)
            x = e[gr], I = z + De(x, gr), W += Ee(x, r, a, I, c);
        else {
          var Yr = D(e);
          if (typeof Yr == "function") {
            var dt = e;
            Yr === dt.entries && (We || se("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), We = !0);
            for (var Vt = Yr.call(dt), pt, Wt = 0; !(pt = Vt.next()).done; )
              x = pt.value, I = z + De(x, Wt++), W += Ee(x, r, a, I, c);
          } else if (d === "object") {
            var vt = String(e);
            throw new Error("Objects are not valid as a React child (found: " + (vt === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : vt) + "). If you meant to render a collection of children, use an array instead.");
          }
        }
        return W;
      }
      function Fe(e, r, a) {
        if (e == null)
          return e;
        var o = [], c = 0;
        return Ee(e, o, "", "", function(d) {
          return r.call(a, d, c++);
        }), o;
      }
      function kr(e) {
        var r = 0;
        return Fe(e, function() {
          r++;
        }), r;
      }
      function ir(e, r, a) {
        Fe(e, function() {
          r.apply(this, arguments);
        }, a);
      }
      function jr(e) {
        return Fe(e, function(r) {
          return r;
        }) || [];
      }
      function sr(e) {
        if (!Re(e))
          throw new Error("React.Children.only expected to receive a single React element child.");
        return e;
      }
      function cr(e) {
        var r = {
          $$typeof: ee,
          // As a workaround to support multiple concurrent renderers, we categorize
          // some renderers as primary and others as secondary. We only expect
          // there to be two concurrent renderers at most: React Native (primary) and
          // Fabric (secondary); React DOM (primary) and React ART (secondary).
          // Secondary renderers store their context values on separate fields.
          _currentValue: e,
          _currentValue2: e,
          // Used to track how many concurrent renderers this context currently
          // supports within in a single renderer. Such as parallel server rendering.
          _threadCount: 0,
          // These are circular
          Provider: null,
          Consumer: null,
          // Add these to use same hidden class in VM as ServerContext
          _defaultValue: null,
          _globalName: null
        };
        r.Provider = {
          $$typeof: L,
          _context: r
        };
        var a = !1, o = !1, c = !1;
        {
          var d = {
            $$typeof: ee,
            _context: r
          };
          Object.defineProperties(d, {
            Provider: {
              get: function() {
                return o || (o = !0, f("Rendering <Context.Consumer.Provider> is not supported and will be removed in a future major release. Did you mean to render <Context.Provider> instead?")), r.Provider;
              },
              set: function(l) {
                r.Provider = l;
              }
            },
            _currentValue: {
              get: function() {
                return r._currentValue;
              },
              set: function(l) {
                r._currentValue = l;
              }
            },
            _currentValue2: {
              get: function() {
                return r._currentValue2;
              },
              set: function(l) {
                r._currentValue2 = l;
              }
            },
            _threadCount: {
              get: function() {
                return r._threadCount;
              },
              set: function(l) {
                r._threadCount = l;
              }
            },
            Consumer: {
              get: function() {
                return a || (a = !0, f("Rendering <Context.Consumer.Consumer> is not supported and will be removed in a future major release. Did you mean to render <Context.Consumer> instead?")), r.Consumer;
              }
            },
            displayName: {
              get: function() {
                return r.displayName;
              },
              set: function(l) {
                c || (se("Setting `displayName` on Context.Consumer has no effect. You should set it directly on the context with Context.displayName = '%s'.", l), c = !0);
              }
            }
          }), r.Consumer = d;
        }
        return r._currentRenderer = null, r._currentRenderer2 = null, r;
      }
      var Ie = -1, qe = 0, He = 1, lr = 2;
      function xr(e) {
        if (e._status === Ie) {
          var r = e._result, a = r();
          if (a.then(function(d) {
            if (e._status === qe || e._status === Ie) {
              var l = e;
              l._status = He, l._result = d;
            }
          }, function(d) {
            if (e._status === qe || e._status === Ie) {
              var l = e;
              l._status = lr, l._result = d;
            }
          }), e._status === Ie) {
            var o = e;
            o._status = qe, o._result = a;
          }
        }
        if (e._status === He) {
          var c = e._result;
          return c === void 0 && f(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`, c), "default" in c || f(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`, c), c.default;
        } else
          throw e._result;
      }
      function Ar(e) {
        var r = {
          // We use these fields to store the result.
          _status: Ie,
          _result: e
        }, a = {
          $$typeof: ce,
          _payload: r,
          _init: xr
        };
        {
          var o, c;
          Object.defineProperties(a, {
            defaultProps: {
              configurable: !0,
              get: function() {
                return o;
              },
              set: function(d) {
                f("React.lazy(...): It is not supported to assign `defaultProps` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), o = d, Object.defineProperty(a, "defaultProps", {
                  enumerable: !0
                });
              }
            },
            propTypes: {
              configurable: !0,
              get: function() {
                return c;
              },
              set: function(d) {
                f("React.lazy(...): It is not supported to assign `propTypes` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), c = d, Object.defineProperty(a, "propTypes", {
                  enumerable: !0
                });
              }
            }
          });
        }
        return a;
      }
      function Dr(e) {
        e != null && e.$$typeof === G ? f("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : typeof e != "function" ? f("forwardRef requires a render function but was given %s.", e === null ? "null" : typeof e) : e.length !== 0 && e.length !== 2 && f("forwardRef render functions accept exactly two parameters: props and ref. %s", e.length === 1 ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined."), e != null && (e.defaultProps != null || e.propTypes != null) && f("forwardRef render functions do not support propTypes or defaultProps. Did you accidentally pass a React component?");
        var r = {
          $$typeof: M,
          render: e
        };
        {
          var a;
          Object.defineProperty(r, "displayName", {
            enumerable: !1,
            configurable: !0,
            get: function() {
              return a;
            },
            set: function(o) {
              a = o, !e.name && !e.displayName && (e.displayName = o);
            }
          });
        }
        return r;
      }
      var fr;
      fr = Symbol.for("react.module.reference");
      function t(e) {
        return !!(typeof e == "string" || typeof e == "function" || e === ne || e === Q || Z || e === ae || e === U || e === re || q || e === $e || Te || Be || Oe || typeof e == "object" && e !== null && (e.$$typeof === ce || e.$$typeof === G || e.$$typeof === L || e.$$typeof === ee || e.$$typeof === M || // This needs to include all possible module reference object
        // types supported by any Flight configuration anywhere since
        // we don't know which Flight build this will end up being used
        // with.
        e.$$typeof === fr || e.getModuleId !== void 0));
      }
      function u(e, r) {
        t(e) || f("memo: The first argument must be a component. Instead received: %s", e === null ? "null" : typeof e);
        var a = {
          $$typeof: G,
          type: e,
          compare: r === void 0 ? null : r
        };
        {
          var o;
          Object.defineProperty(a, "displayName", {
            enumerable: !1,
            configurable: !0,
            get: function() {
              return o;
            },
            set: function(c) {
              o = c, !e.name && !e.displayName && (e.displayName = c);
            }
          });
        }
        return a;
      }
      function s() {
        var e = ge.current;
        return e === null && f(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.`), e;
      }
      function p(e) {
        var r = s();
        if (e._context !== void 0) {
          var a = e._context;
          a.Consumer === e ? f("Calling useContext(Context.Consumer) is not supported, may cause bugs, and will be removed in a future major release. Did you mean to call useContext(Context) instead?") : a.Provider === e && f("Calling useContext(Context.Provider) is not supported. Did you mean to call useContext(Context) instead?");
        }
        return r.useContext(e);
      }
      function w(e) {
        var r = s();
        return r.useState(e);
      }
      function S(e, r, a) {
        var o = s();
        return o.useReducer(e, r, a);
      }
      function _(e) {
        var r = s();
        return r.useRef(e);
      }
      function h(e, r) {
        var a = s();
        return a.useEffect(e, r);
      }
      function B(e, r) {
        var a = s();
        return a.useInsertionEffect(e, r);
      }
      function F(e, r) {
        var a = s();
        return a.useLayoutEffect(e, r);
      }
      function $(e, r) {
        var a = s();
        return a.useCallback(e, r);
      }
      function J(e, r) {
        var a = s();
        return a.useMemo(e, r);
      }
      function we(e, r, a) {
        var o = s();
        return o.useImperativeHandle(e, r, a);
      }
      function me(e, r) {
        {
          var a = s();
          return a.useDebugValue(e, r);
        }
      }
      function H() {
        var e = s();
        return e.useTransition();
      }
      function Ke(e) {
        var r = s();
        return r.useDeferredValue(e);
      }
      function Fr() {
        var e = s();
        return e.useId();
      }
      function Ir(e, r, a) {
        var o = s();
        return o.useSyncExternalStore(e, r, a);
      }
      var Ge = 0, zr, qr, Hr, Kr, Gr, Zr, Jr;
      function Xr() {
      }
      Xr.__reactDisabledLog = !0;
      function Et() {
        {
          if (Ge === 0) {
            zr = console.log, qr = console.info, Hr = console.warn, Kr = console.error, Gr = console.group, Zr = console.groupCollapsed, Jr = console.groupEnd;
            var e = {
              configurable: !0,
              enumerable: !0,
              value: Xr,
              writable: !0
            };
            Object.defineProperties(console, {
              info: e,
              log: e,
              warn: e,
              error: e,
              group: e,
              groupCollapsed: e,
              groupEnd: e
            });
          }
          Ge++;
        }
      }
      function wt() {
        {
          if (Ge--, Ge === 0) {
            var e = {
              configurable: !0,
              enumerable: !0,
              writable: !0
            };
            Object.defineProperties(console, {
              log: i({}, e, {
                value: zr
              }),
              info: i({}, e, {
                value: qr
              }),
              warn: i({}, e, {
                value: Hr
              }),
              error: i({}, e, {
                value: Kr
              }),
              group: i({}, e, {
                value: Gr
              }),
              groupCollapsed: i({}, e, {
                value: Zr
              }),
              groupEnd: i({}, e, {
                value: Jr
              })
            });
          }
          Ge < 0 && f("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
        }
      }
      var $r = Y.ReactCurrentDispatcher, Lr;
      function dr(e, r, a) {
        {
          if (Lr === void 0)
            try {
              throw Error();
            } catch (c) {
              var o = c.stack.trim().match(/\n( *(at )?)/);
              Lr = o && o[1] || "";
            }
          return `
` + Lr + e;
        }
      }
      var Mr = !1, pr;
      {
        var Ct = typeof WeakMap == "function" ? WeakMap : Map;
        pr = new Ct();
      }
      function Qr(e, r) {
        if (!e || Mr)
          return "";
        {
          var a = pr.get(e);
          if (a !== void 0)
            return a;
        }
        var o;
        Mr = !0;
        var c = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        var d;
        d = $r.current, $r.current = null, Et();
        try {
          if (r) {
            var l = function() {
              throw Error();
            };
            if (Object.defineProperty(l.prototype, "props", {
              set: function() {
                throw Error();
              }
            }), typeof Reflect == "object" && Reflect.construct) {
              try {
                Reflect.construct(l, []);
              } catch (z) {
                o = z;
              }
              Reflect.construct(e, [], l);
            } else {
              try {
                l.call();
              } catch (z) {
                o = z;
              }
              e.call(l.prototype);
            }
          } else {
            try {
              throw Error();
            } catch (z) {
              o = z;
            }
            e();
          }
        } catch (z) {
          if (z && o && typeof z.stack == "string") {
            for (var y = z.stack.split(`
`), R = o.stack.split(`
`), P = y.length - 1, j = R.length - 1; P >= 1 && j >= 0 && y[P] !== R[j]; )
              j--;
            for (; P >= 1 && j >= 0; P--, j--)
              if (y[P] !== R[j]) {
                if (P !== 1 || j !== 1)
                  do
                    if (P--, j--, j < 0 || y[P] !== R[j]) {
                      var x = `
` + y[P].replace(" at new ", " at ");
                      return e.displayName && x.includes("<anonymous>") && (x = x.replace("<anonymous>", e.displayName)), typeof e == "function" && pr.set(e, x), x;
                    }
                  while (P >= 1 && j >= 0);
                break;
              }
          }
        } finally {
          Mr = !1, $r.current = d, wt(), Error.prepareStackTrace = c;
        }
        var I = e ? e.displayName || e.name : "", W = I ? dr(I) : "";
        return typeof e == "function" && pr.set(e, W), W;
      }
      function St(e, r, a) {
        return Qr(e, !1);
      }
      function Tt(e) {
        var r = e.prototype;
        return !!(r && r.isReactComponent);
      }
      function vr(e, r, a) {
        if (e == null)
          return "";
        if (typeof e == "function")
          return Qr(e, Tt(e));
        if (typeof e == "string")
          return dr(e);
        switch (e) {
          case U:
            return dr("Suspense");
          case re:
            return dr("SuspenseList");
        }
        if (typeof e == "object")
          switch (e.$$typeof) {
            case M:
              return St(e.render);
            case G:
              return vr(e.type, r, a);
            case ce: {
              var o = e, c = o._payload, d = o._init;
              try {
                return vr(d(c), r, a);
              } catch {
              }
            }
          }
        return "";
      }
      var et = {}, rt = Y.ReactDebugCurrentFrame;
      function yr(e) {
        if (e) {
          var r = e._owner, a = vr(e.type, e._source, r ? r.type : null);
          rt.setExtraStackFrame(a);
        } else
          rt.setExtraStackFrame(null);
      }
      function Ot(e, r, a, o, c) {
        {
          var d = Function.call.bind(xe);
          for (var l in e)
            if (d(e, l)) {
              var y = void 0;
              try {
                if (typeof e[l] != "function") {
                  var R = Error((o || "React class") + ": " + a + " type `" + l + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof e[l] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                  throw R.name = "Invariant Violation", R;
                }
                y = e[l](r, l, o, a, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
              } catch (P) {
                y = P;
              }
              y && !(y instanceof Error) && (yr(c), f("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", o || "React class", a, l, typeof y), yr(null)), y instanceof Error && !(y.message in et) && (et[y.message] = !0, yr(c), f("Failed %s type: %s", a, y.message), yr(null));
            }
        }
      }
      function Ue(e) {
        if (e) {
          var r = e._owner, a = vr(e.type, e._source, r ? r.type : null);
          Se(a);
        } else
          Se(null);
      }
      var Nr;
      Nr = !1;
      function tt() {
        if (K.current) {
          var e = de(K.current.type);
          if (e)
            return `

Check the render method of \`` + e + "`.";
        }
        return "";
      }
      function Pt(e) {
        if (e !== void 0) {
          var r = e.fileName.replace(/^.*[\\\/]/, ""), a = e.lineNumber;
          return `

Check your code at ` + r + ":" + a + ".";
        }
        return "";
      }
      function kt(e) {
        return e != null ? Pt(e.__source) : "";
      }
      var nt = {};
      function jt(e) {
        var r = tt();
        if (!r) {
          var a = typeof e == "string" ? e : e.displayName || e.name;
          a && (r = `

Check the top-level render call using <` + a + ">.");
        }
        return r;
      }
      function at(e, r) {
        if (!(!e._store || e._store.validated || e.key != null)) {
          e._store.validated = !0;
          var a = jt(r);
          if (!nt[a]) {
            nt[a] = !0;
            var o = "";
            e && e._owner && e._owner !== K.current && (o = " It was passed a child from " + de(e._owner.type) + "."), Ue(e), f('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', a, o), Ue(null);
          }
        }
      }
      function ot(e, r) {
        if (typeof e == "object") {
          if (Le(e))
            for (var a = 0; a < e.length; a++) {
              var o = e[a];
              Re(o) && at(o, r);
            }
          else if (Re(e))
            e._store && (e._store.validated = !0);
          else if (e) {
            var c = D(e);
            if (typeof c == "function" && c !== e.entries)
              for (var d = c.call(e), l; !(l = d.next()).done; )
                Re(l.value) && at(l.value, r);
          }
        }
      }
      function ut(e) {
        {
          var r = e.type;
          if (r == null || typeof r == "string")
            return;
          var a;
          if (typeof r == "function")
            a = r.propTypes;
          else if (typeof r == "object" && (r.$$typeof === M || // Note: Memo only checks outer props here.
          // Inner props are checked in the reconciler.
          r.$$typeof === G))
            a = r.propTypes;
          else
            return;
          if (a) {
            var o = de(r);
            Ot(a, e.props, "prop", o, e);
          } else if (r.PropTypes !== void 0 && !Nr) {
            Nr = !0;
            var c = de(r);
            f("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", c || "Unknown");
          }
          typeof r.getDefaultProps == "function" && !r.getDefaultProps.isReactClassApproved && f("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
        }
      }
      function xt(e) {
        {
          for (var r = Object.keys(e.props), a = 0; a < r.length; a++) {
            var o = r[a];
            if (o !== "children" && o !== "key") {
              Ue(e), f("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", o), Ue(null);
              break;
            }
          }
          e.ref !== null && (Ue(e), f("Invalid attribute `ref` supplied to `React.Fragment`."), Ue(null));
        }
      }
      function it(e, r, a) {
        var o = t(e);
        if (!o) {
          var c = "";
          (e === void 0 || typeof e == "object" && e !== null && Object.keys(e).length === 0) && (c += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var d = kt(r);
          d ? c += d : c += tt();
          var l;
          e === null ? l = "null" : Le(e) ? l = "array" : e !== void 0 && e.$$typeof === X ? (l = "<" + (de(e.type) || "Unknown") + " />", c = " Did you accidentally export a JSX literal instead of a component?") : l = typeof e, f("React.createElement: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", l, c);
        }
        var y = Cr.apply(this, arguments);
        if (y == null)
          return y;
        if (o)
          for (var R = 2; R < arguments.length; R++)
            ot(arguments[R], e);
        return e === ne ? xt(y) : ut(y), y;
      }
      var st = !1;
      function At(e) {
        var r = it.bind(null, e);
        return r.type = e, st || (st = !0, se("React.createFactory() is deprecated and will be removed in a future major release. Consider using JSX or use React.createElement() directly instead.")), Object.defineProperty(r, "type", {
          enumerable: !1,
          get: function() {
            return se("Factory.type is deprecated. Access the class directly before passing it to createFactory."), Object.defineProperty(this, "type", {
              value: e
            }), e;
          }
        }), r;
      }
      function Dt(e, r, a) {
        for (var o = Tr.apply(this, arguments), c = 2; c < arguments.length; c++)
          ot(arguments[c], o.type);
        return ut(o), o;
      }
      function Ft(e, r) {
        var a = ie.transition;
        ie.transition = {};
        var o = ie.transition;
        ie.transition._updatedFibers = /* @__PURE__ */ new Set();
        try {
          e();
        } finally {
          if (ie.transition = a, a === null && o._updatedFibers) {
            var c = o._updatedFibers.size;
            c > 10 && se("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."), o._updatedFibers.clear();
          }
        }
      }
      var ct = !1, hr = null;
      function It(e) {
        if (hr === null)
          try {
            var r = ("require" + Math.random()).slice(0, 7), a = A && A[r];
            hr = a.call(A, "timers").setImmediate;
          } catch {
            hr = function(c) {
              ct === !1 && (ct = !0, typeof MessageChannel > "u" && f("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
              var d = new MessageChannel();
              d.port1.onmessage = c, d.port2.postMessage(void 0);
            };
          }
        return hr(e);
      }
      var Ye = 0, lt = !1;
      function ft(e) {
        {
          var r = Ye;
          Ye++, N.current === null && (N.current = []);
          var a = N.isBatchingLegacy, o;
          try {
            if (N.isBatchingLegacy = !0, o = e(), !a && N.didScheduleLegacyUpdate) {
              var c = N.current;
              c !== null && (N.didScheduleLegacyUpdate = !1, Ur(c));
            }
          } catch (I) {
            throw mr(r), I;
          } finally {
            N.isBatchingLegacy = a;
          }
          if (o !== null && typeof o == "object" && typeof o.then == "function") {
            var d = o, l = !1, y = {
              then: function(I, W) {
                l = !0, d.then(function(z) {
                  mr(r), Ye === 0 ? Vr(z, I, W) : I(z);
                }, function(z) {
                  mr(r), W(z);
                });
              }
            };
            return !lt && typeof Promise < "u" && Promise.resolve().then(function() {
            }).then(function() {
              l || (lt = !0, f("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
            }), y;
          } else {
            var R = o;
            if (mr(r), Ye === 0) {
              var P = N.current;
              P !== null && (Ur(P), N.current = null);
              var j = {
                then: function(I, W) {
                  N.current === null ? (N.current = [], Vr(R, I, W)) : I(R);
                }
              };
              return j;
            } else {
              var x = {
                then: function(I, W) {
                  I(R);
                }
              };
              return x;
            }
          }
        }
      }
      function mr(e) {
        e !== Ye - 1 && f("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "), Ye = e;
      }
      function Vr(e, r, a) {
        {
          var o = N.current;
          if (o !== null)
            try {
              Ur(o), It(function() {
                o.length === 0 ? (N.current = null, r(e)) : Vr(e, r, a);
              });
            } catch (c) {
              a(c);
            }
          else
            r(e);
        }
      }
      var Wr = !1;
      function Ur(e) {
        if (!Wr) {
          Wr = !0;
          var r = 0;
          try {
            for (; r < e.length; r++) {
              var a = e[r];
              do
                a = a(!0);
              while (a !== null);
            }
            e.length = 0;
          } catch (o) {
            throw e = e.slice(r + 1), o;
          } finally {
            Wr = !1;
          }
        }
      }
      var $t = it, Lt = Dt, Mt = At, Nt = {
        map: Fe,
        forEach: ir,
        count: kr,
        toArray: jr,
        only: sr
      };
      v.Children = Nt, v.Component = b, v.Fragment = ne, v.Profiler = Q, v.PureComponent = C, v.StrictMode = ae, v.Suspense = U, v.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Y, v.act = ft, v.cloneElement = Lt, v.createContext = cr, v.createElement = $t, v.createFactory = Mt, v.createRef = Rr, v.forwardRef = Dr, v.isValidElement = Re, v.lazy = Ar, v.memo = u, v.startTransition = Ft, v.unstable_act = ft, v.useCallback = $, v.useContext = p, v.useDebugValue = me, v.useDeferredValue = Ke, v.useEffect = h, v.useId = Fr, v.useImperativeHandle = we, v.useInsertionEffect = B, v.useLayoutEffect = F, v.useMemo = J, v.useReducer = S, v.useRef = _, v.useState = w, v.useSyncExternalStore = Ir, v.useTransition = H, v.version = Ce, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
    }();
  }(Xe, Xe.exports)), Xe.exports;
}
var mt;
function Br() {
  return mt || (mt = 1, process.env.NODE_ENV === "production" ? br.exports = Bt() : br.exports = zt()), br.exports;
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var gt;
function qt() {
  if (gt) return Ze;
  gt = 1;
  var A = Br(), v = Symbol.for("react.element"), Ce = Symbol.for("react.fragment"), X = Object.prototype.hasOwnProperty, pe = A.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, ne = { key: !0, ref: !0, __self: !0, __source: !0 };
  function ae(Q, L, ee) {
    var M, U = {}, re = null, G = null;
    ee !== void 0 && (re = "" + ee), L.key !== void 0 && (re = "" + L.key), L.ref !== void 0 && (G = L.ref);
    for (M in L) X.call(L, M) && !ne.hasOwnProperty(M) && (U[M] = L[M]);
    if (Q && Q.defaultProps) for (M in L = Q.defaultProps, L) U[M] === void 0 && (U[M] = L[M]);
    return { $$typeof: v, type: Q, key: re, ref: G, props: U, _owner: pe.current };
  }
  return Ze.Fragment = Ce, Ze.jsx = ae, Ze.jsxs = ae, Ze;
}
var Je = {};
/**
 * @license React
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var _t;
function Ht() {
  return _t || (_t = 1, process.env.NODE_ENV !== "production" && function() {
    var A = Br(), v = Symbol.for("react.element"), Ce = Symbol.for("react.portal"), X = Symbol.for("react.fragment"), pe = Symbol.for("react.strict_mode"), ne = Symbol.for("react.profiler"), ae = Symbol.for("react.provider"), Q = Symbol.for("react.context"), L = Symbol.for("react.forward_ref"), ee = Symbol.for("react.suspense"), M = Symbol.for("react.suspense_list"), U = Symbol.for("react.memo"), re = Symbol.for("react.lazy"), G = Symbol.for("react.offscreen"), ce = Symbol.iterator, $e = "@@iterator";
    function oe(t) {
      if (t === null || typeof t != "object")
        return null;
      var u = ce && t[ce] || t[$e];
      return typeof u == "function" ? u : null;
    }
    var ue = A.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    function D(t) {
      {
        for (var u = arguments.length, s = new Array(u > 1 ? u - 1 : 0), p = 1; p < u; p++)
          s[p - 1] = arguments[p];
        ge("error", t, s);
      }
    }
    function ge(t, u, s) {
      {
        var p = ue.ReactDebugCurrentFrame, w = p.getStackAddendum();
        w !== "" && (u += "%s", s = s.concat([w]));
        var S = s.map(function(_) {
          return String(_);
        });
        S.unshift("Warning: " + u), Function.prototype.apply.call(console[t], console, S);
      }
    }
    var ie = !1, N = !1, K = !1, le = !1, ve = !1, Se;
    Se = Symbol.for("react.module.reference");
    function Te(t) {
      return !!(typeof t == "string" || typeof t == "function" || t === X || t === ne || ve || t === pe || t === ee || t === M || le || t === G || ie || N || K || typeof t == "object" && t !== null && (t.$$typeof === re || t.$$typeof === U || t.$$typeof === ae || t.$$typeof === Q || t.$$typeof === L || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      t.$$typeof === Se || t.getModuleId !== void 0));
    }
    function Be(t, u, s) {
      var p = t.displayName;
      if (p)
        return p;
      var w = u.displayName || u.name || "";
      return w !== "" ? s + "(" + w + ")" : s;
    }
    function Oe(t) {
      return t.displayName || "Context";
    }
    function q(t) {
      if (t == null)
        return null;
      if (typeof t.tag == "number" && D("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof t == "function")
        return t.displayName || t.name || null;
      if (typeof t == "string")
        return t;
      switch (t) {
        case X:
          return "Fragment";
        case Ce:
          return "Portal";
        case ne:
          return "Profiler";
        case pe:
          return "StrictMode";
        case ee:
          return "Suspense";
        case M:
          return "SuspenseList";
      }
      if (typeof t == "object")
        switch (t.$$typeof) {
          case Q:
            var u = t;
            return Oe(u) + ".Consumer";
          case ae:
            var s = t;
            return Oe(s._context) + ".Provider";
          case L:
            return Be(t, t.render, "ForwardRef");
          case U:
            var p = t.displayName || null;
            return p !== null ? p : q(t.type) || "Memo";
          case re: {
            var w = t, S = w._payload, _ = w._init;
            try {
              return q(_(S));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var Z = Object.assign, Y = 0, se, f, fe, Pe, ye, n, i;
    function g() {
    }
    g.__reactDisabledLog = !0;
    function b() {
      {
        if (Y === 0) {
          se = console.log, f = console.info, fe = console.warn, Pe = console.error, ye = console.group, n = console.groupCollapsed, i = console.groupEnd;
          var t = {
            configurable: !0,
            enumerable: !0,
            value: g,
            writable: !0
          };
          Object.defineProperties(console, {
            info: t,
            log: t,
            warn: t,
            error: t,
            group: t,
            groupCollapsed: t,
            groupEnd: t
          });
        }
        Y++;
      }
    }
    function E() {
      {
        if (Y--, Y === 0) {
          var t = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: Z({}, t, {
              value: se
            }),
            info: Z({}, t, {
              value: f
            }),
            warn: Z({}, t, {
              value: fe
            }),
            error: Z({}, t, {
              value: Pe
            }),
            group: Z({}, t, {
              value: ye
            }),
            groupCollapsed: Z({}, t, {
              value: n
            }),
            groupEnd: Z({}, t, {
              value: i
            })
          });
        }
        Y < 0 && D("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var k = ue.ReactCurrentDispatcher, O;
    function T(t, u, s) {
      {
        if (O === void 0)
          try {
            throw Error();
          } catch (w) {
            var p = w.stack.trim().match(/\n( *(at )?)/);
            O = p && p[1] || "";
          }
        return `
` + O + t;
      }
    }
    var C = !1, V;
    {
      var Rr = typeof WeakMap == "function" ? WeakMap : Map;
      V = new Rr();
    }
    function Qe(t, u) {
      if (!t || C)
        return "";
      {
        var s = V.get(t);
        if (s !== void 0)
          return s;
      }
      var p;
      C = !0;
      var w = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var S;
      S = k.current, k.current = null, b();
      try {
        if (u) {
          var _ = function() {
            throw Error();
          };
          if (Object.defineProperty(_.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(_, []);
            } catch (H) {
              p = H;
            }
            Reflect.construct(t, [], _);
          } else {
            try {
              _.call();
            } catch (H) {
              p = H;
            }
            t.call(_.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (H) {
            p = H;
          }
          t();
        }
      } catch (H) {
        if (H && p && typeof H.stack == "string") {
          for (var h = H.stack.split(`
`), B = p.stack.split(`
`), F = h.length - 1, $ = B.length - 1; F >= 1 && $ >= 0 && h[F] !== B[$]; )
            $--;
          for (; F >= 1 && $ >= 0; F--, $--)
            if (h[F] !== B[$]) {
              if (F !== 1 || $ !== 1)
                do
                  if (F--, $--, $ < 0 || h[F] !== B[$]) {
                    var J = `
` + h[F].replace(" at new ", " at ");
                    return t.displayName && J.includes("<anonymous>") && (J = J.replace("<anonymous>", t.displayName)), typeof t == "function" && V.set(t, J), J;
                  }
                while (F >= 1 && $ >= 0);
              break;
            }
        }
      } finally {
        C = !1, k.current = S, E(), Error.prepareStackTrace = w;
      }
      var we = t ? t.displayName || t.name : "", me = we ? T(we) : "";
      return typeof t == "function" && V.set(t, me), me;
    }
    function Le(t, u, s) {
      return Qe(t, !1);
    }
    function Er(t) {
      var u = t.prototype;
      return !!(u && u.isReactComponent);
    }
    function Me(t, u, s) {
      if (t == null)
        return "";
      if (typeof t == "function")
        return Qe(t, Er(t));
      if (typeof t == "string")
        return T(t);
      switch (t) {
        case ee:
          return T("Suspense");
        case M:
          return T("SuspenseList");
      }
      if (typeof t == "object")
        switch (t.$$typeof) {
          case L:
            return Le(t.render);
          case U:
            return Me(t.type, u, s);
          case re: {
            var p = t, w = p._payload, S = p._init;
            try {
              return Me(S(w), u, s);
            } catch {
            }
          }
        }
      return "";
    }
    var _e = Object.prototype.hasOwnProperty, ke = {}, er = ue.ReactDebugCurrentFrame;
    function je(t) {
      if (t) {
        var u = t._owner, s = Me(t.type, t._source, u ? u.type : null);
        er.setExtraStackFrame(s);
      } else
        er.setExtraStackFrame(null);
    }
    function de(t, u, s, p, w) {
      {
        var S = Function.call.bind(_e);
        for (var _ in t)
          if (S(t, _)) {
            var h = void 0;
            try {
              if (typeof t[_] != "function") {
                var B = Error((p || "React class") + ": " + s + " type `" + _ + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof t[_] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw B.name = "Invariant Violation", B;
              }
              h = t[_](u, _, p, s, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (F) {
              h = F;
            }
            h && !(h instanceof Error) && (je(w), D("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", p || "React class", s, _, typeof h), je(null)), h instanceof Error && !(h.message in ke) && (ke[h.message] = !0, je(w), D("Failed %s type: %s", s, h.message), je(null));
          }
      }
    }
    var xe = Array.isArray;
    function Ne(t) {
      return xe(t);
    }
    function rr(t) {
      {
        var u = typeof Symbol == "function" && Symbol.toStringTag, s = u && t[Symbol.toStringTag] || t.constructor.name || "Object";
        return s;
      }
    }
    function tr(t) {
      try {
        return Ve(t), !1;
      } catch {
        return !0;
      }
    }
    function Ve(t) {
      return "" + t;
    }
    function ze(t) {
      if (tr(t))
        return D("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", rr(t)), Ve(t);
    }
    var be = ue.ReactCurrentOwner, wr = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, nr, ar, Ae;
    Ae = {};
    function Cr(t) {
      if (_e.call(t, "ref")) {
        var u = Object.getOwnPropertyDescriptor(t, "ref").get;
        if (u && u.isReactWarning)
          return !1;
      }
      return t.ref !== void 0;
    }
    function Sr(t) {
      if (_e.call(t, "key")) {
        var u = Object.getOwnPropertyDescriptor(t, "key").get;
        if (u && u.isReactWarning)
          return !1;
      }
      return t.key !== void 0;
    }
    function Tr(t, u) {
      if (typeof t.ref == "string" && be.current && u && be.current.stateNode !== u) {
        var s = q(be.current.type);
        Ae[s] || (D('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', q(be.current.type), t.ref), Ae[s] = !0);
      }
    }
    function Re(t, u) {
      {
        var s = function() {
          nr || (nr = !0, D("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", u));
        };
        s.isReactWarning = !0, Object.defineProperty(t, "key", {
          get: s,
          configurable: !0
        });
      }
    }
    function or(t, u) {
      {
        var s = function() {
          ar || (ar = !0, D("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", u));
        };
        s.isReactWarning = !0, Object.defineProperty(t, "ref", {
          get: s,
          configurable: !0
        });
      }
    }
    var Or = function(t, u, s, p, w, S, _) {
      var h = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: v,
        // Built-in properties that belong on the element
        type: t,
        key: u,
        ref: s,
        props: _,
        // Record the component responsible for creating this element.
        _owner: S
      };
      return h._store = {}, Object.defineProperty(h._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(h, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: p
      }), Object.defineProperty(h, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: w
      }), Object.freeze && (Object.freeze(h.props), Object.freeze(h)), h;
    };
    function Pr(t, u, s, p, w) {
      {
        var S, _ = {}, h = null, B = null;
        s !== void 0 && (ze(s), h = "" + s), Sr(u) && (ze(u.key), h = "" + u.key), Cr(u) && (B = u.ref, Tr(u, w));
        for (S in u)
          _e.call(u, S) && !wr.hasOwnProperty(S) && (_[S] = u[S]);
        if (t && t.defaultProps) {
          var F = t.defaultProps;
          for (S in F)
            _[S] === void 0 && (_[S] = F[S]);
        }
        if (h || B) {
          var $ = typeof t == "function" ? t.displayName || t.name || "Unknown" : t;
          h && Re(_, $), B && or(_, $);
        }
        return Or(t, h, B, w, p, be.current, _);
      }
    }
    var We = ue.ReactCurrentOwner, ur = ue.ReactDebugCurrentFrame;
    function he(t) {
      if (t) {
        var u = t._owner, s = Me(t.type, t._source, u ? u.type : null);
        ur.setExtraStackFrame(s);
      } else
        ur.setExtraStackFrame(null);
    }
    var De;
    De = !1;
    function Ee(t) {
      return typeof t == "object" && t !== null && t.$$typeof === v;
    }
    function Fe() {
      {
        if (We.current) {
          var t = q(We.current.type);
          if (t)
            return `

Check the render method of \`` + t + "`.";
        }
        return "";
      }
    }
    function kr(t) {
      return "";
    }
    var ir = {};
    function jr(t) {
      {
        var u = Fe();
        if (!u) {
          var s = typeof t == "string" ? t : t.displayName || t.name;
          s && (u = `

Check the top-level render call using <` + s + ">.");
        }
        return u;
      }
    }
    function sr(t, u) {
      {
        if (!t._store || t._store.validated || t.key != null)
          return;
        t._store.validated = !0;
        var s = jr(u);
        if (ir[s])
          return;
        ir[s] = !0;
        var p = "";
        t && t._owner && t._owner !== We.current && (p = " It was passed a child from " + q(t._owner.type) + "."), he(t), D('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', s, p), he(null);
      }
    }
    function cr(t, u) {
      {
        if (typeof t != "object")
          return;
        if (Ne(t))
          for (var s = 0; s < t.length; s++) {
            var p = t[s];
            Ee(p) && sr(p, u);
          }
        else if (Ee(t))
          t._store && (t._store.validated = !0);
        else if (t) {
          var w = oe(t);
          if (typeof w == "function" && w !== t.entries)
            for (var S = w.call(t), _; !(_ = S.next()).done; )
              Ee(_.value) && sr(_.value, u);
        }
      }
    }
    function Ie(t) {
      {
        var u = t.type;
        if (u == null || typeof u == "string")
          return;
        var s;
        if (typeof u == "function")
          s = u.propTypes;
        else if (typeof u == "object" && (u.$$typeof === L || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        u.$$typeof === U))
          s = u.propTypes;
        else
          return;
        if (s) {
          var p = q(u);
          de(s, t.props, "prop", p, t);
        } else if (u.PropTypes !== void 0 && !De) {
          De = !0;
          var w = q(u);
          D("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", w || "Unknown");
        }
        typeof u.getDefaultProps == "function" && !u.getDefaultProps.isReactClassApproved && D("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function qe(t) {
      {
        for (var u = Object.keys(t.props), s = 0; s < u.length; s++) {
          var p = u[s];
          if (p !== "children" && p !== "key") {
            he(t), D("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", p), he(null);
            break;
          }
        }
        t.ref !== null && (he(t), D("Invalid attribute `ref` supplied to `React.Fragment`."), he(null));
      }
    }
    var He = {};
    function lr(t, u, s, p, w, S) {
      {
        var _ = Te(t);
        if (!_) {
          var h = "";
          (t === void 0 || typeof t == "object" && t !== null && Object.keys(t).length === 0) && (h += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var B = kr();
          B ? h += B : h += Fe();
          var F;
          t === null ? F = "null" : Ne(t) ? F = "array" : t !== void 0 && t.$$typeof === v ? (F = "<" + (q(t.type) || "Unknown") + " />", h = " Did you accidentally export a JSX literal instead of a component?") : F = typeof t, D("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", F, h);
        }
        var $ = Pr(t, u, s, w, S);
        if ($ == null)
          return $;
        if (_) {
          var J = u.children;
          if (J !== void 0)
            if (p)
              if (Ne(J)) {
                for (var we = 0; we < J.length; we++)
                  cr(J[we], t);
                Object.freeze && Object.freeze(J);
              } else
                D("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else
              cr(J, t);
        }
        if (_e.call(u, "key")) {
          var me = q(t), H = Object.keys(u).filter(function(Ir) {
            return Ir !== "key";
          }), Ke = H.length > 0 ? "{key: someKey, " + H.join(": ..., ") + ": ...}" : "{key: someKey}";
          if (!He[me + Ke]) {
            var Fr = H.length > 0 ? "{" + H.join(": ..., ") + ": ...}" : "{}";
            D(`A props object containing a "key" prop is being spread into JSX:
  let props = %s;
  <%s {...props} />
React keys must be passed directly to JSX without using spread:
  let props = %s;
  <%s key={someKey} {...props} />`, Ke, me, Fr, me), He[me + Ke] = !0;
          }
        }
        return t === X ? qe($) : Ie($), $;
      }
    }
    function xr(t, u, s) {
      return lr(t, u, s, !0);
    }
    function Ar(t, u, s) {
      return lr(t, u, s, !1);
    }
    var Dr = Ar, fr = xr;
    Je.Fragment = X, Je.jsx = Dr, Je.jsxs = fr;
  }()), Je;
}
var bt;
function Kt() {
  return bt || (bt = 1, process.env.NODE_ENV === "production" ? _r.exports = qt() : _r.exports = Ht()), _r.exports;
}
var te = Kt();
const Gt = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20xmlns:xlink='http://www.w3.org/1999/xlink'%20aria-hidden='true'%20role='img'%20class='iconify%20iconify--logos'%20width='35.93'%20height='32'%20preserveAspectRatio='xMidYMid%20meet'%20viewBox='0%200%20256%20228'%3e%3cpath%20fill='%2300D8FF'%20d='M210.483%2073.824a171.49%20171.49%200%200%200-8.24-2.597c.465-1.9.893-3.777%201.273-5.621c6.238-30.281%202.16-54.676-11.769-62.708c-13.355-7.7-35.196.329-57.254%2019.526a171.23%20171.23%200%200%200-6.375%205.848a155.866%20155.866%200%200%200-4.241-3.917C100.759%203.829%2077.587-4.822%2063.673%203.233C50.33%2010.957%2046.379%2033.89%2051.995%2062.588a170.974%20170.974%200%200%200%201.892%208.48c-3.28.932-6.445%201.924-9.474%202.98C17.309%2083.498%200%2098.307%200%20113.668c0%2015.865%2018.582%2031.778%2046.812%2041.427a145.52%20145.52%200%200%200%206.921%202.165a167.467%20167.467%200%200%200-2.01%209.138c-5.354%2028.2-1.173%2050.591%2012.134%2058.266c13.744%207.926%2036.812-.22%2059.273-19.855a145.567%20145.567%200%200%200%205.342-4.923a168.064%20168.064%200%200%200%206.92%206.314c21.758%2018.722%2043.246%2026.282%2056.54%2018.586c13.731-7.949%2018.194-32.003%2012.4-61.268a145.016%20145.016%200%200%200-1.535-6.842c1.62-.48%203.21-.974%204.76-1.488c29.348-9.723%2048.443-25.443%2048.443-41.52c0-15.417-17.868-30.326-45.517-39.844Zm-6.365%2070.984c-1.4.463-2.836.91-4.3%201.345c-3.24-10.257-7.612-21.163-12.963-32.432c5.106-11%209.31-21.767%2012.459-31.957c2.619.758%205.16%201.557%207.61%202.4c23.69%208.156%2038.14%2020.213%2038.14%2029.504c0%209.896-15.606%2022.743-40.946%2031.14Zm-10.514%2020.834c2.562%2012.94%202.927%2024.64%201.23%2033.787c-1.524%208.219-4.59%2013.698-8.382%2015.893c-8.067%204.67-25.32-1.4-43.927-17.412a156.726%20156.726%200%200%201-6.437-5.87c7.214-7.889%2014.423-17.06%2021.459-27.246c12.376-1.098%2024.068-2.894%2034.671-5.345a134.17%20134.17%200%200%201%201.386%206.193ZM87.276%20214.515c-7.882%202.783-14.16%202.863-17.955.675c-8.075-4.657-11.432-22.636-6.853-46.752a156.923%20156.923%200%200%201%201.869-8.499c10.486%202.32%2022.093%203.988%2034.498%204.994c7.084%209.967%2014.501%2019.128%2021.976%2027.15a134.668%20134.668%200%200%201-4.877%204.492c-9.933%208.682-19.886%2014.842-28.658%2017.94ZM50.35%20144.747c-12.483-4.267-22.792-9.812-29.858-15.863c-6.35-5.437-9.555-10.836-9.555-15.216c0-9.322%2013.897-21.212%2037.076-29.293c2.813-.98%205.757-1.905%208.812-2.773c3.204%2010.42%207.406%2021.315%2012.477%2032.332c-5.137%2011.18-9.399%2022.249-12.634%2032.792a134.718%20134.718%200%200%201-6.318-1.979Zm12.378-84.26c-4.811-24.587-1.616-43.134%206.425-47.789c8.564-4.958%2027.502%202.111%2047.463%2019.835a144.318%20144.318%200%200%201%203.841%203.545c-7.438%207.987-14.787%2017.08-21.808%2026.988c-12.04%201.116-23.565%202.908-34.161%205.309a160.342%20160.342%200%200%201-1.76-7.887Zm110.427%2027.268a347.8%20347.8%200%200%200-7.785-12.803c8.168%201.033%2015.994%202.404%2023.343%204.08c-2.206%207.072-4.956%2014.465-8.193%2022.045a381.151%20381.151%200%200%200-7.365-13.322Zm-45.032-43.861c5.044%205.465%2010.096%2011.566%2015.065%2018.186a322.04%20322.04%200%200%200-30.257-.006c4.974-6.559%2010.069-12.652%2015.192-18.18ZM82.802%2087.83a323.167%20323.167%200%200%200-7.227%2013.238c-3.184-7.553-5.909-14.98-8.134-22.152c7.304-1.634%2015.093-2.97%2023.209-3.984a321.524%20321.524%200%200%200-7.848%2012.897Zm8.081%2065.352c-8.385-.936-16.291-2.203-23.593-3.793c2.26-7.3%205.045-14.885%208.298-22.6a321.187%20321.187%200%200%200%207.257%2013.246c2.594%204.48%205.28%208.868%208.038%2013.147Zm37.542%2031.03c-5.184-5.592-10.354-11.779-15.403-18.433c4.902.192%209.899.29%2014.978.29c5.218%200%2010.376-.117%2015.453-.343c-4.985%206.774-10.018%2012.97-15.028%2018.486Zm52.198-57.817c3.422%207.8%206.306%2015.345%208.596%2022.52c-7.422%201.694-15.436%203.058-23.88%204.071a382.417%20382.417%200%200%200%207.859-13.026a347.403%20347.403%200%200%200%207.425-13.565Zm-16.898%208.101a358.557%20358.557%200%200%201-12.281%2019.815a329.4%20329.4%200%200%201-23.444.823c-7.967%200-15.716-.248-23.178-.732a310.202%20310.202%200%200%201-12.513-19.846h.001a307.41%20307.41%200%200%201-10.923-20.627a310.278%20310.278%200%200%201%2010.89-20.637l-.001.001a307.318%20307.318%200%200%201%2012.413-19.761c7.613-.576%2015.42-.876%2023.31-.876H128c7.926%200%2015.743.303%2023.354.883a329.357%20329.357%200%200%201%2012.335%2019.695a358.489%20358.489%200%200%201%2011.036%2020.54a329.472%20329.472%200%200%201-11%2020.722Zm22.56-122.124c8.572%204.944%2011.906%2024.881%206.52%2051.026c-.344%201.668-.73%203.367-1.15%205.09c-10.622-2.452-22.155-4.275-34.23-5.408c-7.034-10.017-14.323-19.124-21.64-27.008a160.789%20160.789%200%200%201%205.888-5.4c18.9-16.447%2036.564-22.941%2044.612-18.3ZM128%2090.808c12.625%200%2022.86%2010.235%2022.86%2022.86s-10.235%2022.86-22.86%2022.86s-22.86-10.235-22.86-22.86s10.235-22.86%2022.86-22.86Z'%3e%3c/path%3e%3c/svg%3e", Zt = "/vite.svg";
var Jt = Br();
const Rt = /* @__PURE__ */ Yt(Jt), Xt = (A) => Rt.useState(A), Qt = ({}) => {
  const [A, v] = Xt(0);
  return Rt.useEffect(() => {
    v(1);
  }, []), /* @__PURE__ */ te.jsxs("h1", { className: "text-xl text-center", children: [
    "Todo ",
    A
  ] });
}, en = () => /* @__PURE__ */ te.jsxs("div", { className: "w-full h-full flex flex-col justify-center items-center", children: [
  /* @__PURE__ */ te.jsx(Qt, {}),
  /* @__PURE__ */ te.jsxs("div", { children: [
    /* @__PURE__ */ te.jsx("a", { href: "https://vite.dev", target: "_blank", children: /* @__PURE__ */ te.jsx("img", { src: Zt, className: "logo", alt: "Vite logo" }) }),
    /* @__PURE__ */ te.jsx("a", { href: "https://react.dev", target: "_blank", children: /* @__PURE__ */ te.jsx("img", { src: Gt, className: "logo react", alt: "React logo" }) })
  ] }),
  /* @__PURE__ */ te.jsx("h1", { children: "Vite + React, It's Plugin Headless Platform." }),
  /* @__PURE__ */ te.jsx("div", { className: "card", children: /* @__PURE__ */ te.jsxs("p", { children: [
    "Edit ",
    /* @__PURE__ */ te.jsx("code", { children: "src/App.tsx" }),
    " and save to test HMR"
  ] }) }),
  /* @__PURE__ */ te.jsx("p", { className: "read-the-docs", children: "Click on the Vite and React logos to learn more" })
] });
export {
  en as default
};
