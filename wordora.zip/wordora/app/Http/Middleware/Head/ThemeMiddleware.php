<?php

namespace App\Http\Middleware\Head;

use Closure;
use Illuminate\Http\Request;
use App\Models\Head\Theme;
use Illuminate\Support\Facades\View;
use Symfony\Component\HttpFoundation\Response;
use App\Models\{ Post, Comment };

class ThemeMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {

        $active_theme = cache('active_theme', function () {
            return Theme::active();
        });

        $active_menu = cache('active_menu', function () {
            return
                [
                    'name' => 'main',
                    'items' => [
                        [
                            'name' => 'Accueil',
                            'link' => '/'
                        ],

                        [
                            'name' => 'Actualitée',
                            'link' => '/blog'
                        ],

                        [
                            'name' => 'Agences',
                            'link' => '/agences'
                        ],

                        [
                            'name' => 'Services',
                            'link' => '/services'
                        ],

                        [
                            'name' => 'Engagements',
                            'link' => '/engagements'
                        ],

                        [
                            'name' => 'Carriere',
                            'link' => '/carriere'
                        ],

                        [
                            'name' => 'A Propos',
                            'link' => '/a Propos'
                        ],
                    ]
                ];
        });
        

        $latest_posts = cache('latest_posts', function () {
            return Post::with('author:id,displayName,name')
                ->where('post_type', 'post')
                ->where('post_status', 'publish')
                ->latest()
                ->take(5)
                ->get();
        });
        
        $latest_comments = cache('latest_comments', function () {
            return Comment:://::with('author:id,displayName,name')
                latest()
                ->take(5)
                ->get();
        });
        
        $main_services = cache('main_services', function () {
            return [
                [
                    'name'=> 'Nettoyage écologique', 
                    'thumbnail'=> 'https://lh3.googleusercontent.com/pw/AP1GczPq1VBkun0UWqbOfTBr6rltZ3FsqCJncALD0IUM08Q8m-55o7AG3YLZ7Hm1gnt07h7GF_wEOzrmJq9Zmlpq1bjfSpYwGO53aEVluj7qFZRUFaQq93t9RZrfvltd_OVhVHzJSIYfpSRZN8KNOCaVSoOu8g=w1430-h953-s-no-gm?authuser=0',
                ],
                
                [
                    'name'=> 'Nettoyage après Sinistre', 
                    'thumbnail'=> 'https://benedic.be/img/articles/wysiwyg/articles-apres-un-sinistre-pensez-au-nettoyage.jpg',
                ],
                
                
                [
                    'name'=> 'Nettoyage Industriel', 
                    'thumbnail'=> 'https://lh3.googleusercontent.com/pw/AP1GczNh0-NGSvVcT0ylsD1IdHPE2vYBiZpo_maZrjuAKJCS4XB_IxYESwrT-YxpcaNv_9SfB2_kC7aY-c-XI03eZaTM26b0dRGCnCvPzDC8QO8-N0s9hUaYBBb-7gU5xPbgVCMczRlTjXCCZsjhs0tjnPq7BQ=w1040-h468-s-no-gm?authuser=0',
                ],
        
                [
                    'name'=> 'Entretien des espaces verts', 
                    'thumbnail'=> 'https://lh3.googleusercontent.com/pw/AP1GczMR3M3p1GewJwbHrLux9-TdYFbjXtBk9V2dJQQUkgxEl7JYjqP3d4SKBbOfMIafV6EgaFcmBaEmIuCLqMJ_IU9b5SADiLDlmITxiv0aJu3yqGYVZahZ2EOxy9VzWnf7jzPrCplt5PbObvwHyRShkzHVGA=w1430-h953-s-no-gm?authuser=0',
                ],
                
                
                [
                    'name'=> 'Gestion des déchets', 
                    'thumbnail'=> 'https://lh3.googleusercontent.com/pw/AP1GczNllmtWJVKwNnmQTjTUkyvgwRaZgdmcGd-ZNvGzjPaQ2ZfFe7XRUNLGpg43gqYWGSR7DgYmwgRbmNT2fGrO5I0MXOatOshnrkKKo61CNa_SfvW0nKZZfhYJOt9SAVv45RIZ9jq9VFkajNF5zK_GNw_akw=w1920-h908-s-no-gm?authuser=0',
                ],
                
                [
                    'name'=> 'Formation hygiène et propreté', 
                    'thumbnail'=> 'uploads/form_hy_prop.jpg'
                ],
                
                [
                    'name'=> 'Audit et Conseil', 
                    'thumbnail'=> 'uploads/AUDIT.jpg'
                ],
                
                [
                    'name'=> 'Conciegerie', 
                    'thumbnail'=> 'https://lh3.googleusercontent.com/pw/AP1GczNLUY8jzC2zzlTou3VW9_FhKrjBCqSfTCnncpEyfjHCf5NiKXqYTElcpJHZld8Z4YpbMfGj5OentRjxTJxCjUpbrLGOuIaU3h1nLnAPn4MQO2tHVms0v01bIUu_O4K3yyt2kseMhmb-Ll8xC0dM72OAfA=w1040-h468-s-no-gm?authuser=0'
                ],
                
                [
                    'name'=> 'Desinfection, Deratisation, Désinsectisation.', 
                    'thumbnail'=> 'https://lh3.googleusercontent.com/pw/AP1GczP8-qZGfxXrQdCNebzc7HDwRX_rJbCXDh8PGNqu5LoQjfrqFBAoiu4BzUoAcpUTnGE7dyqy7cX7AcTjzXzSbXoDs3IRb8UqEJmZclZfwSUFIpYEA9TOX5KlusBv7rAZq9IdBeoquKnKTleArJbjzkPewQ=w1430-h953-s-no-gm?authuser=0g'
                ]
                
            ];
        });
        

        View::share('menu', $active_menu);
        View::share('theme', $active_theme);
        View::share('latest_posts', $latest_posts);
        View::share('main_services', $main_services);
        View::share('latest_comments', $latest_comments);


        return $next($request);
    }
}
