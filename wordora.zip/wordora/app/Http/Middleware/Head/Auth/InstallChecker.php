<?php

namespace App\Http\Middleware\Head\Auth;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Head\User;

class InstallChecker
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $runIntaller = User::count() === 0;

        if($runIntaller) {
            return redirect()->route('admin.init.index');
        }
        return $next($request);
    }
}
