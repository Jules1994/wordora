<?php

namespace App\Http\Middleware\Head;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

class PermissionResolver
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, $permission): Response
    {
        /*$user = Auth::user();
        if (!$user || !$user->hasPermission($permission)) {
            return redirect()->route('dashboard')->with('error', 'Accès refusé.');
        }*/
        return $next($request);
    }
}
