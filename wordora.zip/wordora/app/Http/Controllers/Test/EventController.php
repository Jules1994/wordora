<?php

namespace App\Http\Controllers\Test;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EventController extends Controller
{
    //
    public function index(Request $request) {

        //$permissions = Auth::user()->roles->flatMap->permissions->pluck('name')->unique();
        return inertia('head/account/overview');
    }
}
