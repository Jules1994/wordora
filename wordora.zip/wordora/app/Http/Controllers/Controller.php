<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\File;

use Exception;

abstract class Controller
{
    //
    protected function updateInstance($instanceClass, $inputs) {
        $keys = array_keys($inputs);
        foreach($keys as $key) {
            $value = $inputs[$key];
            if(is_null($value)) {
                continue;
            }
            $instanceClass->$key = $value;
        }
    }

    protected function updateAssocArray($value, $inputs) {
        $keys = array_keys($inputs);
        $returnValue = [];
        foreach($keys as $key) {
            $value = $inputs[$key];
            $returnValue[$key] = is_null($value) ? $value[$key]: $value;
        }

        return $returnValue;
    }

    protected function unzip(string $input_file, string $output_folder) {
        // Extraire le zip
        $zip = new \ZipArchive();
        $res = $zip->open($input_file);
        if($res === FALSE) {
            throw new Exception('Error, cannot open zip file: "' . $input_file . '"');
        }
        $zip->extractTo($output_folder);
        $zip->close();
    }

    protected function deleteFile($file_path) {
        if (File::exists($file_path)) {
            return File::delete($file_path);
        }else {
            return FALSE;
        }
    }

}
