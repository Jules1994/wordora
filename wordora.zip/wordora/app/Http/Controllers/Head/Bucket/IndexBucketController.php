<?php

namespace App\Http\Controllers\Head\Bucket;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IndexBucketController extends Controller
{
    //
}
