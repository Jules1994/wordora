<?php

namespace App\Http\Controllers\Head\Report;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ModuleNavigationController extends Controller
{
    //
    private $root = 'head/projects/';
    public function index(Request $request) {

        $ref_module = $request->ref;
        if(!$ref_module) {
            $ref_module = "dashboard_app";
        }
        return inertia("{$this->root}{$ref_module}");
    }
}
