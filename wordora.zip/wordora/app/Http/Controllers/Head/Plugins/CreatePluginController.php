<?php

namespace App\Http\Controllers\Head\Plugins;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Plugin };

class CreatePluginController extends Controller
{
    //
    public function index(Request $req) {
        return inertia('head/plugins/form');
    }

    public function store(Request $req) {
        try {
            $Input = $req->validate([
                'slug' => 'required|unique:plugins,slug',
                'name' => 'required',
                'cdn_url' => 'nullable|string',
                'local_path' => 'nullable|string',
                'description' => 'nullable|string',
                'version' => 'integer|nullable',
            ]);

    
            $plugin = new Plugin($Input);
            $plugin->save();

            return redirect()->route('admin.plugins.index')->with(['message', 'Successfull']);
        } catch (\Exception $e) {
            return redirect()->back()->withErrors($e->getMessage());
        }
    }
}
