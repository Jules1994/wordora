<?php

namespace App\Http\Controllers\Head\Plugins;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Plugin };

class DeletePluginController extends Controller
{
    //
    public function remove(Request $req, $id) {
        try {

            $plugin = Plugin::where('id', $id)->first();
            if(is_null($plugin)) {
                throw new \Exception("Plugin not found");
            }

            $plugin->delete();
            return redirect()->route('admin.plugins.index')->with(['message', 'Successfull']);
            
        } catch (\Exception $e) {
            return redirect()->back()->withErrors($e->getMessage());
        }        
    }
}
