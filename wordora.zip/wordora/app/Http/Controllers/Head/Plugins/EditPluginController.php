<?php

namespace App\Http\Controllers\Head\Plugins;

use App\Http\Controllers\Controller;
use App\Models\Head\{ Plugin };
use Illuminate\Http\Request;
use App\Head\PluginInstaller;

class EditPluginController extends Controller
{
    //
    public function index(Request $req, $id) {
        $plugin = Plugin::where('id', $id)->first();
        return inertia('head/plugins/show', compact('plugin'));
    }

    public function update(Request $req, $id) {
        try {
            $Input = $req->validate([
                "active" => "bollean|nullable",
            ]);

            $plugin = Plugin::where('id', $id)->first();
            if(is_null($plugin)) {
                throw new \Exception("Plugin not found");
            }
    
            $this->updateInstance($plugin, $Input);
            $plugin->update();

            return redirect()->route('admin.plugins.index')->with(['message', 'Successfull']);
        } catch (\Exception $e) {
            return redirect()->back()->withErrors($e->getMessage());
        }
    }

    public function toggle(Request $req, $id) {

        try {

            $plugin = Plugin::where('id', $id)->first();
            if(is_null($plugin)) {
                throw new \Exception("Plugin not found");
            }

            $plugin->update(['is_active' => !$plugin->is_active]);
            return redirect()->route('admin.plugins.index')->with(['message', 'Successfull']);
            
        } catch (\Exception $e) {
            return redirect()->back()->withErrors($e->getMessage());
        }
    }

    public function install(Request $req, $id)
    {
        try {

            $plugin = Plugin::where('id', $id)->first();
            if(is_null($plugin)) {
                throw new \Exception("Plugin not found");
            }

            $pluginPath = $plugin->local_path;
            // Extraire le zip
            $zip = new \ZipArchive();
            $zip->open($pluginPath);
            $extractPath = pathinfo($pluginPath, PATHINFO_FILENAME);
            /*$zip->open(storage_path('app/' . $pluginPath));
            $extractPath = storage_path('app/plugins/' . pathinfo($pluginPath, PATHINFO_FILENAME));*/
            $zip->extractTo($extractPath);
            $zip->close();

            // Étape 2 : Installation
            $installer = new PluginInstaller();
            $installer->installPlugin($extractPath);
            
            $plugin->installed = true;
            $plugin->save();

            return redirect()->route('admin.plugins.index')->with(['message', 'Successfull']);
        } catch (\Exception $e) {
            //return redirect()->back()->withErrors($e->getMessage());
            return response()->json(['error' => $e->getMessage()]);
        }
    }    
}
