<?php

namespace App\Http\Controllers\Head\Plugins;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{Plugin};

class IndexPluginController extends Controller
{
    //
    public function index(Request $req)
    {
        $plugins = Plugin::all();
        return inertia('head/plugins/index', compact('plugins'));
    }

    public function load(Request $request)
    {
        $pluginSlug = $request->query('plugin');

        // Vérifie si le plugin existe
        $plugin = Plugin::where('slug', $pluginSlug)
            ->where('is_active', true)
            ->firstOrFail();

        return inertia('head/plugins/load', compact('plugin'));
    }

    public function preview(Request $request, $id)
    {

        // Vérifie si le plugin existe
        $plugin = Plugin::where('id', $id)
            ->where('is_active', true)
            ->firstOrFail();
            
        return inertia('head/plugins/load', compact('plugin'));
    }
}
