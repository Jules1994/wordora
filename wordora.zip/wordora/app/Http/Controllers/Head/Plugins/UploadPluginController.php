<?php

namespace App\Http\Controllers\Head\Plugins;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\Head\PluginInstaller;
use App\Models\Head\{Plugin};

class UploadPluginController extends Controller
{
    //
    public function upload(Request $req)
    {
        try {

            /*$Input = $req->validate([
                'plugin_file' => 'required|file|max:10240', // Limite à 10 Mo, uniquement fichiers .js
            ]);*/

   
            if($req->hasFile('plugin_file') && $req->file('plugin_file')->isValid()) {

                $originalNameWithExt = $req->file('plugin_file')->getClientOriginalName();
                $originalName = explode('.', $originalNameWithExt)[0];

                $pluginPath = $req->file('plugin_file')->move(storage_path('app/public/plugins'), $originalNameWithExt);//$req->file('plugin_file')->store('public/plugins');
                logger("File {$originalName} uploaded successfully to {$pluginPath}");

                if($pluginPath) {
                    $plugin = new Plugin(
                        [
                            'slug' => Str::slug($originalName),
                            'name' => $originalName,
                            'local_path' => $pluginPath
                        ]
                    );
                    $plugin->save();
                }

                return redirect()->route('admin.plugins.index');
            }
            
            throw new \Exception("Error uploading...");


        } catch (\Exception $e) {
            //return redirect()->back()->withErrors($e->getMessage());
            return response()->json(['error' => $e->getMessage()]);
        }
    }

    public function uploadZip(Request $req)
    {
        try {

            $Input = $req->validate([
                'plugin' => 'required|file|mimes:zip',
            ]);

            $path = $req->file('plugin_file')->store('public/plugins');
            $plugin = new Plugin($Input);

            // Enregistrer le plugin dans storage
            $pluginPath = $req->file('plugin')->storeAs('plugins', $req->file('plugin')->getClientOriginalName());

            // Extraire le zip
            $zip = new \ZipArchive();
            $zip->open(storage_path('app/' . $pluginPath));
            $extractPath = storage_path('app/plugins/' . pathinfo($pluginPath, PATHINFO_FILENAME));
            $zip->extractTo($extractPath);
            $zip->close();

            // Étape 2 : Installation
            $installer = new PluginInstaller();
            $installer->installPlugin($extractPath);

            return redirect()->route('admin.plugins.index')->with(['message', 'Successfull']);
        } catch (\Exception $e) {
            //return redirect()->back()->withErrors($e->getMessage());
            return response()->json(['error' => $e->getMessage()]);
        }
    }

    public function updatePlugin(Request $request, Plugin $plugin)
    {
        $request->validate([
            'plugin_file' => 'required|file|mimes:js|max:10240', // Limite à 10 Mo
            'version' => 'required|string',
        ]);

        // Vérifie que la version est plus récente
        if (version_compare($request->version, $plugin->version, '<=')) {
            return redirect()->route('admin.plugins.index')->withErrors([
                'error' => 'La version doit être supérieure à la version actuelle.',
            ]);
        }

        // Stocke le nouveau fichier dans le dossier plugins
        $path = $request->file('plugin_file')->store('public/plugins');
        $filename = basename($path);

        // Met à jour le plugin avec la nouvelle version et le chemin du fichier
        $plugin->update([
            'local_path' => $filename,
            'version' => $request->version,
        ]);

        return redirect()->route('admin.plugins.index')->with('success', "Plugin mis à jour vers la version {$request->version}.");
    }

    public function checkUpdates()
    {
        $plugins = Plugin::all();
        $updates = [];

        // Récupère les informations de version depuis le CDN
        $remotePlugins = json_decode(file_get_contents('https://cdn.example.com/plugins/versions.json'), true);

        foreach ($plugins as $plugin) {
            if (isset($remotePlugins[$plugin->slug])) {
                $remoteVersion = $remotePlugins[$plugin->slug]['version'];
                $remoteUrl = $remotePlugins[$plugin->slug]['url'];

                if (version_compare($remoteVersion, $plugin->version, '>')) {
                    $updates[] = [
                        'plugin' => $plugin->name,
                        'current_version' => $plugin->version,
                        'new_version' => $remoteVersion,
                        'url' => $remoteUrl,
                    ];
                }
            }
        }

        return response()->json($updates);
    }

    public function applyUpdate(Request $request, Plugin $plugin)
    {
        $request->validate(['url' => 'required|url', 'version' => 'required|string']);

        // Télécharge le fichier distant
        $contents = file_get_contents($request->url);
        $filename = "public/plugins/{$plugin->slug}.js";
        Storage::put($filename, $contents);

        // Met à jour la version du plugin
        $plugin->update([
            'local_path' => basename($filename),
            'version' => $request->version,
        ]);

        return redirect()->route('admin.plugins.index')->with('success', "Plugin mis à jour vers la version {$request->version}.");
    }

    public function install(Request $request)
    {
        $pluginPath = storage_path('app/plugins/' . $request->plugin_name);

        if (!File::exists($pluginPath)) {
            return response()->json(['error' => 'Plugin non trouvé.'], 404);
        }

        $installer = new PluginInstaller();
        $installer->installPlugin($pluginPath);

        return response()->json(['message' => 'Plugin installé avec succès.']);
    }
}
