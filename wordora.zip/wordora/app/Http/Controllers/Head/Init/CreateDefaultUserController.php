<?php

namespace App\Http\Controllers\Head\Init;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{Role, User};
use Exception;
use Illuminate\Support\Facades\Hash;

class CreateDefaultUserController extends Controller
{
    public function index(Request $request)
    {
        return inertia('head/init/userform');
    }

    public function createUser(Request $request)
    {
        try {

            $Input = $request->validate([
                'name' => 'required|min:4|string',
                'email' => 'required|min:8|string',
                'password' => 'required|min:8|string',
                'password_confirm' => 'required|min:8|string'
            ]);

            $role = Role::where('slug', 'admin')->first();
            if (!$role) {
                $Input['slug'] = 'admin';
                $Input['color'] = 'red';
                $role = new Role($Input);
                $role->save();
            }

            if($Input['password'] !== $Input['password_confirm']) {
                throw new Exception("Passwords don't match");
            }

            $user = new User([
                'name' => $Input['name'],
                'email'=> $Input['email'],
                'password'=> Hash::make($Input['password'])
            ]);

            $user->save();
            $user->roles()->syncWithoutDetaching([$role->id]);

            return redirect()->route('admin.auth.index');
        } catch (\Exception $e) {
            return response()->json([
                'error' => $e->getMessage()
            ]);
        }
    }
}
