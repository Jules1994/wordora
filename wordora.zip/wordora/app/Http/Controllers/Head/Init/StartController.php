<?php

namespace App\Http\Controllers\Head\Init;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class StartController extends Controller
{
    //
    public function index(Request $request) {
        return inertia('head/init/starter');
    }

    public function install(Request $request) {
       return "Starter install";
    }
}
