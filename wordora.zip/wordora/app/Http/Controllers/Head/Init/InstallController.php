<?php

namespace App\Http\Controllers\Head\Init;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\AppInfo;

class InstallController extends Controller
{
    //
    public function index(Request $request) {
        $appinfo = AppInfo::where('slug', 'appinfo')->first();
        return inertia('head/init/install', compact('appinfo'));
    }

    public function install(Request $request) {
        try {
            
            $Input = $request->validate([
                'app_name' => 'required|min:4|string',
                'app_url' => 'required|min:8|string'
            ]);

            $appinfo = AppInfo::where('slug', 'appinfo')->first();
            if($appinfo) {
                
                $value = is_null($appinfo->value) ? []: json_decode($appinfo->value, TRUE);
                $value = $this->updateAssocArray($value, $Input);
                $appinfo->value = json_encode($value);
                $appinfo->save();
            }else {
               $appinfo = new AppInfo([
                'slug'=> 'appinfo',
                'name'=> 'App Info',
                'value'=> json_encode($Input),
               ]);
               $appinfo->save();
            }

            return redirect()->route('admin.init.user');
        } catch (\Exception $e) {
            return response()->json([
                'error' => $e->getMessage()
            ]);
        }
    }
}
