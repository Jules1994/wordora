<?php

namespace App\Http\Controllers\Head\Users;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ User };
use Exception;

class EditController extends Controller
{
    //
    public function index(Request $req, $id) { 
        $user = User::where('id', $id)->first();
        return inertia('head/users/form', compact('user'));
    }

    public function update(Request $req, $id) {

        try {
            $Input = $req->validate([
                "photo" => "string|nullable",
                "name" => "string|nullable",
                "displayname"=> "string|nullable",
                "email" => "email|nullable",
                "phones" => "string|min:8|max:12|nullable",
                "firstname" => "string|nullable",
                "lastname" => "string|nullable",
                "is_active" => "boolean|nullable",
                "is_active" => "boolean|nullable",
                "is_2fa_enabled" => "boolean|nullable",
                "role_id"=> "nullbale|integer"
            ]);

            $user = User::where('id', $id)->first();
            if(is_null($user)) {
                throw new Exception("User not found");
            }
            $this->updateInstance($user, $Input);
            $user->save();
            $user->roles()->syncWithoutDetaching([1]);

            return redirect()->route('admin.users.index');
        } catch (\Exception $e) {
            return response()->json([
                "error" => $e->getMessage(),
            ]);
        }
    }
}
