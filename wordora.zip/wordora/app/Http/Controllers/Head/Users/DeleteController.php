<?php

namespace App\Http\Controllers\Head\Users;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ User };

class DeleteController extends Controller
{
    //
    public function remove(Request $req, $id) {
        try {
            $Input = $req->validate([
                "photo" => "string|nullable",
                "name" => "string|nullable",
                "displayname"=> "string|nullable",
                "email" => "email|nullable",
                "phones" => "string|min:8|max:12|nullable",
                "firstname" => "string|nullable",
                "lastname" => "string|nullable",
                "is_active" => "boolean|nullable",
                "is_active" => "boolean|nullable",
                "is_2fa_enabled" => "boolean|nullable",
                "role_id"=> "nullbale|integer"
            ]);

            $user = User::where('id', $id)->first();
            if(is_null($user)) {
                throw new \Exception("User not found");
            }
            
            $user->delete();

            return redirect()->route('admin.users.index');
        } catch (\Exception $e) {
            return response()->json([
                "error" => $e->getMessage(),
            ]);
        }
    }
}
