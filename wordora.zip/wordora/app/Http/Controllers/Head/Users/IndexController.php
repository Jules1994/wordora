<?php

namespace App\Http\Controllers\Head\Users;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Role, User };

class IndexController extends Controller
{
    //
    public function index(Request $req) {

        $users = [];
        $query = User::with('roles')->orderBy('created_at', 'DESC');

        $url = Env('APP_URL') . '/';

        $filterBySearch = $req->input('search');
        if($filterBySearch) {
            $users =  $query->where('name', 'LIKE', $filterBySearch . '%');
        }

        $users = $query->paginate(12);
        $roles = Role::all()->map(function($role) {
            return [
                'key'=> $role->slug,
                'text'=> $role->name,
                'value'=> $role->slug
            ];
        });
        return inertia('head/users/index', compact('users', 'url',  'roles'));
    }
}
