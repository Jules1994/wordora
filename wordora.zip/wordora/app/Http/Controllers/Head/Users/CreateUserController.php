<?php

namespace App\Http\Controllers\Head\Users;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Role, User };

class CreateUserController extends Controller
{
    //
    public function index(Request $req) { 
        $roles = Role::all();
        return inertia('head/users/form', compact('roles'));
    }

    public function store(Request $req) {

        try {
            $Input = $req->validate([
                "photo" => "string|nullable",
                "name" => "required|string|nullable",
                "displayname"=> "required|string|nullable",
                "email" => "required|email|nullable",
                "phones" => "required|string|min:8|max:12|nullable",
                "firstname" => "required|string|nullable",
                "lastname" => "required|string|nullable",
                "is_active" => "boolean|nullable",
                "is_active" => "boolean|nullable",
                "is_2fa_enabled" => "boolean|nullable",
                "password"=> "required|min:8|string",
                "role_id"=> "required|nullbale|integer"
            ]);

            $user = new User($Input);
            $user->save();
            $user->roles()->syncWithoutDetaching([$Input['role_id']]);

            return redirect()->route('admin.users.index');
        } catch (\Exception $e) {
            return response()->json([
                "error" => $e->getMessage(),
            ]);
        }
    }

}
