<?php

namespace App\Http\Controllers\Head\Images;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ServeImageController extends Controller
{
    //
}
