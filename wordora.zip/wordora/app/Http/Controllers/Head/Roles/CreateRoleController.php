<?php

namespace App\Http\Controllers\Head\Roles;

use Illuminate\Support\Str;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Role };

class CreateRoleController extends Controller
{

    public function index(Request $req) {
        return inertia('head/roles/form');
    }

    public function store(Request $req) {

        try {
            $Input = $req->validate([
                "name" => "required|string|nullable",
                "color" => "required|string|nullable",
                "description" => "string|min:8|nullable"
            ]);

            $Input['slug'] = Str::slug($Input['name']);
            $role = new Role($Input);
            $role->save();

            return redirect()->route('admin.roles.index');
        } catch (\Exception $e) {
            return response()->json([
                "error" => $e->getMessage(),
            ]);
        }
    }
    
}
