<?php

namespace App\Http\Controllers\Head\Roles;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Role };

class IndexController extends Controller
{
    //
    public function index(Request $req) { 
        $roles = Role::all();

        if($req->format === "json") {
            $json_data = $roles->map(function($role) {
                return [
                    'value'=> $role->id,
                    'label'=> $role->name
                ];
            });
            return response()->json($json_data);
        }
        return inertia('head/roles/index', compact('roles'));
    }
}
