<?php

namespace App\Http\Controllers\Head\Roles;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Role };

class EditController extends Controller
{
    //
    public function index(Request $req, $id) { 
        $role = Role::where('id', $id)->first();
        return inertia('head/roles/form', compact('role'));
    }

    public function update(Request $req, $id) {

        try {
            $Input = $req->validate([
                "name" => "required|string|nullable",
                "color" => "required|string|nullable",
                "description" => "string|min:8|nullable"
            ]);
            $role = Role::where('id', $id)->first();
            if(is_null($role)) {
                throw new \Exception("User not found");
            }
    
            $this->updateInstance($role, $Input);
            $role->update();

            return redirect()->route('admin.roles.index')->with(['message', 'Successfull']);
        } catch (\Exception $e) {
            return redirect()->back()->withErrors($e->getMessage());
        }
    }
}
