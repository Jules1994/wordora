<?php

namespace App\Http\Controllers\Head\Roles;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Role };

class DeleteController extends Controller
{
    //
    public function remove(Request $req, $id) {
        try {
            
            $role = Role::where('id', $id)->first();
            if(is_null($role)) {
                throw new \Exception("User not found");
            }
            
            $role->delete();

            return redirect()->route('admin.users.index');
        } catch (\Exception $e) {
            return response()->json([
                "error" => $e->getMessage(),
            ]);
        }
    }
}
