<?php

namespace App\Http\Controllers\Head\Files;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CreateFileController extends Controller
{
    //
    public function create() {
        $error = session('error');
        return inertia('head/medias/form', compact('error'));
    }

    public function store() {
        
    }
}
