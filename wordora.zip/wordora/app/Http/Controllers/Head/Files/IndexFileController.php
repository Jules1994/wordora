<?php

namespace App\Http\Controllers\Head\Files;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IndexFileController extends Controller
{
    //
}
