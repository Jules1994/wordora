<?php

namespace App\Http\Controllers\Head\Setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DeleteController extends Controller
{
    //
}
