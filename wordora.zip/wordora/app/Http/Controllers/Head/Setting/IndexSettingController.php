<?php

namespace App\Http\Controllers\Head\Setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IndexSettingController extends Controller
{
    //
    public function index(Request $req) {
        $setting_view = $req->input('ref', 'preferences');
        return inertia('head/account/' . $setting_view);
    }
}
