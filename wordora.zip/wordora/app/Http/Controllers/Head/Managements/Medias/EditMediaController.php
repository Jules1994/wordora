<?php

namespace App\Http\Controllers\Head\Managements\Medias;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EditMediaController extends Controller
{
    //
}
