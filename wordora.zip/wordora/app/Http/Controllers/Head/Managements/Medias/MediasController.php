<?php

namespace App\Http\Controllers\Head\Managements\Medias;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\{Term};

class MediasController extends Controller
{
    //
    public function index(Request $request)
    {

        $medias = [];
        $error = session('error');

        $term = Term::where('name', 'file_upload')->first();
        if (!$term) {

            $term = new Term([
                'name' => 'file_upload',
                'slug' => Str::slug('file_upload')
            ]);
            $term->save();
        }

        $medias = $term->taxonomies()
            ->orderBy('created_at', 'DESC')
            ->get()->map(function ($media) {
                return json_decode($media->description);
            });

        if ($request->input('responsetype') === 'json') {
            return response()->json([
                'message' => 'Media Loaded',
                'medias' => $medias
            ], 200);
        }

        return inertia('head/medias/medias_app', compact('medias', 'error'));
    }
}
