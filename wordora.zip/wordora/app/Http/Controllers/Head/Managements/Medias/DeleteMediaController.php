<?php

namespace App\Http\Controllers\Head\Managements\Medias;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DeleteMediaController extends Controller
{
    //
}
