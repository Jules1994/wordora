<?php

namespace App\Http\Controllers\Head\Managements\Medias;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\{Term, TermTaxonomy};

class CreateMediaController extends Controller
{
    //
    public function create()
    {
        $error = session('error');
        return inertia('head/medias/form', compact('error'));
    }

    public function store(Request $request)
    {

        try {


            if ($request->hasFile('file') && $request->file('file')->isValid()) {

                if (!$request->hasFile('file')) {
                    throw new \Exception('Error uploading file!.');
                }

                $file = $request->file('file');
                $media = json_decode($request->input('metadata'));
                $fileName = $media->name;
                $folder_path = $this->findOrCreateFolder();
                $path = $file->move(storage_path('app/public/' . $folder_path), $folder_path . '/' . $fileName);

                if(!$path) {
                    throw new \Exception('Error upload!');
                }


                $term = Term::where('name', 'file_upload')->first();
                if(!$term) {

                    $term = new Term([
                        'name' => 'file_upload',
                        'slug' => Str::slug('file_upload')
                    ]);
                    $term->save();
                }

                // Ajouter une entrée dans la taxonomie
                $media->file_path = $folder_path . '/' . $fileName;
                $termTaxonomy = [
                    'term_id' => $term->id,
                    'taxonomy' => 'file_upload_' . $term->id,
                    'description' => json_encode($media)
                ];
                TermTaxonomy::create($termTaxonomy);

                $media->term_taxonomy = $termTaxonomy;
                return response()->json([
                    'state'=> true, 
                    'message'=> 'File uploaded!', 
                    'media'=> $media
                ]);
            }

            throw new \Exception("Error uploading...");
        } catch (\Exception $e) {
            return response()->json(['state'=> false, 'message'=> $e->getMessage()]);
            //return back()->with('error', $e->getMessage());
        }
    }

    public function findOrCreateFolder() {

        $segmentsDate = explode("-", date('Y-m-d'));
        $months = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juilet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre"];

        $year = $segmentsDate[0];
        $month = $months[intval($segmentsDate[1]) - 1];

        $path = "uploads/{$year}-{$month}";

        return $path;
    }
}
