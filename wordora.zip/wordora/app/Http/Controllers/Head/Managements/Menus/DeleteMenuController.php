<?php

namespace App\Http\Controllers\Head\Managements\Menus;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Term;

class DeleteMenuController extends Controller
{
    //
    public function delete(Request $req, $id) {
        try {
            
            $menu = Term::where('id', $id)->first();
            if(is_null($menu)) {
                throw new \Exception("Menu not found");
            }
            
            $menu->delete();

            return redirect()->route('admin.menus.index');
        } catch (\Exception $e) {
            return back()->with("error", $e->getMessage());
        }
    }
}
