<?php

namespace App\Http\Controllers\Head\Managements\Menus;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Term;

class MenusController extends Controller
{
    public function index(Request $request)
    {    
        $error = session('error');
        $menus = Term::select('terms.*', 'term_taxonomy.taxonomy', 'term_taxonomy.description')
            ->join('term_taxonomy', 'terms.id', 'term_taxonomy.term_id')
            ->get();
        return inertia('head/menus/menus_app', compact('menus', 'error'));
    }
    
}
