<?php

namespace App\Http\Controllers\Head\Managements\Menus;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Term;

class EditMenuController extends Controller
{
    public function edit(Request $req, $id) { 
        
        $menu = Term::where('id', $id)->first();
        $menu->taxonomies();
        $error = session('error');
        return inertia('head/menus/form', compact('menu', 'error'));
    }

    public function update(Request $request, $id) {

        try {

            $Input = $request->validate([
                'name' => 'nullable|string|max:255|unique:terms,name',
                'slug' => 'nullable|string|max:255|unique:terms,slug',
                'description' => 'nullable|string|max:255',
            ]);


            $menu = Term::where('id', $id)->first();
            if(is_null($menu)) {
                throw new \Exception("Menu not found");
            }
    
            $menu->name = $Input['name'] ?? $menu->name;
            $menu->slug = $Input['slug'] ?? $menu->slug;
            $menu->save();

            return redirect()->route('admin.menus.index')->with(['message', 'Successfull']);
        } catch (\Exception $e) {
            return back()->with("error", $e->getMessage());
        }
    }
}
