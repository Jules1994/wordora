<?php

namespace App\Http\Controllers\Head\Managements\Menus;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\{ Term, TermTaxonomy };

class CreateMenuController extends Controller
{
    //
    public function create() {
        $error = session('error');
        return inertia('head/menus/form', compact( 'error'));
    }

    public function store(Request $request) {
        try {
            
            $Input = $request->validate([
                'name' => 'required|string|max:255|unique:terms,name',
                'slug' => 'required|string|max:255|unique:terms,slug',
                'description' => 'nullable|string|max:255',
            ]);

            // Créer le terme pour le menu
            $menu = Term::create([
                'name' => $Input['name'],
                'slug' => $Input['slug'],
            ]);

            // Ajouter une entrée dans la taxonomie
            TermTaxonomy::create([
                'term_id' => $menu->id,
                'taxonomy' => 'nav_menu',
                'description' => $Input['description'],
            ]);

            return redirect()->route('admin.menus.index');
        } catch (\Exception $e) {
            return back()->with("error", $e->getMessage());
        }
    }
}
