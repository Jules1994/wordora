<?php

namespace App\Http\Controllers\Head\Managements\Pages;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;

class CreatePageController extends Controller
{
    public function index(Request $req) {
        $error = session('error');
        return inertia('head/pages/form', compact('error'));
    }

    public function store(Request $req) {

        try {
            $Input = $req->validate([
                "title" => "required|string|nullable"
            ]);

            $post = new Post($Input);
            $post->post_title = $Input['title'];
            $post->post_type = 'page';
            $post->author_id = $req->user()->id;
            $post->save();

            return redirect()->route('admin.pages.index');
        } catch (\Exception $e) {
            return back()->with("error", $e->getMessage());
        }
    }
}
