<?php

namespace App\Http\Controllers\Head\Managements\Pages;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;

class EditPagesController extends Controller
{
    //
    public function edit(Request $req, $id) { 
        $post = Post::where('id', $id)->first();
        $error = session('error');
        return inertia('head/editor/editor_app', compact('post', 'error'));
    }

    public function update(Request $req, $id) {

        try {

            $Input = $req->validate([
                "post_title" => "nullable|string",
                "post_content" => "nullable||nullable",
                "post_status" => "nullable|string",
                "description" => "nullable|string",
                "thumbnail" => "nullable|string",
                "meta" => "nullable|string"
            ]);

            $post = Post::where('id', $id)->first();

            if(is_null($post)) {
                throw new \Exception("Post not found");
            }
    
            $post->post_content = $Input['post_content'] ?? $post->post_content;
            $post->post_status = $Input['post_status'] ?? $post->post_status;
            $post->save();

            return redirect()->route('admin.posts.index')->with(['message', 'Successfull']);
        } catch (\Exception $e) {
            return back()->with("error", $e->getMessage());
        }
    }
}
