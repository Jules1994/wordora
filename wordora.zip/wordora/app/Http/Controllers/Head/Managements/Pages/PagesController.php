<?php

namespace App\Http\Controllers\Head\Managements\Pages;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;

class PagesController extends Controller
{
    //
    public function index(Request $req) { 
        $error = session('error');

        $query = Post::with('author:id,displayName,name')
            ->where('post_type', 'page');

        if($req->input('search')) {
            $query = $query->where('post_title','LIKE',  $$req->input('search') . '%');
        }

        $pages = $query->get();
        return inertia('head/pages/pages_app', compact('pages', 'error'));
    }
}
