<?php

namespace App\Http\Controllers\Head\Managements\Themes;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Theme };

class EditThemeController extends Controller
{
    //
    public function index(Request $req, $id) { 
        $theme = Theme::where('id', $id)->first();
        return inertia('head/themes/form', compact('form'));
    }

    public function update(Request $req, $id) {

        try {
            
            $Input = $req->validate([
                "name" => "string|nullable",
                "alias" => "string|nullable",
                "is_active" => "boolean|nullable"
            ]);

            $theme = Theme::where('id', $id)->first();
            if(is_null($theme)) {
                throw new \Exception("User not found");
            }
    
            $this->updateInstance($theme, $Input);
            $theme->update();

            return redirect()->route('admin.themes.index');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function toggle(Request $req, $id) {

        try {
        
            $theme = Theme::where('id', $id)->first();
            if(is_null($theme)) {
                throw new \Exception("Theme not found");
            }
    
            $theme->is_active = $theme->is_active === 1 ? 0: 1;
            $theme->save();

            return redirect()->route('admin.themes.index');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

}
