<?php

namespace App\Http\Controllers\Head\Managements\Themes;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Theme };

class CreateThemeController extends Controller
{
    public function index(Request $req) {
        $error = session('error');
        return inertia('head/themes/form', compact('error'));
    }

    public function store(Request $req) {

        try {

               
            if($req->hasFile('theme_file') && $req->file('theme_file')->isValid()) {

                $originalNameWithExt = $req->file('theme_file')->getClientOriginalName();
                $originalName = explode('.', $originalNameWithExt)[0];

                $themePath = $req->file('theme_file')->move(storage_path('app/public/themes'), $originalNameWithExt);//$req->file('plugin_file')->store('public/plugins');
                logger("File {$originalName} uploaded successfully to {$themePath}");

                if($themePath) {
                    $theme = new Theme(
                        [
                            'name' => $originalName,
                            'alias' => $originalName,
                            'path' => $themePath
                        ]
                    );
                    $theme->save();
                }

                $this->unzip(storage_path('app/public/themes/' . $originalName . '.zip'), storage_path('app/public/themes/'));
                $this->deleteFile(storage_path('app/public/themes/' . $originalName . '.zip'));
                return redirect()->route('admin.themes.index');
            }

            throw new \Exception("Error uploading...");

        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
