<?php

namespace App\Http\Controllers\Head\Managements\Themes;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{Theme};

class ThemesController extends Controller
{
    //
    public function index(Request $req)
    {
        $themes = Theme::all();

        if ($req->format === "json") {
            $json_data = $themes->map(function ($theme) {
                return [
                    'value' => $theme->id,
                    'label' => $theme->name
                ];
            });
            return response()->json($json_data);
        }
        return inertia('head/themes/themes_app', compact('themes'));
    }
}
