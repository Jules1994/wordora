<?php

namespace App\Http\Controllers\Head\Managements\Themes;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\{ Theme };

class DeleteThemeController extends Controller
{
    //
    public function remove(Request $req, $id) {
        try {
            
            $theme = Theme::where('id', $id)->first();
            if(is_null($theme)) {
                throw new \Exception("Theme not found");
            }
            
            $theme->delete();
            return redirect()->route('admin.themes.index');

        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
