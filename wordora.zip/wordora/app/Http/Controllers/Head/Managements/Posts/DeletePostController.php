<?php

namespace App\Http\Controllers\Head\Managements\Posts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;

class DeletePostController extends Controller
{
    //
    public function remove(Request $req, $id) {
        try {
            
            $post = Post::where('id', $id)->first();
            if(is_null($post)) {
                throw new \Exception("Post not found");
            }
            
            $post->delete();

            return redirect()->route('admin.posts.index');
        } catch (\Exception $e) {
            return back()->with("error", $e->getMessage());
        }
    }
}
