<?php

namespace App\Http\Controllers\Head\Managements\Posts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\{ Post, Term, TermRelationship, TermTaxonomy };

class CreatePostController extends Controller
{
    public function index(Request $req) {
        $error = session('error');
        return inertia('head/posts/form', compact('error'));
    }

    public function store(Request $req) {

        try {
            $Input = $req->validate([
                "title" => "required|string|nullable"
            ]);

            $post = new Post($Input);
            $post->post_title = $Input['title'];
            $post->author_id = $req->user()->id;
            $post->save();

            

            $term = Term::where('name', 'thumbnail')->first();
            if(!$term) {

                $term = new Term([
                    'name' => 'post_thumbnail',
                    'slug' => Str::slug('post_thumbnail')
                ]);
                $term->save();
            }

            $termTaxonomy = [
                'term_id' => $term->id,
                'taxonomy' => 'post_thumbnail_' . $post->id,
                'description' => null
            ];

            $termTaxonomy = new TermTaxonomy($termTaxonomy);
            $termTaxonomy->save();

            TermRelationship::create([
                'post_id'=> $post->id,
                'term_taxonomy_id'=> $termTaxonomy->id
            ]);

            return redirect()->route('admin.posts.index');
        } catch (\Exception $e) {
            return back()->with("error", $e->getMessage());
        }
    }
}
