<?php

namespace App\Http\Controllers\Head\Managements\Posts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{ TermRelationship };

class PostsController extends Controller
{
    //
    public function index(Request $req) {         
        $error = session('error');

        $query = TermRelationship::select('posts.*', 'term_taxonomy.description as post_thumbnail', 'users.name')
            ->join('posts', 'posts.id', 'term_relationships.post_id')
            ->join('term_taxonomy', 'term_taxonomy.id', 'term_relationships.term_taxonomy_id')
            ->join('users', 'users.id', 'posts.author_id')
            ->where('post_type', 'post')
            ->where('taxonomy', 'like',  "post_thumbnail_%");

        if($req->input('search')) {
            $query = $query->where('post_title', 'like', $req->input('search') . '%');
        }

        $posts = $query->get();
        //return $posts;
        return inertia('head/posts/posts_app', compact('posts', 'error'));
    }
}
