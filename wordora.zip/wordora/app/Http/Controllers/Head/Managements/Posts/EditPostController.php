<?php

namespace App\Http\Controllers\Head\Managements\Posts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{ Post, TermTaxonomy, TermRelationship };

class EditPostController extends Controller
{
    //
    public function edit(Request $req, $id) { 

        $post = TermRelationship::select('posts.*', 'term_taxonomy.description as thumbnail', 'users.name')
            ->join('posts', 'posts.id', 'term_relationships.post_id')
            ->join('term_taxonomy', 'term_taxonomy.id', 'term_relationships.term_taxonomy_id')
            ->join('users', 'users.id', 'posts.author_id')
            ->where('post_type', 'post')
            ->where('taxonomy', 'post_thumbnail_' . $id)
            ->first();
        $error = session('error');
        return inertia('head/editor/editor_app', compact('post', 'error'));
    }

    public function update(Request $req, $id) {

        try {

            $Input = $req->validate([
                "post_title" => "nullable|string",
                "post_content" => "nullable||nullable",
                "post_status" => "nullable|string",
                "description" => "nullable|string",
                "thumbnail" => "nullable|string",
                "meta" => "nullable|string"
            ]);

            $post = Post::where('id', $id)->first();

            if(is_null($post)) {
                throw new \Exception("Post not found");
            }

            $taxonomy = 'post_thumbnail_' . $post->id;
            $termTaxonomy = TermTaxonomy::where('taxonomy', $taxonomy)->first();

            $termTaxonomy->description = $Input['thumbnail'] ?? $termTaxonomy->taxonomy;
            $termTaxonomy->save();

            $post->post_content = $Input['post_content'] ?? $post->post_content;
            $post->post_status = $Input['post_status'] ?? $post->post_status;
            $post->save();

            return redirect()->route('admin.posts.index')->with(['message', 'Successfull']);
        } catch (\Exception $e) {
            return back()->with("error", $e->getMessage());
        }
    }
}
