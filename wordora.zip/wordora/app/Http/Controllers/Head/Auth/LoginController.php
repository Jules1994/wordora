<?php

namespace App\Http\Controllers\Head\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use App\Mail\Head\TwoFactorCodeMail;
use Exception;

class LoginController extends Controller
{
    //
    public function index(Request $request)
    {
        $error = session('error');
        return inertia('head/auth/login', compact('error'));
    }

    public function handle(Request $request)
    {

        try {

            $Input = $request->validate([
                'name' => 'required|min:4|string',
                'password' => 'required|min:8|string',
            ]);

            $user = User::where('name', $Input['name'])->first();
            if (!$user) {
                throw new Exception('User not found');
            }
            if (!$user->is_active) {
                throw new Exception('Account is deactivated');
            }
            if (!Hash::check($Input['password'], $user->password)) {
                throw new Exception('Incorrect password');
            }

            if ($user->is_2fa_enabled) {
                $user->two_factor_code = random_int(100000, 999999);
                $user->two_factor_expires_at = now()->addMinutes(5);
                $user->save();
                // Envoi de l'email
                Mail::to($user->email)->send(new TwoFactorCodeMail($user));
                return redirect()->intended('/admin/twofactor');
            }

            Auth::login($user);
            $user->is_logged_in = true;
            $user->session_id = Session::getId();
            $user->save();
            return redirect()->intended('/admin');

        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

    }
}
