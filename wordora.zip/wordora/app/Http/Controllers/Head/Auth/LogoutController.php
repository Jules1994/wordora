<?php

namespace App\Http\Controllers\Head\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Head\User;

class LogoutController extends Controller
{
    //
    public function index() {
        if(Auth::user()) {

            $user = User::where('id', Auth::user()->id)->first();
            $user->is_logged_in = false;
            $user->session_id = null;
            $user->save();

            Auth::logout();
            return redirect()->route('admin.auth.index');
        }
        abort(403);
    }
}
