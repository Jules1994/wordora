<?php

namespace App\Http\Controllers\Head\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\Head\User;
use Exception;

class ForgotPasswordController extends Controller
{
    //

    public function index() {
        $error = session('error');
        $message = session('message');
        return inertia('head/auth/reset', compact('message', 'error'));
    }

    public function handle(Request $request) {
        try {
            $request->validate([
                'email' => 'required|email'
            ]);
        
            /*DB::table('password_resets')->insert([
                'email' => $request->email,
                'token' => '98465',
            ]);*/
        
            return back()->with('message', 'Please, read your email sent!');
        }catch(\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function reset(Request $request) {

        try {
            $request->validate([
                'token' => 'required',
                'email' => 'required|email',
                'password' => 'required|confirmed|min:8',
            ]);
        
            $reset = DB::table('password_resets')->where([
                'email' => $request->email,
                'token' => $request->token,
            ])->first();
        
            if (!$reset || Carbon::parse($reset->created_at)->addMinutes(60)->isPast()) {
                return new Exception('Invalid or expired token');
            }
        
            $user = User::where('email', $request->email)->first();
            $user->password = Hash::make($request->password);
            $user->save();
        
            DB::table('password_resets')->where(['email' => $request->email])->delete();
        
            return redirect()->route('admin.auth.2factor');
        }catch(\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
