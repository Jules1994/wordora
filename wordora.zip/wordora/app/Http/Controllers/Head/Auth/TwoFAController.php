<?php

namespace App\Http\Controllers\Head\Auth;

use App\Models\Head\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TwoFAController extends Controller
{
    //
    public function index(Request $request)
    {
        $error = session('error');
        return inertia('head/auth/twofactor', compact('error'));
    }

    public function handle(Request $request)
    {
        try {
            $auth = Auth::user();

            $user = User::find($auth->id);
    
            if ($user->two_factor_code !== $request->code) {
                return new \Exception('message', 'Invalid code');
            }
      
            if ($user->two_factor_expires_at->isPast()) {
                return new \Exception('message', 'Code expired');
            }
      
            // Réinitialisation du code pour sécuriser
            $user->two_factor_code = null;
            $user->two_factor_expires_at = null;
            $user->save();
      
            return redirect()->intended('/admin/dashboard');
            //code...
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
