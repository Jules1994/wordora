<?php

namespace App\Http\Controllers\Head\Permissions;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    //
}
