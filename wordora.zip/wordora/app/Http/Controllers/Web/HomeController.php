<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Head\Theme;

class HomeController extends Controller
{
    public function index(Request $request) {
        
        $page = $request->get('page', 'index');
        return $this->view($page);
    }

    public function page(Request $request) {
        return $this->view('page');
    }

    public function search(Request $request) {
        return $this->view('search');
    }

    public function blog(Request $request) {
        return $this->view('blog');
    }

    public function show(Request $request) {
        return $this->view('show');
    }

    private function view(string $page, array $params = []) {

        $theme = cache('active_theme', function () {
            return Theme::active();
        });

        $themes_path_folder = storage_path('app/public/themes');
        $active_theme = !is_null($theme) ? $theme->name : 'default';

        if(!is_file($themes_path_folder . '/' . $active_theme . '/' . $page . '.blade.php')) {
            abort(404, 'Page non trouvée dans le thème.');
        }

        $params['theme'] = $active_theme;
        $active_page = "${active_theme}::${page}";
        return view($active_page, $params);
    }   
}
