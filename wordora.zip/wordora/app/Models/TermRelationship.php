<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TermRelationship extends Model
{
    use HasFactory;

    protected $fillable = [
        'post_id',
        'term_taxonomy_id',
    ];

    public function post()
    {
        return $this->belongsTo(Post::class);
    }

    public function termTaxonomy()
    {
        return $this->belongsTo(TermTaxonomy::class);
    }
}
