<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Head\User;
use App\Models\{ PostMeta, TermTaxonomy, Comment};

class Post extends Model
{
    use HasFactory;

    protected $fillable = [
        'author_id',
        'post_title',
        'post_content',
        'post_status',
        'post_type',
        'parent_id',
    ];

    public function author()
    {
        return $this->belongsTo(User::class, 'author_id');
    }

    public function meta()
    {
        return $this->hasMany(PostMeta::class);
    }

    public function terms()
    {
        return $this->belongsToMany(TermTaxonomy::class, 'term_relationships', 'post_id', 'term_taxonomy_id');
    }

    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

    public function parent()
    {
        return $this->belongsTo(Post::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(Post::class, 'parent_id');
    }
}
