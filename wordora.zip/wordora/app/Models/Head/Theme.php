<?php

namespace App\Models\Head;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Theme extends Model
{
    //
    public $table = "themes";
    protected $fillable = [
        'name',
        'alias',
        'is_active',
        'path'
    ];

    public static function active() {
        return DB::table('themes')->select("*")->where('is_active', 1)->first();
    }
}
