<?php

namespace App\Models\Head;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    protected $fillable = [
        'slug',
        'name',
        'permissions',
        'description',
        'color'
    ];
    public function permissions()
    {
        return $this->belongsToMany(Permission::class);
    }
}
