<?php

namespace App\Models\Head;

use Illuminate\Database\Eloquent\Model;

class LogFile extends Model
{
    //

    protected $fillable = [
        'name',
        'path',
        'date',
    ];

    public function saveLogFileInfo($path)
    {
        LogFile::create([
            'path' => $path,
            'name' => basename($path),
            'date' => now(),
        ]);
    }

}
