<?php

namespace App\Models\Head;

use Illuminate\Database\Eloquent\Model;

class Plugin extends Model
{
    //
    protected $fillable = ['slug', 'name', 'description', 'id_form', 'values', 'is_active', 'cdn_url', 'local_path', 'version', 'installed'];

    protected $casts = [
        'values' => 'json', // Décoder automatiquement les valeurs JSON
    ];
}
