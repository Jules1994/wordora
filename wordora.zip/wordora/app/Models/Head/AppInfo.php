<?php

namespace App\Models\Head;

use Illuminate\Database\Eloquent\Model;

class AppInfo extends Model
{
    //
    public $table = "appinfos";
    protected $fillable = [
        'slug',
        'name',
        'value',
        'type',
        'form_id',
        'description'
    ];
}
