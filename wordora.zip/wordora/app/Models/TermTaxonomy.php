<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TermTaxonomy extends Model
{
    use HasFactory;
    public $table = 'term_taxonomy';
    protected $fillable = [
        'term_id',
        'taxonomy',
        'description',
    ];

    public function term()
    {
        return $this->belongsTo(Term::class);
    }

    public function posts()
    {
        return $this->belongsToMany(Post::class, 'term_relationships', 'term_taxonomy_id', 'post_id');
    }
}
