<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CommentMeta extends Model
{
    use HasFactory;

    protected $fillable = [
        'comment_id',
        'meta_key',
        'meta_value',
    ];

    public function comment()
    {
        return $this->belongsTo(Comment::class);
    }
}