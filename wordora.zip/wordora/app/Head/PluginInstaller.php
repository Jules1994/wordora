<?php

namespace App\Head;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;

class PluginInstaller
{
    public function installPlugin(string $pluginPath)
    {
        $pluginPath = $pluginPath . '/' . $pluginPath;
        $migrationPath = $pluginPath . '/migrations';
        $sqlFile = $pluginPath  . '/database.sql';

        // Exécuter les migrations si elles existent
        if (File::exists($migrationPath)) {
            Artisan::call('migrate', ['--path' => $migrationPath]);
            echo Artisan::output();
        }

        // Exécuter un fichier SQL brut si présent
        if (File::exists($sqlFile)) {
            $sql = File::get($sqlFile);
            DB::unprepared($sql);
        }

        // (Optionnel) Exécuter des seeders
        $seederPath = $pluginPath . '/seeders';
        if (File::exists($seederPath)) {
            $this->runSeeders($seederPath);
        }
    }

    private function runSeeders(string $seederPath)
    {
        $seeders = File::files($seederPath);

        foreach ($seeders as $seeder) {
            $seederClass = pathinfo($seeder, PATHINFO_FILENAME);
            Artisan::call('db:seed', ['--class' => $seederClass]);
            echo Artisan::output();
        }
    }
}
