<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
        $themePath = storage_path('app/public/themes');
        if (is_dir($themePath)) {
            // Ajouter tous les thèmes disponibles au système de vues
            foreach (scandir($themePath) as $theme) {
                if ($theme !== '.' && $theme !== '..' && is_dir($themePath . '/' . $theme)) {
                    View::addNamespace($theme, $themePath . '/' . $theme);
                    //View::addNamespace($theme, $themePath . '/' . $theme . '/views/');
                }
            }
        }
    }
}
