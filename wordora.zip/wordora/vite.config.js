import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import { VitePWA } from 'vite-plugin-pwa';
import react from '@vitejs/plugin-react';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.tsx'],
            refresh: true,
        }),

        //react()
        /*VitePWA({
            registerType: 'autoUpdate',
            manifest: {
                name: 'Headless',
                short_name: 'Headless',
                description: 'Une application progressive avec Inertia.js',
                start_url: '/',
                display: 'standalone',
                background_color: '#ffffff',
                theme_color: '#007bff',
                icons: [
                    {
                        src: '/icons/icon-192x192.png',
                        sizes: '192x192',
                        type: 'image/png',
                    },
                    {
                        src: '/icons/icon-512x512.png',
                        sizes: '512x512',
                        type: 'image/png',
                    },
                ],
            },
        })*/
    ],

    build: {
        rollupOptions: {
            //external: ['react', 'react-dom'],
            output: {
                globals: {
                    react: 'React',
                    'react-dom': 'ReactDOM'
                }
            }
        }
    }

});
