<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\Head\{ AuthResolver, ThemeMiddleware};
use App\Http\Middleware\Head\Auth\{InstallChecker};
use App\Http\Controllers\Head\Auth\{ LoginController, LogoutController, TwoFAController, ForgotPasswordController };
use App\Http\Controllers\Head\Init\{ StartController, InstallController, CreateDefaultUserController };
use App\Http\Controllers\Head\Users\{ IndexController as ListUsersControlller, DeleteController as DeleteUserController, EditController as EditUserController, CreateUserController };
use App\Http\Controllers\Head\Roles\{ IndexController as ListRolesController, DeleteController as RolesDeleteController, EditController as EditRoleController, CreateRoleController };
use App\Http\Controllers\Head\Setting\{ IndexSettingController };
use App\Http\Controllers\Head\Plugins\{ IndexPluginController, CreatePluginController, EditPluginController, UploadPluginController, DeletePluginController };
use App\Http\Controllers\Head\Report\{ ModuleNavigationController };
use App\Http\Controllers\Head\Managements\Pages\{ PagesController, CreatePageController, EditPagesController, DeletePageController };
use App\Http\Controllers\Head\Managements\Posts\{ PostsController, CreatePostController, EditPostController, DeletePostController };
use App\Http\Controllers\Head\Managements\Themes\{ ThemesController, CreateThemeController, EditThemeController, DeleteThemeController };
use App\Http\Controllers\Head\Managements\Menus\{ MenusController, CreateMenuController, EditMenuController, DeleteMenuController };
use App\Http\Controllers\Head\Managements\Medias\{ MediasController, CreateMediaController, EditMediaController, DeleteMediaController };
use App\Http\Controllers\Web\HomeController;
use App\Http\Middleware\HandleInertiaRequests;

Route::middleware(ThemeMiddleware::class)->group(function() {

    Route::get('/', [HomeController::class, 'index']);
    Route::get('/page', [HomeController::class, 'page']);
    Route::get('/blog', [HomeController::class, 'blog']);
    Route::get('/show', [HomeController::class, 'show']);
    Route::get('/search', [HomeController::class, 'search']);
});

Route::middleware(HandleInertiaRequests::class)->prefix('admin')->group(function() {

    Route::prefix('init')->group(function() {

        Route::get('/', [StartController::class, 'index'])->name('admin.init.index');
        Route::post('/init-validate', [StartController::class, 'handle'])->name('init.validate');
    
        Route::get('/install', [InstallController::class, 'index'])->name('admin.init.install');
        Route::post('/install-validate', [InstallController::class, 'install'])->name('admin.init.install.validate');
    
        Route::get('/create-default-user', [CreateDefaultUserController::class, 'index'])->name('admin.init.user');
        Route::post('/create-default-user-validate', [CreateDefaultUserController::class, 'createUser'])->name('admin.init.user.validate');
    
    });
    
    Route::middleware(InstallChecker::class)->prefix('auth')->group(function() {
    
        Route::get('/', [LoginController::class, 'index'])->name('admin.auth.index');
        Route::post('/auth-validator', [LoginController::class, 'handle'])->name('admin.auth.validate');
    
    
        Route::get('/forgot', [ForgotPasswordController::class, 'index'])->name('admin.auth.forgot');
        Route::post('/forgot-generate-token', [ForgotPasswordController::class, 'handle'])->name('admin.auth.generate.token.validate');
        Route::get('/forgot-reset-password', [ForgotPasswordController::class, 'reset'])->name('admin.auth.forgot-reset-password');

        Route::get('/twofactor', [TwoFAController::class, 'index'])->name('admin.auth.2factor');
        Route::post('/twofactor-validator', [TwoFAController::class, 'handle'])->name('admin.auth.2factor.validate');
    
        Route::post('/logout', [LogoutController::class, 'index'])->name('admin.auth.logout');
    });
    
    Route::middleware(AuthResolver::class)->group(function() {

        Route::get('/', [ModuleNavigationController::class, 'index'])->name('admin.events');
    
        Route::prefix('users')->group(function() {
            Route::get('/', [ListUsersControlller::class, 'index'])->name('admin.users.index');
            
            Route::get('/create', [CreateUserController::class, 'index'])->name('admin.users.create.index');;
            Route::post('/create', [CreateUserController::class, 'store'])->name('admin.users.create.store');
    
            Route::get('/{id}/edit', [EditUserController::class, 'index'])->name('admin.users.edit');
            Route::put('/{id}/update', [EditUserController::class, 'update'])->name('admin.users.update');
    
            Route::delete('/{id}/delete', [DeleteUserController::class, 'remove'])->name('admin.users.remove');
        });
    
        Route::prefix('roles')->group(function() {
            Route::get('/', [ListRolesController::class, 'index'])->name('admin.roles.index');
    
            Route::get('/create', [CreateRoleController::class, 'index'])->name('admin.roles.create.index');
            Route::post('/create', [CreateRoleController::class, 'store'])->name('admin.roles.create.store');
    
            Route::get('/{id}/edit', [EditRoleController::class, 'index'])->name('admin.roles.edit');
            Route::put('/{id}/update', [EditRoleController::class, 'update'])->name('admin.roles.update');
    
            Route::delete('/{id}/delete', [RolesDeleteController::class, 'remove'])->name('admin.roles.remove');
        });
    
        Route::prefix('setting')->group(function() {
            Route::get('/', [IndexSettingController::class, 'index'])->name('admin.setting.index');
        });
    
        Route::prefix('plugins')->group(function() {
    
            Route::get('/', [IndexPluginController::class, 'index'])->name('admin.plugins.index');
    
    
            Route::get('/create', [CreatePluginController::class, 'index'])->name('admin.plugins.craete.index');
            Route::post('/create', [CreatePluginController::class, 'store'])->name('admin.plugins.create.store');
            Route::post('/upload', [UploadPluginController::class, 'upload'])->name('admin.plugins.upload');
    
            Route::get('/{id}/preview', [IndexPluginController::class, 'preview'])->name('admin.plugins.preview');
            Route::put('/{id}/install', [EditPluginController::class, 'install'])->name('admin.plugins.install');
            Route::put('/{id}/toggle', [EditPluginController::class, 'toggle'])->name('admin.plugins.toggle');
            Route::delete('/{id}/delete', [DeletePluginController::class, 'remove'])->name('admin.plugins.delete');
        });

        Route::prefix('pages')->group(function() {
    
            Route::get('/', [PagesController::class, 'index'])->name('admin.pages.index');
    
    
            Route::get('/create', [CreatePageController::class, 'index'])->name('admin.pages.create.index');
            Route::post('/create', [CreatePageController::class, 'store'])->name('admin.pages.create.store');
    
            Route::get('/{id}/edit', [EditPagesController::class, 'edit'])->name('admin.pages.edit');
            Route::put('/{id}/update', [EditPagesController::class, 'update'])->name('admin.pages.toggle');
            Route::delete('/{id}/delete', [DeletePageController::class, 'delete'])->name('admin.pages.delete');
        });

        Route::prefix('posts')->group(function() {
    
            Route::get('/', [PostsController::class, 'index'])->name('admin.posts.index');
    
    
            Route::get('/create', [CreatePostController::class, 'index'])->name('admin.posts.create.index');
            Route::post('/create', [CreatePostController::class, 'store'])->name('admin.posts.create.store');
    
            Route::get('/{id}/edit', [EditPostController::class, 'edit'])->name('admin.posts.edit');
            Route::put('/{id}/update', [EditPostController::class, 'update'])->name('admin.posts.toggle');
            Route::delete('/{id}/delete', [DeletePostController::class, 'delete'])->name('admin.posts.delete');
        });

        Route::prefix('themes')->group(function() {
    
            Route::get('/', [ThemesController::class, 'index'])->name('admin.themes.index');
    
    
            Route::get('/create', [CreateThemeController::class, 'index'])->name('admin.themes.create.index');
            Route::post('/create', [CreateThemeController::class, 'store'])->name('admin.themes.create.store');
    
            Route::get('/{id}/edit', [EditThemeController::class, 'edit'])->name('admin.themes.edit');
            Route::put('/{id}/update', [EditThemeController::class, 'update'])->name('admin.themes.update');
            Route::put('/{id}/toggle', [EditThemeController::class, 'toggle'])->name('admin.themes.toggle');
            Route::delete('/{id}/delete', [DeleteThemeController::class, 'delete'])->name('admin.themes.delete');
        });

        Route::prefix('menus')->group(function() {
    
            Route::get('/', [MenusController::class, 'index'])->name('admin.menus.index');
    
    
            Route::get('/create', [CreateMenuController::class, 'create'])->name('admin.menus.create.index');
            Route::post('/create', [CreateMenuController::class, 'store'])->name('admin.menus.create.store');
    
            Route::get('/{id}/edit', [EditMenuController::class, 'edit'])->name('admin.menus.edit');
            Route::put('/{id}/update', [EditMenuController::class, 'update'])->name('admin.menus.update');
            Route::put('/{id}/toggle', [EditThemeController::class, 'toggle'])->name('admin.menus.toggle');
            Route::delete('/{id}/delete', [DeleteMenuController::class, 'delete'])->name('admin.menus.delete');
        });
    
        Route::prefix('medias')->group(function() {
    
            Route::get('/', [MediasController::class, 'index'])->name('admin.medias.index');
    
    
            Route::get('/create', [CreateMediaController::class, 'create'])->name('admin.medias.create.index');
            Route::post('/create', [CreateMediaController::class, 'store'])->name('admin.medias.create.store');
    
            Route::get('/{id}/edit', [EditMediaController::class, 'edit'])->name('admin.medias.edit');
            Route::put('/{id}/update', [EditMediaController::class, 'update'])->name('admin.medias.update');
            Route::put('/{id}/toggle', [EditMediaController::class, 'toggle'])->name('admin.medias.toggle');
            Route::delete('/{id}/delete', [DeleteMediaController::class, 'delete'])->name('admin.medias.delete');
        });

    });
});