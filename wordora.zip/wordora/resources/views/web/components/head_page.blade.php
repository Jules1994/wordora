        <div class="w-full h-auto bg-white text-black/50">

            <section
                class="relative w-full h-[25%] xl:h-[25%] bg-cover bg-top bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                <!--- Overlay --->
                <div
                    class="absolute w-full h-full flex flex-col justify-center xl:justify-start items-center xl:items-start align-center top-62 px-0 xl:px-[20%] py-8 left-0 gap-y-8 z-80 text-white bg-black/30">
                    @isset($page->title)
                        {!! $page->title !!}
                    @endisset
                </div>
            </section>

            @isset($page->content)
                {!! $page->content !!}
            @endisset

        </div>
