@extends('web.layout')

@section('page')

@endsection