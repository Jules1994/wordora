@extends('web.layout')

@section('page')
    @isset($posts)
        
    @endisset
@endsection