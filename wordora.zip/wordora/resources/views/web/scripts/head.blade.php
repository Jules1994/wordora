<script src="https://gabonnettoyage.com/js/cdn_tailwindcss_com_3_4_3.js"></script>
<script src="https://gabonnettoyage.com/js/jquery.min.js"></script>
<script src="https://apis.google.com/js/platform.js" async="" defer="" gapi_processed="true"></script>
<meta name="google-signin-client_id" content="YOUR_CLIENT_ID.apps.googleusercontent.com">
<link rel="icon" href="https://gabonnettoyage.com/logo-gn.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/flowbite@2.4.1/dist/flowbite.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'google-blue': 'blueksy',
                    'google-green': 'green',
                    'google-red': 'orangered',
                }
            }
        }
    }
</script>
<script src="chrome-extension://ojaffphbffmdaicdkahnmihipclmepok/static/js/workers.min.js"></script>
<style>
    /* ! tailwindcss v3.4.3 | MIT License | https://tailwindcss.com */
    *,
    ::after,
    ::before {
        box-sizing: border-box;
        border-width: 0;
        border-style: solid;
        border-color: #e5e7eb
    }

    ::after,
    ::before {
        --tw-content: ''
    }

    :host,
    html {
        line-height: 1.5;
        -webkit-text-size-adjust: 100%;
        -moz-tab-size: 4;
        tab-size: 4;
        font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
        font-feature-settings: normal;
        font-variation-settings: normal;
        -webkit-tap-highlight-color: transparent
    }

    body {
        margin: 0;
        line-height: inherit
    }

    hr {
        height: 0;
        color: inherit;
        border-top-width: 1px
    }

    abbr:where([title]) {
        -webkit-text-decoration: underline dotted;
        text-decoration: underline dotted
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        font-size: inherit;
        font-weight: inherit
    }

    a {
        color: inherit;
        text-decoration: inherit
    }

    b,
    strong {
        font-weight: bolder
    }

    code,
    kbd,
    pre,
    samp {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        font-feature-settings: normal;
        font-variation-settings: normal;
        font-size: 1em
    }

    small {
        font-size: 80%
    }

    sub,
    sup {
        font-size: 75%;
        line-height: 0;
        position: relative;
        vertical-align: baseline
    }

    sub {
        bottom: -.25em
    }

    sup {
        top: -.5em
    }

    table {
        text-indent: 0;
        border-color: inherit;
        border-collapse: collapse
    }

    button,
    input,
    optgroup,
    select,
    textarea {
        font-family: inherit;
        font-feature-settings: inherit;
        font-variation-settings: inherit;
        font-size: 100%;
        font-weight: inherit;
        line-height: inherit;
        letter-spacing: inherit;
        color: inherit;
        margin: 0;
        padding: 0
    }

    button,
    select {
        text-transform: none
    }

    button,
    input:where([type=button]),
    input:where([type=reset]),
    input:where([type=submit]) {
        -webkit-appearance: button;
        background-color: transparent;
        background-image: none
    }

    :-moz-focusring {
        outline: auto
    }

    :-moz-ui-invalid {
        box-shadow: none
    }

    progress {
        vertical-align: baseline
    }

    ::-webkit-inner-spin-button,
    ::-webkit-outer-spin-button {
        height: auto
    }

    [type=search] {
        -webkit-appearance: textfield;
        outline-offset: -2px
    }

    ::-webkit-search-decoration {
        -webkit-appearance: none
    }

    ::-webkit-file-upload-button {
        -webkit-appearance: button;
        font: inherit
    }

    summary {
        display: list-item
    }

    blockquote,
    dd,
    dl,
    figure,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    hr,
    p,
    pre {
        margin: 0
    }

    fieldset {
        margin: 0;
        padding: 0
    }

    legend {
        padding: 0
    }

    menu,
    ol,
    ul {
        list-style: none;
        margin: 0;
        padding: 0
    }

    dialog {
        padding: 0
    }

    textarea {
        resize: vertical
    }

    input::placeholder,
    textarea::placeholder {
        opacity: 1;
        color: #9ca3af
    }

    [role=button],
    button {
        cursor: pointer
    }

    :disabled {
        cursor: default
    }

    audio,
    canvas,
    embed,
    iframe,
    img,
    object,
    svg,
    video {
        display: block;
        vertical-align: middle
    }

    img,
    video {
        max-width: 100%;
        height: auto
    }

    [hidden] {
        display: none
    }

    *,
    ::before,
    ::after {
        --tw-border-spacing-x: 0;
        --tw-border-spacing-y: 0;
        --tw-translate-x: 0;
        --tw-translate-y: 0;
        --tw-rotate: 0;
        --tw-skew-x: 0;
        --tw-skew-y: 0;
        --tw-scale-x: 1;
        --tw-scale-y: 1;
        --tw-pan-x: ;
        --tw-pan-y: ;
        --tw-pinch-zoom: ;
        --tw-scroll-snap-strictness: proximity;
        --tw-gradient-from-position: ;
        --tw-gradient-via-position: ;
        --tw-gradient-to-position: ;
        --tw-ordinal: ;
        --tw-slashed-zero: ;
        --tw-numeric-figure: ;
        --tw-numeric-spacing: ;
        --tw-numeric-fraction: ;
        --tw-ring-inset: ;
        --tw-ring-offset-width: 0px;
        --tw-ring-offset-color: #fff;
        --tw-ring-color: rgb(59 130 246 / 0.5);
        --tw-ring-offset-shadow: 0 0 #0000;
        --tw-ring-shadow: 0 0 #0000;
        --tw-shadow: 0 0 #0000;
        --tw-shadow-colored: 0 0 #0000;
        --tw-blur: ;
        --tw-brightness: ;
        --tw-contrast: ;
        --tw-grayscale: ;
        --tw-hue-rotate: ;
        --tw-invert: ;
        --tw-saturate: ;
        --tw-sepia: ;
        --tw-drop-shadow: ;
        --tw-backdrop-blur: ;
        --tw-backdrop-brightness: ;
        --tw-backdrop-contrast: ;
        --tw-backdrop-grayscale: ;
        --tw-backdrop-hue-rotate: ;
        --tw-backdrop-invert: ;
        --tw-backdrop-opacity: ;
        --tw-backdrop-saturate: ;
        --tw-backdrop-sepia: ;
        --tw-contain-size: ;
        --tw-contain-layout: ;
        --tw-contain-paint: ;
        --tw-contain-style:
    }

    ::backdrop {
        --tw-border-spacing-x: 0;
        --tw-border-spacing-y: 0;
        --tw-translate-x: 0;
        --tw-translate-y: 0;
        --tw-rotate: 0;
        --tw-skew-x: 0;
        --tw-skew-y: 0;
        --tw-scale-x: 1;
        --tw-scale-y: 1;
        --tw-pan-x: ;
        --tw-pan-y: ;
        --tw-pinch-zoom: ;
        --tw-scroll-snap-strictness: proximity;
        --tw-gradient-from-position: ;
        --tw-gradient-via-position: ;
        --tw-gradient-to-position: ;
        --tw-ordinal: ;
        --tw-slashed-zero: ;
        --tw-numeric-figure: ;
        --tw-numeric-spacing: ;
        --tw-numeric-fraction: ;
        --tw-ring-inset: ;
        --tw-ring-offset-width: 0px;
        --tw-ring-offset-color: #fff;
        --tw-ring-color: rgb(59 130 246 / 0.5);
        --tw-ring-offset-shadow: 0 0 #0000;
        --tw-ring-shadow: 0 0 #0000;
        --tw-shadow: 0 0 #0000;
        --tw-shadow-colored: 0 0 #0000;
        --tw-blur: ;
        --tw-brightness: ;
        --tw-contrast: ;
        --tw-grayscale: ;
        --tw-hue-rotate: ;
        --tw-invert: ;
        --tw-saturate: ;
        --tw-sepia: ;
        --tw-drop-shadow: ;
        --tw-backdrop-blur: ;
        --tw-backdrop-brightness: ;
        --tw-backdrop-contrast: ;
        --tw-backdrop-grayscale: ;
        --tw-backdrop-hue-rotate: ;
        --tw-backdrop-invert: ;
        --tw-backdrop-opacity: ;
        --tw-backdrop-saturate: ;
        --tw-backdrop-sepia: ;
        --tw-contain-size: ;
        --tw-contain-layout: ;
        --tw-contain-paint: ;
        --tw-contain-style:
    }

    .invisible {
        visibility: hidden
    }

    .absolute {
        position: absolute
    }

    .relative {
        position: relative
    }

    .sticky {
        position: sticky
    }

    .left-0 {
        left: 0px
    }

    .left-2 {
        left: 0.5rem
    }

    .right-0 {
        right: 0px
    }

    .right-2 {
        right: 0.5rem
    }

    .top-0 {
        top: 0px
    }

    .top-\[0\%\] {
        top: 0%
    }

    .top-\[35\%\] {
        top: 35%
    }

    .z-10 {
        z-index: 10
    }

    .z-50 {
        z-index: 50
    }

    .z-\[1000px\] {
        z-index: 1000px
    }

    .float-left {
        float: left
    }

    .mx-auto {
        margin-left: auto;
        margin-right: auto
    }

    .-ml-5 {
        margin-left: -1.25rem
    }

    .mb-4 {
        margin-bottom: 1rem
    }

    .ml-3 {
        margin-left: 0.75rem
    }

    .mr-2 {
        margin-right: 0.5rem
    }

    .mt-10 {
        margin-top: 2.5rem
    }

    .mt-12 {
        margin-top: 3rem
    }

    .mt-4 {
        margin-top: 1rem
    }

    .flex {
        display: flex
    }

    .hidden {
        display: none
    }

    .h-1 {
        height: 0.25rem
    }

    .h-10 {
        height: 2.5rem
    }

    .h-12 {
        height: 3rem
    }

    .h-20 {
        height: 5rem
    }

    .h-44 {
        height: 11rem
    }

    .h-6 {
        height: 1.5rem
    }

    .h-7 {
        height: 1.75rem
    }

    .h-8 {
        height: 2rem
    }

    .h-\[2px\] {
        height: 2px
    }

    .h-\[35vh\] {
        height: 35vh
    }

    .h-\[65\%\] {
        height: 65%
    }

    .h-auto {
        height: auto
    }

    .h-full {
        height: 100%
    }

    .w-1\/2 {
        width: 50%
    }

    .w-1\/3 {
        width: 33.333333%
    }

    .w-10 {
        width: 2.5rem
    }

    .w-4 {
        width: 1rem
    }

    .w-6 {
        width: 1.5rem
    }

    .w-7 {
        width: 1.75rem
    }

    .w-72 {
        width: 18rem
    }

    .w-8 {
        width: 2rem
    }

    .w-auto {
        width: auto
    }

    .w-full {
        width: 100%
    }

    .max-w-7xl {
        max-width: 80rem
    }

    .flex-1 {
        flex: 1 1 0%
    }

    .flex-shrink-0 {
        flex-shrink: 0
    }

    .-translate-y-10 {
        --tw-translate-y: -2.5rem;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .cursor-pointer {
        cursor: pointer
    }

    .flex-row {
        flex-direction: row
    }

    .flex-col {
        flex-direction: column
    }

    .flex-wrap {
        flex-wrap: wrap
    }

    .items-start {
        align-items: flex-start
    }

    .items-end {
        align-items: flex-end
    }

    .items-center {
        align-items: center
    }

    .justify-start {
        justify-content: flex-start
    }

    .justify-end {
        justify-content: flex-end
    }

    .justify-center {
        justify-content: center
    }

    .justify-between {
        justify-content: space-between
    }

    .justify-around {
        justify-content: space-around
    }

    .gap-2 {
        gap: 0.5rem
    }

    .gap-4 {
        gap: 1rem
    }

    .gap-x-10 {
        column-gap: 2.5rem
    }

    .gap-x-2 {
        column-gap: 0.5rem
    }

    .gap-x-4 {
        column-gap: 1rem
    }

    .gap-x-6 {
        column-gap: 1.5rem
    }

    .gap-y-10 {
        row-gap: 2.5rem
    }

    .gap-y-2 {
        row-gap: 0.5rem
    }

    .gap-y-4 {
        row-gap: 1rem
    }

    .gap-y-8 {
        row-gap: 2rem
    }

    .space-x-4> :not([hidden])~ :not([hidden]) {
        --tw-space-x-reverse: 0;
        margin-right: calc(1rem * var(--tw-space-x-reverse));
        margin-left: calc(1rem * calc(1 - var(--tw-space-x-reverse)))
    }

    .space-x-8> :not([hidden])~ :not([hidden]) {
        --tw-space-x-reverse: 0;
        margin-right: calc(2rem * var(--tw-space-x-reverse));
        margin-left: calc(2rem * calc(1 - var(--tw-space-x-reverse)))
    }

    .space-y-10> :not([hidden])~ :not([hidden]) {
        --tw-space-y-reverse: 0;
        margin-top: calc(2.5rem * calc(1 - var(--tw-space-y-reverse)));
        margin-bottom: calc(2.5rem * var(--tw-space-y-reverse))
    }

    .space-y-2> :not([hidden])~ :not([hidden]) {
        --tw-space-y-reverse: 0;
        margin-top: calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
        margin-bottom: calc(0.5rem * var(--tw-space-y-reverse))
    }

    .space-y-4> :not([hidden])~ :not([hidden]) {
        --tw-space-y-reverse: 0;
        margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
        margin-bottom: calc(1rem * var(--tw-space-y-reverse))
    }

    .overflow-hidden {
        overflow: hidden
    }

    .overflow-x-auto {
        overflow-x: auto
    }

    .truncate {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap
    }

    .rounded-full {
        border-radius: 9999px
    }

    .rounded-md {
        border-radius: 0.375rem
    }

    .rounded-b {
        border-bottom-right-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem
    }

    .rounded-t {
        border-top-left-radius: 0.25rem;
        border-top-right-radius: 0.25rem
    }

    .border-2 {
        border-width: 2px
    }

    .border-b-0 {
        border-bottom-width: 0px
    }

    .border-b-\[1px\] {
        border-bottom-width: 1px
    }

    .border-t {
        border-top-width: 1px
    }

    .border-t-2 {
        border-top-width: 2px
    }

    .border-google-green {
        --tw-border-opacity: 1;
        border-color: rgb(0 128 0 / var(--tw-border-opacity))
    }

    .border-slate-100 {
        --tw-border-opacity: 1;
        border-color: rgb(241 245 249 / var(--tw-border-opacity))
    }

    .border-slate-200 {
        --tw-border-opacity: 1;
        border-color: rgb(226 232 240 / var(--tw-border-opacity))
    }

    .border-slate-300 {
        --tw-border-opacity: 1;
        border-color: rgb(203 213 225 / var(--tw-border-opacity))
    }

    .border-white {
        --tw-border-opacity: 1;
        border-color: rgb(255 255 255 / var(--tw-border-opacity))
    }

    .bg-\[\#f1f1f1\] {
        --tw-bg-opacity: 1;
        background-color: rgb(241 241 241 / var(--tw-bg-opacity))
    }

    .bg-\[\#ff1f1f\] {
        --tw-bg-opacity: 1;
        background-color: rgb(255 31 31 / var(--tw-bg-opacity))
    }

    .bg-\[\#ff1f1f\]\/80 {
        background-color: rgb(255 31 31 / 0.8)
    }

    .bg-black\/50 {
        background-color: rgb(0 0 0 / 0.5)
    }

    .bg-black\/70 {
        background-color: rgb(0 0 0 / 0.7)
    }

    .bg-google-green {
        --tw-bg-opacity: 1;
        background-color: rgb(0 128 0 / var(--tw-bg-opacity))
    }

    .bg-google-green\/30 {
        background-color: rgb(0 128 0 / 0.3)
    }

    .bg-google-green\/50 {
        background-color: rgb(0 128 0 / 0.5)
    }

    .bg-google-green\/90 {
        background-color: rgb(0 128 0 / 0.9)
    }

    .bg-google-red {
        --tw-bg-opacity: 1;
        background-color: rgb(255 69 0 / var(--tw-bg-opacity))
    }

    .bg-sky-700 {
        --tw-bg-opacity: 1;
        background-color: rgb(3 105 161 / var(--tw-bg-opacity))
    }

    .bg-white {
        --tw-bg-opacity: 1;
        background-color: rgb(255 255 255 / var(--tw-bg-opacity))
    }

    .bg-\[url\(https\:\/\/lh3\.googleusercontent\.com\/pw\/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg\=w1080-h717-s-no-gm\?authuser\=0\)\] {
        background-image: url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)
    }

    .bg-cover {
        background-size: cover
    }

    .bg-bottom {
        background-position: bottom
    }

    .object-contain {
        object-fit: contain
    }

    .object-cover {
        object-fit: cover
    }

    .p-2 {
        padding: 0.5rem
    }

    .p-4 {
        padding: 1rem
    }

    .p-8 {
        padding: 2rem
    }

    .px-0 {
        padding-left: 0px;
        padding-right: 0px
    }

    .px-2 {
        padding-left: 0.5rem;
        padding-right: 0.5rem
    }

    .px-4 {
        padding-left: 1rem;
        padding-right: 1rem
    }

    .px-6 {
        padding-left: 1.5rem;
        padding-right: 1.5rem
    }

    .px-8 {
        padding-left: 2rem;
        padding-right: 2rem
    }

    .py-0 {
        padding-top: 0px;
        padding-bottom: 0px
    }

    .py-10 {
        padding-top: 2.5rem;
        padding-bottom: 2.5rem
    }

    .py-2 {
        padding-top: 0.5rem;
        padding-bottom: 0.5rem
    }

    .py-4 {
        padding-top: 1rem;
        padding-bottom: 1rem
    }

    .py-8 {
        padding-top: 2rem;
        padding-bottom: 2rem
    }

    .py-\[8\%\] {
        padding-top: 8%;
        padding-bottom: 8%
    }

    .pb-10 {
        padding-bottom: 2.5rem
    }

    .pb-4 {
        padding-bottom: 1rem
    }

    .pb-8 {
        padding-bottom: 2rem
    }

    .pr-2 {
        padding-right: 0.5rem
    }

    .pt-10 {
        padding-top: 2.5rem
    }

    .pt-16 {
        padding-top: 4rem
    }

    .pt-8 {
        padding-top: 2rem
    }

    .text-left {
        text-align: left
    }

    .text-center {
        text-align: center
    }

    .font-sans {
        font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"
    }

    .text-2xl {
        font-size: 1.5rem;
        line-height: 2rem
    }

    .text-3xl {
        font-size: 1.875rem;
        line-height: 2.25rem
    }

    .text-5xl {
        font-size: 3rem;
        line-height: 1
    }

    .text-xl {
        font-size: 1.25rem;
        line-height: 1.75rem
    }

    .text-xs {
        font-size: 0.75rem;
        line-height: 1rem
    }

    .font-bold {
        font-weight: 700
    }

    .font-light {
        font-weight: 300
    }

    .font-medium {
        font-weight: 500
    }

    .font-semibold {
        font-weight: 600
    }

    .uppercase {
        text-transform: uppercase
    }

    .text-\[\#f1f1f1\] {
        --tw-text-opacity: 1;
        color: rgb(241 241 241 / var(--tw-text-opacity))
    }

    .text-black {
        --tw-text-opacity: 1;
        color: rgb(0 0 0 / var(--tw-text-opacity))
    }

    .text-black\/50 {
        color: rgb(0 0 0 / 0.5)
    }

    .text-black\/80 {
        color: rgb(0 0 0 / 0.8)
    }

    .text-google-green {
        --tw-text-opacity: 1;
        color: rgb(0 128 0 / var(--tw-text-opacity))
    }

    .text-google-red {
        --tw-text-opacity: 1;
        color: rgb(255 69 0 / var(--tw-text-opacity))
    }

    .text-gray-400 {
        --tw-text-opacity: 1;
        color: rgb(156 163 175 / var(--tw-text-opacity))
    }

    .text-gray-500 {
        --tw-text-opacity: 1;
        color: rgb(107 114 128 / var(--tw-text-opacity))
    }

    .text-gray-700 {
        --tw-text-opacity: 1;
        color: rgb(55 65 81 / var(--tw-text-opacity))
    }

    .text-sky-700 {
        --tw-text-opacity: 1;
        color: rgb(3 105 161 / var(--tw-text-opacity))
    }

    .text-slate-500 {
        --tw-text-opacity: 1;
        color: rgb(100 116 139 / var(--tw-text-opacity))
    }

    .text-slate-600 {
        --tw-text-opacity: 1;
        color: rgb(71 85 105 / var(--tw-text-opacity))
    }

    .text-slate-700 {
        --tw-text-opacity: 1;
        color: rgb(51 65 85 / var(--tw-text-opacity))
    }

    .text-white {
        --tw-text-opacity: 1;
        color: rgb(255 255 255 / var(--tw-text-opacity))
    }

    .antialiased {
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale
    }

    .opacity-0 {
        opacity: 0
    }

    .shadow-lg {
        --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
        box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
    }

    .transition-all {
        transition-property: all;
        transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        transition-duration: 150ms
    }

    .transition-colors {
        transition-property: color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;
        transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
        transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;
        transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        transition-duration: 150ms
    }

    .duration-200 {
        transition-duration: 200ms
    }

    .hover\:-translate-x-1:hover {
        --tw-translate-x: -0.25rem;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .hover\:-translate-x-1\.5:hover {
        --tw-translate-x: -0.375rem;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .hover\:-translate-y-1:hover {
        --tw-translate-y: -0.25rem;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .hover\:-translate-y-1\.5:hover {
        --tw-translate-y: -0.375rem;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .hover\:border-\[\#ff1f1f\]\/80:hover {
        border-color: rgb(255 31 31 / 0.8)
    }

    .hover\:border-sky-700:hover {
        --tw-border-opacity: 1;
        border-color: rgb(3 105 161 / var(--tw-border-opacity))
    }

    .hover\:bg-black\/80:hover {
        background-color: rgb(0 0 0 / 0.8)
    }

    .hover\:bg-google-green\/80:hover {
        background-color: rgb(0 128 0 / 0.8)
    }

    .hover\:text-\[\#e1db2b\]:hover {
        --tw-text-opacity: 1;
        color: rgb(225 219 43 / var(--tw-text-opacity))
    }

    .hover\:text-google-blue:hover {
        color: blueksy
    }

    .hover\:text-google-red:hover {
        --tw-text-opacity: 1;
        color: rgb(255 69 0 / var(--tw-text-opacity))
    }

    .hover\:text-white:hover {
        --tw-text-opacity: 1;
        color: rgb(255 255 255 / var(--tw-text-opacity))
    }

    .hover\:shadow-xl:hover {
        --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
        --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
        box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
    }

    .hover\:shadow-black\/50:hover {
        --tw-shadow-color: rgb(0 0 0 / 0.5);
        --tw-shadow: var(--tw-shadow-colored)
    }

    .focus\:outline-none:focus {
        outline: 2px solid transparent;
        outline-offset: 2px
    }

    .group\/item:hover .group-hover\/item\:visible {
        visibility: visible
    }

    .group\/item:hover .group-hover\/item\:ml-0 {
        margin-left: 0px
    }

    .group\/item:hover .group-hover\/item\:block {
        display: block
    }

    .group\/item:hover .group-hover\/item\:translate-y-0 {
        --tw-translate-y: 0px;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .group\/item:hover .group-hover\/item\:opacity-100 {
        opacity: 1
    }

    @media (min-width: 640px) {
        .sm\:items-center {
            align-items: center
        }

        .sm\:justify-center {
            justify-content: center
        }
    }

    @media (min-width: 768px) {
        .md\:flex {
            display: flex
        }

        .md\:hidden {
            display: none
        }
    }

    @media (min-width: 1280px) {
        .xl\:-right-\[2\%\] {
            right: -2%
        }

        .xl\:left-\[0\%\] {
            left: 0%
        }

        .xl\:right-\[1\%\] {
            right: 1%
        }

        .xl\:top-\[5\.5\%\] {
            top: 5.5%
        }

        .xl\:mt-0 {
            margin-top: 0px
        }

        .xl\:mt-4 {
            margin-top: 1rem
        }

        .xl\:block {
            display: block
        }

        .xl\:flex {
            display: flex
        }

        .xl\:h-\[30vh\] {
            height: 30vh
        }

        .xl\:h-\[75\%\] {
            height: 75%
        }

        .xl\:w-1\/2 {
            width: 50%
        }

        .xl\:w-1\/6 {
            width: 16.666667%
        }

        .xl\:w-44 {
            width: 11rem
        }

        .xl\:w-80 {
            width: 20rem
        }

        .xl\:w-\[24\%\] {
            width: 24%
        }

        .xl\:w-\[70\%\] {
            width: 70%
        }

        .xl\:w-full {
            width: 100%
        }

        .xl\:flex-row {
            flex-direction: row
        }

        .xl\:flex-wrap {
            flex-wrap: wrap
        }

        .xl\:flex-nowrap {
            flex-wrap: nowrap
        }

        .xl\:items-start {
            align-items: flex-start
        }

        .xl\:justify-start {
            justify-content: flex-start
        }

        .xl\:gap-y-0 {
            row-gap: 0px
        }

        .xl\:overflow-x-hidden {
            overflow-x: hidden
        }

        .xl\:p-3 {
            padding: 0.75rem
        }

        .xl\:px-0 {
            padding-left: 0px;
            padding-right: 0px
        }

        .xl\:px-20 {
            padding-left: 5rem;
            padding-right: 5rem
        }

        .xl\:px-36 {
            padding-left: 9rem;
            padding-right: 9rem
        }

        .xl\:px-4 {
            padding-left: 1rem;
            padding-right: 1rem
        }

        .xl\:px-8 {
            padding-left: 2rem;
            padding-right: 2rem
        }

        .xl\:px-\[20\%\] {
            padding-left: 20%;
            padding-right: 20%
        }

        .xl\:px-\[5\%\] {
            padding-left: 5%;
            padding-right: 5%
        }

        .xl\:py-2 {
            padding-top: 0.5rem;
            padding-bottom: 0.5rem
        }

        .xl\:py-20 {
            padding-top: 5rem;
            padding-bottom: 5rem
        }

        .xl\:py-\[10\%\] {
            padding-top: 10%;
            padding-bottom: 10%
        }

        .xl\:pr-\[25\%\] {
            padding-right: 25%
        }

        .xl\:text-4xl {
            font-size: 2.25rem;
            line-height: 2.5rem
        }

        .xl\:text-6xl {
            font-size: 3.75rem;
            line-height: 1
        }

        .xl\:text-8xl {
            font-size: 6rem;
            line-height: 1
        }

        .xl\:text-lg {
            font-size: 1.125rem;
            line-height: 1.75rem
        }

        .xl\:text-sm {
            font-size: 0.875rem;
            line-height: 1.25rem
        }

        .xl\:text-xl {
            font-size: 1.25rem;
            line-height: 1.75rem
        }
    }

    @media (min-width: 1536px) {
        .\32xl\:h-\[30vh\] {
            height: 30vh
        }

        .\32xl\:w-72 {
            width: 18rem
        }

        .\32xl\:justify-center {
            justify-content: center
        }

        .\32xl\:px-0 {
            padding-left: 0px;
            padding-right: 0px
        }

        .\32xl\:px-72 {
            padding-left: 18rem;
            padding-right: 18rem
        }

        .\32xl\:px-\[10\%\] {
            padding-left: 10%;
            padding-right: 10%
        }

        .\32xl\:pl-0 {
            padding-left: 0px
        }
    }

    @media (prefers-color-scheme: dark) {
        .dark\:text-gray-700 {
            --tw-text-opacity: 1;
            color: rgb(55 65 81 / var(--tw-text-opacity))
        }

        .dark\:text-white {
            --tw-text-opacity: 1;
            color: rgb(255 255 255 / var(--tw-text-opacity))
        }
    }
</style>
<style>
    *,
    ::before,
    ::after {
        --tw-border-spacing-x: 0;
        --tw-border-spacing-y: 0;
        --tw-translate-x: 0;
        --tw-translate-y: 0;
        --tw-rotate: 0;
        --tw-skew-x: 0;
        --tw-skew-y: 0;
        --tw-scale-x: 1;
        --tw-scale-y: 1;
        --tw-pan-x: ;
        --tw-pan-y: ;
        --tw-pinch-zoom: ;
        --tw-scroll-snap-strictness: proximity;
        --tw-gradient-from-position: ;
        --tw-gradient-via-position: ;
        --tw-gradient-to-position: ;
        --tw-ordinal: ;
        --tw-slashed-zero: ;
        --tw-numeric-figure: ;
        --tw-numeric-spacing: ;
        --tw-numeric-fraction: ;
        --tw-ring-inset: ;
        --tw-ring-offset-width: 0px;
        --tw-ring-offset-color: #fff;
        --tw-ring-color: rgb(59 130 246 / 0.5);
        --tw-ring-offset-shadow: 0 0 #0000;
        --tw-ring-shadow: 0 0 #0000;
        --tw-shadow: 0 0 #0000;
        --tw-shadow-colored: 0 0 #0000;
        --tw-blur: ;
        --tw-brightness: ;
        --tw-contrast: ;
        --tw-grayscale: ;
        --tw-hue-rotate: ;
        --tw-invert: ;
        --tw-saturate: ;
        --tw-sepia: ;
        --tw-drop-shadow: ;
        --tw-backdrop-blur: ;
        --tw-backdrop-brightness: ;
        --tw-backdrop-contrast: ;
        --tw-backdrop-grayscale: ;
        --tw-backdrop-hue-rotate: ;
        --tw-backdrop-invert: ;
        --tw-backdrop-opacity: ;
        --tw-backdrop-saturate: ;
        --tw-backdrop-sepia: ;
        --tw-contain-size: ;
        --tw-contain-layout: ;
        --tw-contain-paint: ;
        --tw-contain-style:
    }

    ::backdrop {
        --tw-border-spacing-x: 0;
        --tw-border-spacing-y: 0;
        --tw-translate-x: 0;
        --tw-translate-y: 0;
        --tw-rotate: 0;
        --tw-skew-x: 0;
        --tw-skew-y: 0;
        --tw-scale-x: 1;
        --tw-scale-y: 1;
        --tw-pan-x: ;
        --tw-pan-y: ;
        --tw-pinch-zoom: ;
        --tw-scroll-snap-strictness: proximity;
        --tw-gradient-from-position: ;
        --tw-gradient-via-position: ;
        --tw-gradient-to-position: ;
        --tw-ordinal: ;
        --tw-slashed-zero: ;
        --tw-numeric-figure: ;
        --tw-numeric-spacing: ;
        --tw-numeric-fraction: ;
        --tw-ring-inset: ;
        --tw-ring-offset-width: 0px;
        --tw-ring-offset-color: #fff;
        --tw-ring-color: rgb(59 130 246 / 0.5);
        --tw-ring-offset-shadow: 0 0 #0000;
        --tw-ring-shadow: 0 0 #0000;
        --tw-shadow: 0 0 #0000;
        --tw-shadow-colored: 0 0 #0000;
        --tw-blur: ;
        --tw-brightness: ;
        --tw-contrast: ;
        --tw-grayscale: ;
        --tw-hue-rotate: ;
        --tw-invert: ;
        --tw-saturate: ;
        --tw-sepia: ;
        --tw-drop-shadow: ;
        --tw-backdrop-blur: ;
        --tw-backdrop-brightness: ;
        --tw-backdrop-contrast: ;
        --tw-backdrop-grayscale: ;
        --tw-backdrop-hue-rotate: ;
        --tw-backdrop-invert: ;
        --tw-backdrop-opacity: ;
        --tw-backdrop-saturate: ;
        --tw-backdrop-sepia: ;
        --tw-contain-size: ;
        --tw-contain-layout: ;
        --tw-contain-paint: ;
        --tw-contain-style:
    }

    /* ! tailwindcss v3.4.15 | MIT License | https://tailwindcss.com */
    *,
    ::after,
    ::before {
        box-sizing: border-box;
        border-width: 0;
        border-style: solid;
        border-color: #e5e7eb
    }

    ::after,
    ::before {
        --tw-content: ''
    }

    :host,
    html {
        line-height: 1.5;
        -webkit-text-size-adjust: 100%;
        -moz-tab-size: 4;
        tab-size: 4;
        font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
        font-feature-settings: normal;
        font-variation-settings: normal;
        -webkit-tap-highlight-color: transparent
    }

    body {
        margin: 0;
        line-height: inherit
    }

    hr {
        height: 0;
        color: inherit;
        border-top-width: 1px
    }

    abbr:where([title]) {
        -webkit-text-decoration: underline dotted;
        text-decoration: underline dotted
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        font-size: inherit;
        font-weight: inherit
    }

    a {
        color: inherit;
        text-decoration: inherit
    }

    b,
    strong {
        font-weight: bolder
    }

    code,
    kbd,
    pre,
    samp {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        font-feature-settings: normal;
        font-variation-settings: normal;
        font-size: 1em
    }

    small {
        font-size: 80%
    }

    sub,
    sup {
        font-size: 75%;
        line-height: 0;
        position: relative;
        vertical-align: baseline
    }

    sub {
        bottom: -.25em
    }

    sup {
        top: -.5em
    }

    table {
        text-indent: 0;
        border-color: inherit;
        border-collapse: collapse
    }

    button,
    input,
    optgroup,
    select,
    textarea {
        font-family: inherit;
        font-feature-settings: inherit;
        font-variation-settings: inherit;
        font-size: 100%;
        font-weight: inherit;
        line-height: inherit;
        letter-spacing: inherit;
        color: inherit;
        margin: 0;
        padding: 0
    }

    button,
    select {
        text-transform: none
    }

    button,
    input:where([type=button]),
    input:where([type=reset]),
    input:where([type=submit]) {
        -webkit-appearance: button;
        background-color: transparent;
        background-image: none
    }

    :-moz-focusring {
        outline: auto
    }

    :-moz-ui-invalid {
        box-shadow: none
    }

    progress {
        vertical-align: baseline
    }

    ::-webkit-inner-spin-button,
    ::-webkit-outer-spin-button {
        height: auto
    }

    [type=search] {
        -webkit-appearance: textfield;
        outline-offset: -2px
    }

    ::-webkit-search-decoration {
        -webkit-appearance: none
    }

    ::-webkit-file-upload-button {
        -webkit-appearance: button;
        font: inherit
    }

    summary {
        display: list-item
    }

    blockquote,
    dd,
    dl,
    figure,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    hr,
    p,
    pre {
        margin: 0
    }

    fieldset {
        margin: 0;
        padding: 0
    }

    legend {
        padding: 0
    }

    menu,
    ol,
    ul {
        list-style: none;
        margin: 0;
        padding: 0
    }

    dialog {
        padding: 0
    }

    textarea {
        resize: vertical
    }

    input::placeholder,
    textarea::placeholder {
        opacity: 1;
        color: #9ca3af
    }

    [role=button],
    button {
        cursor: pointer
    }

    :disabled {
        cursor: default
    }

    audio,
    canvas,
    embed,
    iframe,
    img,
    object,
    svg,
    video {
        display: block;
        vertical-align: middle
    }

    img,
    video {
        max-width: 100%;
        height: auto
    }

    [hidden]:where(:not([hidden=until-found])) {
        display: none
    }

    .invisible {
        visibility: hidden
    }

    .absolute {
        position: absolute
    }

    .relative {
        position: relative
    }

    .sticky {
        position: sticky
    }

    .left-0 {
        left: 0px
    }

    .left-2 {
        left: 0.5rem
    }

    .right-0 {
        right: 0px
    }

    .right-2 {
        right: 0.5rem
    }

    .top-0 {
        top: 0px
    }

    .top-\[0\%\] {
        top: 0%
    }

    .top-\[35\%\] {
        top: 35%
    }

    .z-10 {
        z-index: 10
    }

    .z-50 {
        z-index: 50
    }

    .z-\[1000px\] {
        z-index: 1000px
    }

    .float-left {
        float: left
    }

    .mx-auto {
        margin-left: auto;
        margin-right: auto
    }

    .-ml-5 {
        margin-left: -1.25rem
    }

    .mb-4 {
        margin-bottom: 1rem
    }

    .ml-3 {
        margin-left: 0.75rem
    }

    .mr-2 {
        margin-right: 0.5rem
    }

    .mt-10 {
        margin-top: 2.5rem
    }

    .mt-12 {
        margin-top: 3rem
    }

    .mt-4 {
        margin-top: 1rem
    }

    .flex {
        display: flex
    }

    .hidden {
        display: none
    }

    .h-1 {
        height: 0.25rem
    }

    .h-10 {
        height: 2.5rem
    }

    .h-12 {
        height: 3rem
    }

    .h-20 {
        height: 5rem
    }

    .h-44 {
        height: 11rem
    }

    .h-6 {
        height: 1.5rem
    }

    .h-7 {
        height: 1.75rem
    }

    .h-8 {
        height: 2rem
    }

    .h-\[2px\] {
        height: 2px
    }

    .h-\[35vh\] {
        height: 35vh
    }

    .h-\[65\%\] {
        height: 65%
    }

    .h-auto {
        height: auto
    }

    .h-full {
        height: 100%
    }

    .w-1\/2 {
        width: 50%
    }

    .w-1\/3 {
        width: 33.333333%
    }

    .w-10 {
        width: 2.5rem
    }

    .w-4 {
        width: 1rem
    }

    .w-6 {
        width: 1.5rem
    }

    .w-7 {
        width: 1.75rem
    }

    .w-72 {
        width: 18rem
    }

    .w-8 {
        width: 2rem
    }

    .w-auto {
        width: auto
    }

    .w-full {
        width: 100%
    }

    .max-w-7xl {
        max-width: 80rem
    }

    .flex-1 {
        flex: 1 1 0%
    }

    .flex-shrink-0 {
        flex-shrink: 0
    }

    .-translate-y-10 {
        --tw-translate-y: -2.5rem;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .cursor-pointer {
        cursor: pointer
    }

    .flex-row {
        flex-direction: row
    }

    .flex-col {
        flex-direction: column
    }

    .flex-wrap {
        flex-wrap: wrap
    }

    .items-start {
        align-items: flex-start
    }

    .items-end {
        align-items: flex-end
    }

    .items-center {
        align-items: center
    }

    .justify-start {
        justify-content: flex-start
    }

    .justify-end {
        justify-content: flex-end
    }

    .justify-center {
        justify-content: center
    }

    .justify-between {
        justify-content: space-between
    }

    .justify-around {
        justify-content: space-around
    }

    .gap-2 {
        gap: 0.5rem
    }

    .gap-4 {
        gap: 1rem
    }

    .gap-x-10 {
        column-gap: 2.5rem
    }

    .gap-x-2 {
        column-gap: 0.5rem
    }

    .gap-x-4 {
        column-gap: 1rem
    }

    .gap-x-6 {
        column-gap: 1.5rem
    }

    .gap-y-10 {
        row-gap: 2.5rem
    }

    .gap-y-2 {
        row-gap: 0.5rem
    }

    .gap-y-4 {
        row-gap: 1rem
    }

    .gap-y-8 {
        row-gap: 2rem
    }

    .space-x-4> :not([hidden])~ :not([hidden]) {
        --tw-space-x-reverse: 0;
        margin-right: calc(1rem * var(--tw-space-x-reverse));
        margin-left: calc(1rem * calc(1 - var(--tw-space-x-reverse)))
    }

    .space-x-8> :not([hidden])~ :not([hidden]) {
        --tw-space-x-reverse: 0;
        margin-right: calc(2rem * var(--tw-space-x-reverse));
        margin-left: calc(2rem * calc(1 - var(--tw-space-x-reverse)))
    }

    .space-y-10> :not([hidden])~ :not([hidden]) {
        --tw-space-y-reverse: 0;
        margin-top: calc(2.5rem * calc(1 - var(--tw-space-y-reverse)));
        margin-bottom: calc(2.5rem * var(--tw-space-y-reverse))
    }

    .space-y-2> :not([hidden])~ :not([hidden]) {
        --tw-space-y-reverse: 0;
        margin-top: calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
        margin-bottom: calc(0.5rem * var(--tw-space-y-reverse))
    }

    .space-y-4> :not([hidden])~ :not([hidden]) {
        --tw-space-y-reverse: 0;
        margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
        margin-bottom: calc(1rem * var(--tw-space-y-reverse))
    }

    .overflow-hidden {
        overflow: hidden
    }

    .overflow-x-auto {
        overflow-x: auto
    }

    .truncate {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap
    }

    .rounded-full {
        border-radius: 9999px
    }

    .rounded-md {
        border-radius: 0.375rem
    }

    .rounded-b {
        border-bottom-right-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem
    }

    .rounded-t {
        border-top-left-radius: 0.25rem;
        border-top-right-radius: 0.25rem
    }

    .border-2 {
        border-width: 2px
    }

    .border-b-0 {
        border-bottom-width: 0px
    }

    .border-b-\[1px\] {
        border-bottom-width: 1px
    }

    .border-t {
        border-top-width: 1px
    }

    .border-t-2 {
        border-top-width: 2px
    }

    .border-google-green {
        --tw-border-opacity: 1;
        border-color: rgb(0 128 0 / var(--tw-border-opacity, 1))
    }

    .border-slate-100 {
        --tw-border-opacity: 1;
        border-color: rgb(241 245 249 / var(--tw-border-opacity, 1))
    }

    .border-slate-200 {
        --tw-border-opacity: 1;
        border-color: rgb(226 232 240 / var(--tw-border-opacity, 1))
    }

    .border-slate-300 {
        --tw-border-opacity: 1;
        border-color: rgb(203 213 225 / var(--tw-border-opacity, 1))
    }

    .border-white {
        --tw-border-opacity: 1;
        border-color: rgb(255 255 255 / var(--tw-border-opacity, 1))
    }

    .bg-\[\#f1f1f1\] {
        --tw-bg-opacity: 1;
        background-color: rgb(241 241 241 / var(--tw-bg-opacity, 1))
    }

    .bg-\[\#ff1f1f\] {
        --tw-bg-opacity: 1;
        background-color: rgb(255 31 31 / var(--tw-bg-opacity, 1))
    }

    .bg-\[\#ff1f1f\]\/80 {
        background-color: rgb(255 31 31 / 0.8)
    }

    .bg-black\/50 {
        background-color: rgb(0 0 0 / 0.5)
    }

    .bg-black\/70 {
        background-color: rgb(0 0 0 / 0.7)
    }

    .bg-google-green {
        --tw-bg-opacity: 1;
        background-color: rgb(0 128 0 / var(--tw-bg-opacity, 1))
    }

    .bg-google-green\/30 {
        background-color: rgb(0 128 0 / 0.3)
    }

    .bg-google-green\/50 {
        background-color: rgb(0 128 0 / 0.5)
    }

    .bg-google-green\/90 {
        background-color: rgb(0 128 0 / 0.9)
    }

    .bg-google-red {
        --tw-bg-opacity: 1;
        background-color: rgb(255 69 0 / var(--tw-bg-opacity, 1))
    }

    .bg-sky-700 {
        --tw-bg-opacity: 1;
        background-color: rgb(3 105 161 / var(--tw-bg-opacity, 1))
    }

    .bg-white {
        --tw-bg-opacity: 1;
        background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1))
    }

    .bg-\[url\(https\:\/\/lh3\.googleusercontent\.com\/pw\/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg\=w1080-h717-s-no-gm\?authuser\=0\)\] {
        background-image: url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)
    }

    .bg-cover {
        background-size: cover
    }

    .bg-bottom {
        background-position: bottom
    }

    .object-contain {
        object-fit: contain
    }

    .object-cover {
        object-fit: cover
    }

    .p-2 {
        padding: 0.5rem
    }

    .p-4 {
        padding: 1rem
    }

    .p-8 {
        padding: 2rem
    }

    .px-0 {
        padding-left: 0px;
        padding-right: 0px
    }

    .px-2 {
        padding-left: 0.5rem;
        padding-right: 0.5rem
    }

    .px-4 {
        padding-left: 1rem;
        padding-right: 1rem
    }

    .px-6 {
        padding-left: 1.5rem;
        padding-right: 1.5rem
    }

    .px-8 {
        padding-left: 2rem;
        padding-right: 2rem
    }

    .py-0 {
        padding-top: 0px;
        padding-bottom: 0px
    }

    .py-10 {
        padding-top: 2.5rem;
        padding-bottom: 2.5rem
    }

    .py-2 {
        padding-top: 0.5rem;
        padding-bottom: 0.5rem
    }

    .py-4 {
        padding-top: 1rem;
        padding-bottom: 1rem
    }

    .py-8 {
        padding-top: 2rem;
        padding-bottom: 2rem
    }

    .py-\[8\%\] {
        padding-top: 8%;
        padding-bottom: 8%
    }

    .pb-10 {
        padding-bottom: 2.5rem
    }

    .pb-4 {
        padding-bottom: 1rem
    }

    .pb-8 {
        padding-bottom: 2rem
    }

    .pr-2 {
        padding-right: 0.5rem
    }

    .pt-10 {
        padding-top: 2.5rem
    }

    .pt-16 {
        padding-top: 4rem
    }

    .pt-8 {
        padding-top: 2rem
    }

    .text-left {
        text-align: left
    }

    .text-center {
        text-align: center
    }

    .font-sans {
        font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"
    }

    .text-2xl {
        font-size: 1.5rem;
        line-height: 2rem
    }

    .text-3xl {
        font-size: 1.875rem;
        line-height: 2.25rem
    }

    .text-5xl {
        font-size: 3rem;
        line-height: 1
    }

    .text-xl {
        font-size: 1.25rem;
        line-height: 1.75rem
    }

    .text-xs {
        font-size: 0.75rem;
        line-height: 1rem
    }

    .font-bold {
        font-weight: 700
    }

    .font-light {
        font-weight: 300
    }

    .font-medium {
        font-weight: 500
    }

    .font-semibold {
        font-weight: 600
    }

    .uppercase {
        text-transform: uppercase
    }

    .text-\[\#f1f1f1\] {
        --tw-text-opacity: 1;
        color: rgb(241 241 241 / var(--tw-text-opacity, 1))
    }

    .text-black {
        --tw-text-opacity: 1;
        color: rgb(0 0 0 / var(--tw-text-opacity, 1))
    }

    .text-black\/50 {
        color: rgb(0 0 0 / 0.5)
    }

    .text-black\/80 {
        color: rgb(0 0 0 / 0.8)
    }

    .text-google-green {
        --tw-text-opacity: 1;
        color: rgb(0 128 0 / var(--tw-text-opacity, 1))
    }

    .text-google-red {
        --tw-text-opacity: 1;
        color: rgb(255 69 0 / var(--tw-text-opacity, 1))
    }

    .text-gray-400 {
        --tw-text-opacity: 1;
        color: rgb(156 163 175 / var(--tw-text-opacity, 1))
    }

    .text-gray-500 {
        --tw-text-opacity: 1;
        color: rgb(107 114 128 / var(--tw-text-opacity, 1))
    }

    .text-gray-700 {
        --tw-text-opacity: 1;
        color: rgb(55 65 81 / var(--tw-text-opacity, 1))
    }

    .text-sky-700 {
        --tw-text-opacity: 1;
        color: rgb(3 105 161 / var(--tw-text-opacity, 1))
    }

    .text-slate-500 {
        --tw-text-opacity: 1;
        color: rgb(100 116 139 / var(--tw-text-opacity, 1))
    }

    .text-slate-600 {
        --tw-text-opacity: 1;
        color: rgb(71 85 105 / var(--tw-text-opacity, 1))
    }

    .text-slate-700 {
        --tw-text-opacity: 1;
        color: rgb(51 65 85 / var(--tw-text-opacity, 1))
    }

    .text-white {
        --tw-text-opacity: 1;
        color: rgb(255 255 255 / var(--tw-text-opacity, 1))
    }

    .antialiased {
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale
    }

    .opacity-0 {
        opacity: 0
    }

    .shadow-lg {
        --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
        box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
    }

    .transition-all {
        transition-property: all;
        transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        transition-duration: 150ms
    }

    .transition-colors {
        transition-property: color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;
        transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
        transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;
        transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        transition-duration: 150ms
    }

    .duration-200 {
        transition-duration: 200ms
    }

    .hover\:-translate-x-1\.5:hover {
        --tw-translate-x: -0.375rem;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .hover\:-translate-y-1\.5:hover {
        --tw-translate-y: -0.375rem;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .hover\:border-\[\#ff1f1f\]\/80:hover {
        border-color: rgb(255 31 31 / 0.8)
    }

    .hover\:border-sky-700:hover {
        --tw-border-opacity: 1;
        border-color: rgb(3 105 161 / var(--tw-border-opacity, 1))
    }

    .hover\:bg-black\/80:hover {
        background-color: rgb(0 0 0 / 0.8)
    }

    .hover\:bg-google-green\/80:hover {
        background-color: rgb(0 128 0 / 0.8)
    }

    .hover\:text-\[\#e1db2b\]:hover {
        --tw-text-opacity: 1;
        color: rgb(225 219 43 / var(--tw-text-opacity, 1))
    }

    .hover\:text-google-blue:hover {
        color: blueksy
    }

    .hover\:text-google-red:hover {
        --tw-text-opacity: 1;
        color: rgb(255 69 0 / var(--tw-text-opacity, 1))
    }

    .hover\:text-white:hover {
        --tw-text-opacity: 1;
        color: rgb(255 255 255 / var(--tw-text-opacity, 1))
    }

    .hover\:shadow-xl:hover {
        --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
        --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
        box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
    }

    .hover\:shadow-black\/50:hover {
        --tw-shadow-color: rgb(0 0 0 / 0.5);
        --tw-shadow: var(--tw-shadow-colored)
    }

    .focus\:outline-none:focus {
        outline: 2px solid transparent;
        outline-offset: 2px
    }

    .group\/item:hover .group-hover\/item\:visible {
        visibility: visible
    }

    .group\/item:hover .group-hover\/item\:ml-0 {
        margin-left: 0px
    }

    .group\/item:hover .group-hover\/item\:block {
        display: block
    }

    .group\/item:hover .group-hover\/item\:translate-y-0 {
        --tw-translate-y: 0px;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .group\/item:hover .group-hover\/item\:opacity-100 {
        opacity: 1
    }

    @media (min-width: 640px) {
        .sm\:items-center {
            align-items: center
        }

        .sm\:justify-center {
            justify-content: center
        }
    }

    @media (min-width: 768px) {
        .md\:flex {
            display: flex
        }

        .md\:hidden {
            display: none
        }
    }

    @media (min-width: 1280px) {
        .xl\:-right-\[2\%\] {
            right: -2%
        }

        .xl\:left-\[0\%\] {
            left: 0%
        }

        .xl\:right-\[1\%\] {
            right: 1%
        }

        .xl\:top-\[5\.5\%\] {
            top: 5.5%
        }

        .xl\:mt-0 {
            margin-top: 0px
        }

        .xl\:mt-4 {
            margin-top: 1rem
        }

        .xl\:block {
            display: block
        }

        .xl\:flex {
            display: flex
        }

        .xl\:h-\[30vh\] {
            height: 30vh
        }

        .xl\:h-\[75\%\] {
            height: 75%
        }

        .xl\:w-1\/2 {
            width: 50%
        }

        .xl\:w-1\/6 {
            width: 16.666667%
        }

        .xl\:w-44 {
            width: 11rem
        }

        .xl\:w-80 {
            width: 20rem
        }

        .xl\:w-\[24\%\] {
            width: 24%
        }

        .xl\:w-\[70\%\] {
            width: 70%
        }

        .xl\:w-full {
            width: 100%
        }

        .xl\:flex-row {
            flex-direction: row
        }

        .xl\:flex-wrap {
            flex-wrap: wrap
        }

        .xl\:flex-nowrap {
            flex-wrap: nowrap
        }

        .xl\:items-start {
            align-items: flex-start
        }

        .xl\:justify-start {
            justify-content: flex-start
        }

        .xl\:gap-y-0 {
            row-gap: 0px
        }

        .xl\:overflow-x-hidden {
            overflow-x: hidden
        }

        .xl\:p-3 {
            padding: 0.75rem
        }

        .xl\:px-0 {
            padding-left: 0px;
            padding-right: 0px
        }

        .xl\:px-20 {
            padding-left: 5rem;
            padding-right: 5rem
        }

        .xl\:px-36 {
            padding-left: 9rem;
            padding-right: 9rem
        }

        .xl\:px-4 {
            padding-left: 1rem;
            padding-right: 1rem
        }

        .xl\:px-8 {
            padding-left: 2rem;
            padding-right: 2rem
        }

        .xl\:px-\[20\%\] {
            padding-left: 20%;
            padding-right: 20%
        }

        .xl\:px-\[5\%\] {
            padding-left: 5%;
            padding-right: 5%
        }

        .xl\:py-2 {
            padding-top: 0.5rem;
            padding-bottom: 0.5rem
        }

        .xl\:py-20 {
            padding-top: 5rem;
            padding-bottom: 5rem
        }

        .xl\:py-\[10\%\] {
            padding-top: 10%;
            padding-bottom: 10%
        }

        .xl\:pr-\[25\%\] {
            padding-right: 25%
        }

        .xl\:text-4xl {
            font-size: 2.25rem;
            line-height: 2.5rem
        }

        .xl\:text-6xl {
            font-size: 3.75rem;
            line-height: 1
        }

        .xl\:text-8xl {
            font-size: 6rem;
            line-height: 1
        }

        .xl\:text-lg {
            font-size: 1.125rem;
            line-height: 1.75rem
        }

        .xl\:text-sm {
            font-size: 0.875rem;
            line-height: 1.25rem
        }

        .xl\:text-xl {
            font-size: 1.25rem;
            line-height: 1.75rem
        }
    }

    @media (min-width: 1536px) {
        .\32xl\:h-\[30vh\] {
            height: 30vh
        }

        .\32xl\:w-72 {
            width: 18rem
        }

        .\32xl\:justify-center {
            justify-content: center
        }

        .\32xl\:px-0 {
            padding-left: 0px;
            padding-right: 0px
        }

        .\32xl\:px-72 {
            padding-left: 18rem;
            padding-right: 18rem
        }

        .\32xl\:px-\[10\%\] {
            padding-left: 10%;
            padding-right: 10%
        }

        .\32xl\:pl-0 {
            padding-left: 0px
        }
    }

    @media (prefers-color-scheme: dark) {
        .dark\:text-gray-700 {
            --tw-text-opacity: 1;
            color: rgb(55 65 81 / var(--tw-text-opacity, 1))
        }

        .dark\:text-white {
            --tw-text-opacity: 1;
            color: rgb(255 255 255 / var(--tw-text-opacity, 1))
        }
    }
</style>
<script src="chrome-extension://ojaffphbffmdaicdkahnmihipclmepok/static/js/workers.min.js"></script>