<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @isset($page)
        <title>{{ $page->title }}</title>
    @endisset
    @include('web.scripts.head')
</head>

<body class="font-sans antialiased bg-white">

    @include('web.components.header')

    @if(isset($page))
        @include('web.components.head_page')
    @else
        @yield('page')
    @endif

    @include('web.components.footer')
    @include('web.scripts.footer')
</body>

</html>
