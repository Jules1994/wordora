import { AxiosInstance } from 'axios';
import { v4 as uuidv4 } from 'uuid'; // Pour des IDs uniques

export class Database {
  private client: AxiosInstance;

  constructor(client: AxiosInstance) {
    this.client = client;
  }

  async createDocument(collection: string, id: string, data: any) {
    const response = await this.client.post(`/${collection}`, { id, ...data });
    return response.data;
  }

  async getDocument(collection: string, id: string) {
    const response = await this.client.get(`/${collection}/${id}`);
    return response.data;
  }

  async getDocuments(collection: string) {
    const response = await this.client.get(`/${collection}`);
    return response.data;
  }

  async updateDocument(collection: string, id: string, data: any) {
    const response = await this.client.put(`/${collection}/${id}`, data);
    return response.data;
  }

  async deleteDocument(collection: string, id: string) {
    const response = await this.client.delete(`/${collection}/${id}`);
    return response.data;
  }
}

export default Database;