import { AxiosInstance } from 'axios';

export class Storage {
  private client: AxiosInstance;

  constructor(client: AxiosInstance) {
    this.client = client;
  }

  // Create a new bucket
  async createBucket(name: string, description?: string): Promise<any> {
    const response = await this.client.post('/storage/buckets', { name, description });
    return response.data;
  }

  // Upload a file to a specific bucket
  async uploadFile(bucketName: string, file: File): Promise<any> {
    const formData = new FormData();
    formData.append('file', file);

    const response = await this.client.post(`/storage/buckets/${bucketName}/files`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  }

  // List all files in a bucket
  async listFiles(bucketName: string): Promise<any> {
    const response = await this.client.get(`/storage/buckets/${bucketName}/files`);
    return response.data;
  }
  
  async listFilesByExtension(bucketName: string, extension?: string): Promise<any> {
    const response = await this.client.get(`/storage/buckets/${bucketName}/files/filter`, {
      params: { extension },
    });
    return response.data;
  }

  // Delete a file from a bucket
  async deleteFile(bucketName: string, fileName: string): Promise<any> {
    const response = await this.client.delete(`/storage/buckets/${bucketName}/files/${fileName}`);
    return response.data;
  }
}

export default Storage;