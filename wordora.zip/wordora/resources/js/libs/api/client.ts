import axios, { AxiosInstance } from 'axios';

export class HttpClient {
  private client: AxiosInstance;

  constructor(baseURL: string, apiToken: string | null = null) {

    const authorization = apiToken ? `Bearer ${apiToken}`: null
    this.client = axios.create({
      baseURL,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authorization,  // Ajout du token dans les en-têtes
      },
    });
  }

  // Cette méthode permet de mettre à jour le token si nécessaire
  public setApiToken(token: string): void {
    this.client.defaults.headers['Authorization'] = `Bearer ${token}`;
  }

  public getClient(): AxiosInstance {
    return this.client;
  }
}

export default HttpClient;