import { AxiosInstance } from 'axios';

export class Account {
  private client: AxiosInstance;

  constructor(client: AxiosInstance) {
    this.client = client;
  }

  // Register a new user
  async createAccount(email: string, password: string, name: string): Promise<any> {
    const response = await this.client.post(`/account/register`, {
      email,
      password,
      name,
    });
    return response.data;
  }

  // Login a user
  async login(email: string, password: string): Promise<any> {
    const response = await this.client.post(`/account/login`, {
      email,
      password,
    });
    return response.data;
  }

  // Get current user
  async getCurrentUser(): Promise<any> {
    const response = await this.client.get(`/account`);
    return response.data;
  }

  // Logout a user
  async logout(): Promise<void> {
    await this.client.post(`/account/logout`);
  }
  
}

export default Account;