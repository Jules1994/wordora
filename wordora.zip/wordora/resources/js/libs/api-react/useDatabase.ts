import { useClient } from './context';

export const useDatabase = () => {
  const { database } = useClient();
  return {
    createDocument: database.createDocument.bind(database),
    getDocuments: database.getDocuments.bind(database),
    deleteDocument: database.deleteDocument.bind(database),
  };
};