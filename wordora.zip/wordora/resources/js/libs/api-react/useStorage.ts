import { useClient } from './context';

export const useStorage = () => {
  const { storage } = useClient();
  return {
    createBucket: storage.createBucket.bind(storage),
    uploadFile: storage.uploadFile.bind(storage),
    listFiles: storage.listFiles.bind(storage),
    listFilesByExtension: storage.listFilesByExtension.bind(storage),
    deleteFile: storage.deleteFile.bind(storage),
  };
};