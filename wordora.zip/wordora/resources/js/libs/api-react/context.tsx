import React from 'react';
import { HttpClient, Account, Database, Storage }  from "../api"

// Définition des types pour le contexte
interface APIContextType {
  storage: Storage;
  account: Account;
  database: Database;
}

// Contexte principal de l'application
const APIContext = React.createContext < APIContextType | undefined > (undefined);

// Client API
const httpClient = new HttpClient('http://localhost:8000/api');

// Instances des classes
const storage = new Storage(httpClient.getClient());
const account = new Account(httpClient.getClient());
const database = new Database(httpClient.getClient());

// Provider pour fournir les services via le contexte
export const AppProvider = ({ children }) => {
  return (
    <APIContext.Provider value={{ database, account, storage }}>
      {children}
    </APIContext.Provider>
  );
};

// Hook personnalisé pour utiliser le contexte
export const useClient = (): APIContextType => {
  const context = React.useContext(APIContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};