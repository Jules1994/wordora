import { useClient } from './context';

export const useAccount = () => {
  const { account } = useClient();
  return {
    createAccount: account.createAccount.bind(account),
    login: account.login.bind(account),
    getAccount: account.getCurrentUser.bind(account),
    logout: account.logout.bind(account),
  };
};