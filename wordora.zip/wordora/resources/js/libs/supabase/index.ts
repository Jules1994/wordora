/* eslint-disable prettier/prettier */
import React from "react"
import { router } from '@inertiajs/react'
import { createClient, Session } from '@supabase/supabase-js'

const supabaseUrl = 'https://nxcuasvdtotmacfqatee.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im54Y3Vhc3ZkdG90bWFjZnFhdGVlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjA0NDU1ODgsImV4cCI6MjAzNjAyMTU4OH0.OSJFFZt7lWbKVJUQSG_ucBw8QZS_A3o5H9Nq5wx6P_4'
export const client = createClient(supabaseUrl, supabaseKey)

export const useSession = ()=> {

    const [session , setSession] = React.useState<Session | null>(null)
    React.useEffect(()=> {

        (async()=> {
            const { data, error } = await client.auth.getSession();
            if(error) {
                alert(error.message)
                setSession(null)
            }else{
                setSession(data.session)
            }
        })()
    }, [])

    return  { session }
}

export const signInWithOAuth = async(provider, callable)=>  {

    let { data, error } = await client.auth.signInWithOAuth({ provider })
    if(error) {
        callable({ error })
        return
    }

    callable({ data })
}

export const signInWithEmailPassword = async({ email, password }, callable)=>  {

    let { data, error } = await client.auth.signInWithPassword({ email, password })

    if(error) {
        callable({ error })
        return
    }

    callable({ data })
}

export const signUpWithEmailPassword = async({ email, password }, callable)=>  {

    let { data, error } = await client.auth.signUp({ email, password })

    if(error) {
        callable({ error })
        return
    }

    callable({ data })
}

export const signInPhoneEmailOtp = async({ email, phone = undefined }, callable)=>  {

    var params: any = { email }
    if(phone !== undefined) {
        params = { phone }
    }

    let { data, error } = await client.auth.signInWithOtp(params)

    if(error) {
        callable({ error })
        return
    }

    callable({ data })
}

export const verifyOtp = async({ email, token }, callable)=>  {

    let { data, error } = await client.auth.verifyOtp({ email, token, type: 'email' })
    if(error) {
        callable({ error })
        return
    }

    callable({ data })
}

export type SignOutInterface = undefined | Function
export const signOut = async (callable: SignOutInterface )=> {
    let { error } = await client.auth.signOut()
    if(error) {
        if(callable) {
            callable({ error })
        }
        return
    }
    router.visit("/")
}

export const inviteUserByEmail = async({ email }, callable)=>  {

    
    let { data, error } = await client.auth.admin.inviteUserByEmail(email)
    if(error) {
        callable({ error })
        return
    }

    callable({ data })
}

export const resetPasswordForEmail = async({ email }, callable)=>  {

    let { data, error } = await client.auth.resetPasswordForEmail(email)
    if(error) {
        callable({ error })
        return
    }

    callable({ data })
}
     