/* eslint-disable prettier/prettier */
import React from 'react'
import { Head, Link } from '@inertiajs/react'

const NAVS = [

    {
        items: [
            {
                key: "dashboard", link: "", text: "Dashboard", icon:
                    <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6.025A7.5 7.5 0 1 0 17.975 14H10V6.025Z" />
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.5 3c-.169 0-.334.014-.5.025V11h7.975c.011-.166.025-.331.025-.5A7.5 7.5 0 0 0 13.5 3Z" />
                    </svg>

            },

            /*{
                key: "integration", link: "integration", text: "Integration", icon:
                    <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m8 8-4 4 4 4m8 0 4-4-4-4m-2-3-4 14" />
                    </svg>
            },*/

        ]
    },

    {
        items: [

            {
                key: "pages", link: "pages", text: "Pages", icon:
                    <svg className="w-6 h-6 hite" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m14.304 4.844 2.852 2.852M7 7H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1v-4.5m2.409-9.91a2.017 2.017 0 0 1 0 2.853l-6.844 6.844L8 14l.713-3.565 6.844-6.844a2.015 2.015 0 0 1 2.852 0Z" />
                    </svg>

            },
            {
                key: "posts", link: "posts", text: "Posts", icon:
                    <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="M5 7h14M5 12h14M5 17h10" />
                    </svg>
            },

            {
                key: "medias", link: "medias", text: "Medias", icon:
                    <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M4 18V8a1 1 0 0 1 1-1h1.5l1.707-1.707A1 1 0 0 1 8.914 5h6.172a1 1 0 0 1 .707.293L17.5 7H19a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z" />
                        <path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                    </svg>

            },

            {
                key: "menu", link: "menus", text: "Menus", icon:
                    <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="M20 6H10m0 0a2 2 0 1 0-4 0m4 0a2 2 0 1 1-4 0m0 0H4m16 6h-2m0 0a2 2 0 1 0-4 0m4 0a2 2 0 1 1-4 0m0 0H4m16 6H10m0 0a2 2 0 1 0-4 0m4 0a2 2 0 1 1-4 0m0 0H4" />
                    </svg>
            },

            {
                key: "comments", link: "comments", text: "Comments", icon:
                    <svg className="w-6 h-6 hite" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17h6l3 3v-3h2V9h-2M4 4h11v8H9l-3 3v-3H4V4Z" />
                    </svg>
            },

        ]
    },

    {
        items: [
            {
                key: "themes", link: "themes", text: "Themes", icon:
                    <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16.153 19 21 12l-4.847-7H3l4.848 7L3 19h13.153Z" />
                    </svg>
            },

            {
                key: "plugins", link: "plugins", text: "Extensions", icon:
                    <svg className="w-6 h-6hite" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="M7.926 10.898 15 7.727m-7.074 5.39L15 16.29M8 12a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Zm12 5.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Zm0-11a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Z" />
                    </svg>

            },

            {
                key: "user", link: "user", text: "Compte", icon:
                    <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeWidth="2" d="M7 17v1a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1a3 3 0 0 0-3-3h-4a3 3 0 0 0-3 3Zm8-9a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                    </svg>

            },
        ]
    },

    {
        items: [
            {
                key: "plugins", link: "plugins", text: "lugins", icon:
                    <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 13v-2a1 1 0 0 0-1-1h-.757l-.707-1.707.535-.536a1 1 0 0 0 0-1.414l-1.414-1.414a1 1 0 0 0-1.414 0l-.536.535L14 4.757V4a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v.757l-1.707.707-.536-.535a1 1 0 0 0-1.414 0L4.929 6.343a1 1 0 0 0 0 1.414l.536.536L4.757 10H4a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h.757l.707 1.707-.535.536a1 1 0 0 0 0 1.414l1.414 1.414a1 1 0 0 0 1.414 0l.536-.535 1.707.707V20a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-.757l1.707-.708.536.536a1 1 0 0 0 1.414 0l1.414-1.414a1 1 0 0 0 0-1.414l-.535-.536.707-1.707H20a1 1 0 0 0 1-1Z" />
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                    </svg>
            }
        ]
    },

]

const ROOT = "/admin/"

export default function Layout({ children }) {

    const [isDark, setIsDark] = React.useState(false)
    const [minimize, setMinimize] = React.useState(true)

    const darkModeHandler = () => {
        setIsDark(!isDark)
        document.body.classList.toggle("dark")
    }

    const handleMinimize = () => setMinimize(!minimize)

    return (
        <div className='w-full min-h-screen bg-white dark:bg-slate-900 pt-[3.2%]'>
            <Head title="Transax" />

            <nav className={`w-[96%] left-[4%] fixed bg-white/95 py-1 top-0 flex flex-row border-b-2 dark:border-b-slate-800 border-slate-100`}>

                <div className="flex-1 h-[90%] space-y-4 divide-y-2 divide-slate-100 dark:divide-slate-800">

                    <ul className="flex-1 flex flex-row justify-center items-center py-2">
                        <li className="group/nav-item w-full relative dark:text-gray-300 pt-2 px-8">
                            <Link href="#" className='flex flex-row gap-x-2 xl:text-sm'>
                                Dashboard
                            </Link>
                        </li>

                    </ul>


                </div>

                <div className="flex-1 h-[10%] px-2">
                    <ul className="h-full flex flex-row items-center justify-end gap-x-4 pt-1">

                        <li>
                            {isDark &&
                                <Link href='#' onClick={darkModeHandler} className='flex flex-row justify-center items-center gap-x-2 dark:text-gray-400'>
                                    <svg className="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                        <path fillRule="evenodd" d="M13 3a1 1 0 1 0-2 0v2a1 1 0 1 0 2 0V3ZM6.343 4.929A1 1 0 0 0 4.93 6.343l1.414 1.414a1 1 0 0 0 1.414-1.414L6.343 4.929Zm12.728 1.414a1 1 0 0 0-1.414-1.414l-1.414 1.414a1 1 0 0 0 1.414 1.414l1.414-1.414ZM12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm-9 4a1 1 0 1 0 0 2h2a1 1 0 1 0 0-2H3Zm16 0a1 1 0 1 0 0 2h2a1 1 0 1 0 0-2h-2ZM7.757 17.657a1 1 0 1 0-1.414-1.414l-1.414 1.414a1 1 0 1 0 1.414 1.414l1.414-1.414Zm9.9-1.414a1 1 0 0 0-1.414 1.414l1.414 1.414a1 1 0 0 0 1.414-1.414l-1.414-1.414ZM13 19a1 1 0 1 0-2 0v2a1 1 0 1 0 2 0v-2Z" clipRule="evenodd" />
                                    </svg>
                                </Link>}

                            {!isDark &&
                                <Link href='#' onClick={darkModeHandler} className='flex flex-row justify-center items-center gap-x-2 dark:text-gray-400'>
                                    <svg className="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                        <path fillRule="evenodd" d="M11.675 2.015a.998.998 0 0 0-.403.011C6.09 2.4 2 6.722 2 12c0 5.523 4.477 10 10 10 4.356 0 8.058-2.784 9.43-6.667a1 1 0 0 0-1.02-1.33c-.08.006-.105.005-.127.005h-.001l-.028-.002A5.227 5.227 0 0 0 20 14a8 8 0 0 1-8-8c0-.952.121-1.752.404-2.558a.996.996 0 0 0 .096-.428V3a1 1 0 0 0-.825-.985Z" clipRule="evenodd" />
                                    </svg>
                                </Link>}

                        </li>

                        <li>
                            <Link href='/admin' className='flex flex-row justify-center items-center gap-x-2 dark:text-gray-400'>
                                <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                    <path fillRule="evenodd" d="M12.006 2a9.847 9.847 0 0 0-6.484 2.44 10.32 10.32 0 0 0-3.393 6.17 10.48 10.48 0 0 0 1.317 6.955 10.045 10.045 0 0 0 5.4 4.418c.504.095.683-.223.683-.494 0-.245-.01-1.052-.014-1.908-2.78.62-3.366-1.21-3.366-1.21a2.711 2.711 0 0 0-1.11-1.5c-.907-.637.07-.621.07-.621.317.044.62.163.885.346.266.183.487.426.647.71.135.253.318.476.538.655a2.079 2.079 0 0 0 2.37.196c.045-.52.27-1.006.635-1.37-2.219-.259-4.554-1.138-4.554-5.07a4.022 4.022 0 0 1 1.031-2.75 3.77 3.77 0 0 1 .096-2.713s.839-.275 2.749 1.05a9.26 9.26 0 0 1 5.004 0c1.906-1.325 2.74-1.05 2.74-1.05.37.858.406 1.828.101 2.713a4.017 4.017 0 0 1 1.029 2.75c0 3.939-2.339 4.805-4.564 5.058a2.471 2.471 0 0 1 .679 1.897c0 1.372-.012 2.477-.012 2.814 0 .272.18.592.687.492a10.05 10.05 0 0 0 5.388-4.421 10.473 10.473 0 0 0 1.313-6.948 10.32 10.32 0 0 0-3.39-6.165A9.847 9.847 0 0 0 12.007 2Z" clipRule="evenodd" />
                                </svg>
                                <label className='xl:text-xs'>
                                    68.8 k
                                </label>
                            </Link>
                        </li>

                        <li className="text-black dark:text-white py-3">
                            <Link href='/admin/auth/logout' method='post' as="button" onClick={() => { }} className="text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                                Sign out
                            </Link>

                        </li>

                    </ul>
                </div>

            </nav>

            <aside className={`${minimize ? 'w-[4%]' : 'w-[12%]'} transition-all duration-200 bg-slate-900 fixed left-0 top-0 h-screen flex flex-col border-r-2 dark:border-r-slate-800 border-slate-100`}
                style={{ zIndex: 10000000000 }}
            >
                <div className="flex-1 h-[90%] space-y-0">

                    <ul className="flex flex-col items-start justify-start">
                        <li className={`text-white dark:text-white py-2 ${minimize ? 'px-4' : 'px-8'} cursor-pointer`} onClick={handleMinimize}>
                            <Link href="#" className={`flex-1 ${minimize ? 'hidden' : 'flex'} flex-row justify-center items-center pt-4`}>
                                <h1 className='font-bold text-xl'>AKORA</h1>
                            </Link>
                            <img src='https://seeklogo.com/images/S/supabase-logo-DCC676FFE2-seeklogo.com.png' className={`w-14 ${minimize ? 'block' : 'hidden'}`} />
                        </li>
                    </ul>

                    {
                        <ul className="flex flex-col items-start justify-start">
                            {
                                NAVS.map((nav, index) => (
                                    <li key={index.toString()} className="w-full first:border-t-0 first:border-t-transparent border-t-[1px] border-slate-800">
                                        <ul className="flex flex-col items-start justify-start p-2">
                                            {
                                                nav.items.map((item, $index) => (
                                                    <li key={$index.toString()} className={`w-full dark:text-gray-300 py-4 ${minimize ? 'px-2' : 'px-8'} text-slate-500 hover:text-slate-500 hover:bg-slate-500/15 rounded-md`}>
                                                        <Link href={`${ROOT}${item.link}`} className={`w-full ${minimize ? 'justify-center items-center' : 'justify-start'} flex flex-row gap-x-2 text-sm`}>
                                                            {item.icon} <span className={`${minimize ? 'hidden' : 'block'}`}>{item.text}</span>
                                                        </Link>
                                                    </li>
                                                ))
                                            }
                                        </ul>


                                    </li>
                                ))
                            }
                        </ul>
                    }

                </div>

                <div className="flex-1 h-[10%] px-2 flex flex-col justify-end">
                    <ul className="w-full flex flex-col items-start justify-start">
                        <li className="w-full dark:text-gray-300 py-2 px-8 text-slate-500  hover:text-slate-500 hover:bg-slate-500/15 rounded-md">
                            <Link href={`${ROOT}settings_app`} className="w-full flex flex-row items-center gap-x-8">
                                <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" />
                                </svg>

                                <span className="group-hover/nav:block hidden">Search</span>
                            </Link>
                        </li>


                        <li className="w-full dark:text-gray-300 py-2 px-8 text-slate-500  hover:text-slate-500 hover:bg-slate-500/15 rounded-md">
                            <Link href={`${ROOT}/setting_app`} className="w-full flex flex-row items-center gap-x-8">
                                <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                    <path fillRule="evenodd" d="M9.586 2.586A2 2 0 0 1 11 2h2a2 2 0 0 1 2 2v.089l.473.196.063-.063a2.002 2.002 0 0 1 2.828 0l1.414 1.414a2 2 0 0 1 0 2.827l-.063.064.196.473H20a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-.089l-.196.473.063.063a2.002 2.002 0 0 1 0 2.828l-1.414 1.414a2 2 0 0 1-2.828 0l-.063-.063-.473.196V20a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2v-.089l-.473-.196-.063.063a2.002 2.002 0 0 1-2.828 0l-1.414-1.414a2 2 0 0 1 0-2.827l.063-.064L4.089 15H4a2 2 0 0 1-2-2v-2a2 2 0 0 1 2-2h.09l.195-.473-.063-.063a2 2 0 0 1 0-2.828l1.414-1.414a2 2 0 0 1 2.827 0l.064.063L9 4.089V4a2 2 0 0 1 .586-1.414ZM8 12a4 4 0 1 1 8 0 4 4 0 0 1-8 0Z" clipRule="evenodd" />
                                </svg>

                                <span className="group-hover/nav:block hidden">Settings</span>
                            </Link>
                        </li>

                    </ul>
                </div>
            </aside>


            <main className={`${minimize ? "w-[96%] ml-[4%]" : "w-[88%] ml-[12%]"}`}>
                {children}
            </main>

        </div>
    )
}

//px-8 py-2