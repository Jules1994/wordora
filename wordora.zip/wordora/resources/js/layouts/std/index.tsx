/* eslint-disable prettier/prettier */
import React from "react"
import { DialogContextProvider } from '../../contexts/dialog.context/context'

export default function Layout({ children }) {
    return (
        <DialogContextProvider backgroundColor="rgba(0, 0, 0, 0.7)">
            {children}
        </DialogContextProvider>)
}