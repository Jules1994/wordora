import React from 'react'
import { Head, Link } from '@inertiajs/react'

export default function Layout({ children, title }) {

  const [isDark, setIsDark] = React.useState(false)

  React.useEffect(() => {}, [])

  const darkModeHandler = () => {
    setIsDark(!isDark)
    document.body.classList.toggle("dark")
  }

  return (

    <div className='w-full min-h-screen bg-white dark:bg-slate-900 pt-[3.2%]'>

      <Head title="Account" />

      <nav className="w-[88%] fixed left-[12%] py-0 top-0 flex flex-row border-b-2 dark:border-b-slate-800 border-slate-100">

        <div className="flex-1 h-[90%] space-y-4 divide-y-2 divide-slate-100 dark:divide-slate-800">

          <ul className="flex-1 flex flex-row justify-center items-center py-2">
            <li className="group/nav-item w-full relative dark:text-gray-300 pt-0 px-8">
              <Link href="/admin" className='flex flex-row gap-x-2 xl:text-sm'>
                Wordora
              </Link>
              <p className='text-slate-500 text-sm'>Pluginable scalator plateform</p>
            </li>

          </ul>


        </div>

        <div className="flex-1 h-[10%] px-2">
          <ul className="h-full flex flex-row items-center justify-end gap-x-4 pt-1">

            <li>
              {isDark &&
                <Link href='#' onClick={darkModeHandler} className='flex flex-row justify-center items-center gap-x-2 dark:text-gray-400'>
                  <svg className="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                    <path fill-rule="evenodd" d="M13 3a1 1 0 1 0-2 0v2a1 1 0 1 0 2 0V3ZM6.343 4.929A1 1 0 0 0 4.93 6.343l1.414 1.414a1 1 0 0 0 1.414-1.414L6.343 4.929Zm12.728 1.414a1 1 0 0 0-1.414-1.414l-1.414 1.414a1 1 0 0 0 1.414 1.414l1.414-1.414ZM12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm-9 4a1 1 0 1 0 0 2h2a1 1 0 1 0 0-2H3Zm16 0a1 1 0 1 0 0 2h2a1 1 0 1 0 0-2h-2ZM7.757 17.657a1 1 0 1 0-1.414-1.414l-1.414 1.414a1 1 0 1 0 1.414 1.414l1.414-1.414Zm9.9-1.414a1 1 0 0 0-1.414 1.414l1.414 1.414a1 1 0 0 0 1.414-1.414l-1.414-1.414ZM13 19a1 1 0 1 0-2 0v2a1 1 0 1 0 2 0v-2Z" clipRule="evenodd" />
                  </svg>
                </Link>}

              {!isDark &&
                <Link href='#' onClick={darkModeHandler} className='flex flex-row justify-center items-center gap-x-2 dark:text-gray-400'>
                  <svg className="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                    <path fillRule="evenodd" d="M11.675 2.015a.998.998 0 0 0-.403.011C6.09 2.4 2 6.722 2 12c0 5.523 4.477 10 10 10 4.356 0 8.058-2.784 9.43-6.667a1 1 0 0 0-1.02-1.33c-.08.006-.105.005-.127.005h-.001l-.028-.002A5.227 5.227 0 0 0 20 14a8 8 0 0 1-8-8c0-.952.121-1.752.404-2.558a.996.996 0 0 0 .096-.428V3a1 1 0 0 0-.825-.985Z" clipRule="evenodd" />
                  </svg>
                </Link>}

            </li>

            <li>
              <Link href='#' className='flex flex-row justify-center items-center gap-x-2 dark:text-gray-400'>
                <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                  <path fillRule="evenodd" d="M12.006 2a9.847 9.847 0 0 0-6.484 2.44 10.32 10.32 0 0 0-3.393 6.17 10.48 10.48 0 0 0 1.317 6.955 10.045 10.045 0 0 0 5.4 4.418c.504.095.683-.223.683-.494 0-.245-.01-1.052-.014-1.908-2.78.62-3.366-1.21-3.366-1.21a2.711 2.711 0 0 0-1.11-1.5c-.907-.637.07-.621.07-.621.317.044.62.163.885.346.266.183.487.426.647.71.135.253.318.476.538.655a2.079 2.079 0 0 0 2.37.196c.045-.52.27-1.006.635-1.37-2.219-.259-4.554-1.138-4.554-5.07a4.022 4.022 0 0 1 1.031-2.75 3.77 3.77 0 0 1 .096-2.713s.839-.275 2.749 1.05a9.26 9.26 0 0 1 5.004 0c1.906-1.325 2.74-1.05 2.74-1.05.37.858.406 1.828.101 2.713a4.017 4.017 0 0 1 1.029 2.75c0 3.939-2.339 4.805-4.564 5.058a2.471 2.471 0 0 1 .679 1.897c0 1.372-.012 2.477-.012 2.814 0 .272.18.592.687.492a10.05 10.05 0 0 0 5.388-4.421 10.473 10.473 0 0 0 1.313-6.948 10.32 10.32 0 0 0-3.39-6.165A9.847 9.847 0 0 0 12.007 2Z" clipRule="evenodd" />
                </svg>
                <label className='xl:text-xs'>
                  68.8 k
                </label>
              </Link>
            </li>

            <li className="text-black dark:text-white py-3">
              <Link href='/admin/auth/logout' method='post' type='button' className="text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                Sign out
              </Link>

            </li>

          </ul>
        </div>

      </nav>

      <aside className="w-[12%] fixed left-0 top-0 h-screen flex flex-col border-r-2 dark:border-r-slate-800 border-slate-100 bg-[#051E34]">
        <div className="flex-1 h-[90%] space-y-4 divide-y-1 divide-slate-50 dark:divide-[#051E34]">

          <ul className="flex flex-col items-start justify-start">
            <li className="text-black dark:text-white px-8">

              <Link href={`/admin`} className="flex-1 flex flex-row justify-center items-center pt-4">
                <h1 className='font-bold text-xl text-white'>Dashboard</h1>
              </Link>
            </li>
          </ul>

          <ul className="w-full flex flex-col justify-start items-start py-2 pt-5">

            <li className="dark:text-gray-500 xl:text-xs text-slate-200 py-0 px-8">
              <Link href="#">Organizations</Link>
            </li>

            <li className="group/nav-item w-full relative dark:text-gray-300 py-2 text-slate-500 px-8">
              <Link href='/admin/plugins' className='flex flex-row gap-x-2'>Plugins</Link>
            </li>

          </ul>

          <ul className="w-full flex flex-col justify-start items-start py-2 pt-5">

            <li className="dark:text-gray-500 xl:text-xs text-slate-200 py-0 px-8">
              <a href="#">Management</a>
            </li>

            <li className="dark:text-gray-300 py-2 px-8 text-slate-500">
              <Link href="/admin/users">Users</Link>
            </li>

            <li className="dark:text-gray-300 py-2 px-8 text-slate-500">
              <Link href="/admin/roles">Roles</Link>
            </li>

            <li className="dark:text-gray-300 py-2 px-8 text-slate-500">
              <Link href="/admin/roles">Uploads</Link>
            </li>

          </ul>

          <ul className="w-full flex flex-col justify-start items-start py-2 pt-5">

            <li className="dark:text-gray-500 xl:text-xs text-slate-200 py-0 px-8">
              <a href="#">Setting</a>
            </li>

            <li className="dark:text-gray-300 py-2 px-8 text-slate-500">
              <Link href="/admin/setting?ref=preferences">Preferences</Link>
            </li>

            <li className="dark:text-gray-300 py-2 px-8 text-slate-500">
              <Link href="/admin/setting?ref=access_tokens">Access Tokens</Link>
            </li>

            <li className="dark:text-gray-300 py-2 px-8 text-slate-500">
              <Link href="/admin/setting?ref=security">Security</Link>
            </li>

            <li className="dark:text-gray-300 py-2 px-8 text-slate-500">
              <Link href="/admin/setting?ref=audit_log">Audit Logs</Link>
            </li>

          </ul>

          <ul className="w-full flex flex-col justify-start items-start py-2 pt-5">

            <li className="dark:text-gray-500 xl:text-xs text-slate-200 py-2 px-8">
              <a href="#" className="space-x-4">
                Documentation
              </a>
            </li>

            <li className="dark:text-gray-300 py-2 px-8 text-slate-500">
              <a href="#" className="flex flex-row justify-center items-center gap-x-4">
                API Reference
                <svg className="w-5 h-5 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                  <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778" />
                </svg>
              </a>
            </li>

          </ul>

        </div>

      </aside>


      <main className="w-[88%] ml-[12%]">
        {children}
      </main>

    </div>
  )
}

//px-8 py-2s