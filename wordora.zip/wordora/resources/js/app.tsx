import './bootstrap';
import React from "react"
import ReactDOM from 'react-dom';
import { createInertiaApp } from '@inertiajs/react'
import { createRoot } from 'react-dom/client'
import { DialogContextProvider } from './contexts/dialog.context/context';
import LoaderProviderContext from './contexts/loader.context';
import ThemeProviderContext from './contexts/theme.context';
import { UploaderContextProvider } from './contexts/uploader.context';
import { AppProvider } from './libs/api-react';

window.React = React
window.ReactDOM = ReactDOM


if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker
            .register('/sw.js')
            .then((registration) => {
                console.log('ServiceWorker enregistré :', registration.scope);
            })
            .catch((error) => {
                console.error('Erreur lors de l\'enregistrement du ServiceWorker :', error);
            });
    });
}

const SystemContext: React.FC<any> = ({ children }) => (
    <ThemeProviderContext>
        <LoaderProviderContext>
            <UploaderContextProvider>
                <DialogContextProvider backgroundColor='rgba(0, 0, 0, .7)'>
                    <AppProvider>
                        {children}
                    </AppProvider>
                </DialogContextProvider>
            </UploaderContextProvider>
        </LoaderProviderContext>
    </ThemeProviderContext>
)


createInertiaApp({
    resolve: name => {
        const pages = import.meta.glob('./screens/**/*.tsx', { eager: true })
        return pages[`./screens/${name}.tsx`]
    },
    setup({ el, App, props }) {
        createRoot(el).render(
            <SystemContext>
                <App {...props} />
            </SystemContext>

        )
    },
    progress: {
        // The delay after which the progress bar will appear, in milliseconds...
        delay: 250,

        // The color of the progress bar...
        color: 'orangered',

        // Whether to include the default NProgress styles...
        includeCSS: true,

        // Whether the NProgress spinner will be shown...
        showSpinner: false,
    },

})


