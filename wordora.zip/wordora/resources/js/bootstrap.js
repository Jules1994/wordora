import axios from 'axios';
window.axios = axios;

window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

window.global = window;
window.process = { env: { DEBUG: undefined } };

Date.prototype.addDays = function (days) {
  var date = new Date(this.valueOf());
  date.setDate(date.getDate() + days);
  return date;
};

Date.prototype.formatToBilling = function (separator = "-") {
  var date = new Date(this.valueOf());

  const day = date.getDate() > 9 ? date.getDate() : "0" + date.getDate();
  const month =
    date.getMonth() + 1 > 9 ? date.getMonth() + 1 : "0" + (date.getMonth() + 1);
  const year = date.getFullYear();

  return day + separator + month + separator + year;
};

Date.prototype.formatToBillingToHuman = function (separator = " ") {
  const DAYS = [
    "Dimanche",
    "Lundi",
    "Mardi",
    "Mercredi",
    "Jeudi",
    "Vendredi",
    "Samedi",
  ];
  const MONTHS = [
    "Janvier",
    "Fevrier",
    "Mars",
    "Avril",
    "Mai",
    "Juin",
    "Juillet",
    "Aout",
    "septembre",
    "Octobre",
    "Novembre",
    "Decembre",
  ];

  var date = new Date(this.valueOf());
  const day = date.getDate() > 9 ? date.getDate() : "0" + date.getDate();
  const month = MONTHS[date.getMonth()];
  const year = date.getFullYear();

  return (
    "Le " +
    DAYS[date.getDay()] +
    separator +
    day +
    separator +
    month +
    separator +
    year
  );
};
