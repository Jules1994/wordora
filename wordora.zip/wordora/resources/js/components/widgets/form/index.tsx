import React, { useState, useEffect } from 'react';
import axios from 'axios';
import View from '../../view'
import MaskedInput from '../maskedinput';

const parseCSV = async (file) => {
    const response = await fetch(file);
    const text = await response.text();
    const lines = text.trim().split('\n');
    const headers = lines[0].split(',');
    return lines.slice(1).map(line => {
        const values = line.split(',');
        return headers.reduce((obj, header, index) => {
            obj[header.trim()] = values[index].trim();
            return obj;
        }, {});
    });
};

function Form({ config, defaultData = null }, ref) {

    const [formData, setFormData] = useState(defaultData || {});
    const [dynamicOptions, setDynamicOptions] = useState({});
    const [errors, setErrors] = useState({});
    const [mediaPreviews, setMediaPreviews] = useState({});

    useEffect(() => {
        // Initialiser les données du formulaire
        if (config?.sections) {
            (async () => {
                let initialData = {};
                for await (var section of config.sections) {
                    for await (var field of section.fields) {

                        initialData[field.name] = formData[field.name] ? formData[field.name] : '';
                        if (field.type === 'select' && field.source) {
                            await loadOptions(field.name, field.source);
                        }
                    }
                }
                setFormData(initialData);
            })()
        }
    }, [config]);

    React.useImperativeHandle(ref, () => {
        return {

            data: () => {
                return formData
            },

            submit: () => {
                return {
                    errors,
                    value: formData
                }
            },

            hasErrors: () => {
                const keys = Object.keys(errors);
                if (keys.length === 0) {
                    return false
                }
                for (var key of keys) {
                    if (errors[key] && errors[key] !== '') {
                        return true
                    }
                }
                return false
            }
        }
    },
        [errors, formData, config])

    // Charger les options dynamiques
    const loadOptions = async (name, source) => {
        try {
            alert("Okay")
            let options = [];
            if (source.type === 'url') {
                const response = await axios.get(source.url);
                alert(JSON.stringify(response))
                options = await response.data;
            } else if (source.type === 'json') {
                options = source.data;
            } else if (source.type === 'csv') {
                options = await parseCSV(source.file) as never[];
            }
            setDynamicOptions(prev => ({ ...prev, [name]: options }));
        } catch (e) {
            alert(e.message)
        }
    };

    const validateField = (name, value, validation) => {
        let error = '';
        if (validation.required && !value) {
            error = 'This field is required.';
        } else if (validation.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
            error = 'Please enter a valid email address.';
        } else if (validation.regex && !new RegExp(validation.regex).test(value)) {
            error = 'Invalid format.';
        } else if (validation.minLength && value.length < validation.minLength) {
            error = `Minimum length is ${validation.minLength}.`;
        } else if (validation.maxLength && value.length > validation.maxLength) {
            error = `Maximum length is ${validation.maxLength}.`;
        }
        setErrors(prev => ({ ...prev, [name]: error }));
    };

    const handleChange = (name, value, validation) => {
        setFormData({
            ...formData,
            [name]: value,
        });

        if (validation) {
            validateField(name, value, validation);
        }
    };

    const handleFileChange = (name, file) => {
        setFormData({ ...formData, [name]: file });

        const reader = new FileReader();
        reader.onload = (e) => {
            setMediaPreviews(prev => ({ ...prev, [name]: e.target?.result }));
        };

        if (file.type.startsWith('image') || file.type.startsWith('video')) {
            reader.readAsDataURL(file);
        }
    };

    const renderField = (field) => {

        const error = errors[field.name];
        const commonProps = {
            name: field.name,
            onChange: (e) => handleChange(field.name, e.target.value, field.validation),
            className: `border px-2 py-1 ${error ? 'border-red-500' : ''}`
        };

        switch (field.type) {
            case 'input':
                return (
                    <View className="w-full mb-5">

                        {field.type === 'input' && field.maskType ? (
                            <MaskedInput
                                name={field.name}
                                type={`${field.secureText ? "password" : 'text'}`}
                                placeholder={field.placeholder}
                                maskType={field.maskType}
                                defaultValue={formData[field.name]}
                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                onChange={(e) => handleChange(field.name, e.target.value, field.validation)}
                            />
                        ) : (
                            <input
                                name={field.name}
                                type={`${field.secureText ? "password" : 'text'}`}
                                placeholder={field.placeholder}
                                defaultValue={formData[field.name]}
                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                onChange={(e) => handleChange(field.name, e.target.value, field.validation)}
                            />
                        )}
                        {error && <p className="text-red-500 text-sm">{error}</p>}
                    </View>
                );

            case 'paragraph':
                return (
                    <View className="w-full mb-5">

                        <textarea
                            name={field.name}
                            placeholder={field.placeholder}
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full min-h-24 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            onChange={(e) => handleChange(field.name, e.target.value, field.validation)}
                        >
                            {formData[field.name]}
                        </textarea>
                        {error && <p className="text-red-500 text-sm">{error}</p>}
                    </View>
                );

            case 'radio':
                return field.options.map((option, index) => (
                    <>
                        <label key={index} className="inline-flex items-center">
                            <input
                                type="radio"
                                name={field.name}
                                value={option.value}
                                className="form-radio"
                                placeholder={field.placeholder}
                                onChange={(e) => handleChange(field.name, e.target.value, field.validation)}
                            />
                            <span className="ml-2">{option.label}</span>
                        </label>
                        {error && <p className="text-red-500 text-sm">{error}</p>}
                    </>
                ));
            case 'select':
                return (
                    <select
                        name={field.name}
                        className="border px-2 py-1"
                        onChange={(e) => handleChange(field.name, e.target.value, field.validation)}
                    >
                        {(dynamicOptions[field.name]).map((option, index) => (
                            <option key={index} value={option.value}>
                                {option.label}
                            </option>
                        ))}
                    </select>
                );
            case 'imagePicker':
                return (
                    <View>
                        <input
                            type="file"
                            accept="image/*"
                            onChange={(e: any) => handleFileChange(field.name, e.target?.files[0])}
                        />
                        {mediaPreviews[field.name] && (
                            <img
                                src={mediaPreviews[field.name]}
                                alt="Preview"
                                className="mt-2 w-24 h-24 object-cover"
                            />
                        )}
                        {error && <p className="text-red-500 text-sm">{error}</p>}
                    </View>
                );
            case 'documentPicker':
                return (
                    <View className="relative flex flex-col justify-center items-center gap-y-4 w-full h-92 py-8 border-dotted border-4 border-slate-2 rounded-md">
                        
                        <input
                            type="file"
                            className="absolute top-0 left-0 w-full h-full opacity-0"
                            onChange={(e: any) => handleFileChange(field.name, e.target?.files[0])}
                        />

                        <svg className="w-14 h-14 text-gray-400 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                            <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5v9m-5 0H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2M8 9l4-5 4 5m1 8h.01" />
                        </svg>

                        {<p className='text-center text-gray-400 text-sm'>{field.placeholder}</p>}
                        {error && <p className="text-red-500 text-sm">{error}</p>}
                    </View>

                );
            case 'multipleImagesPicker':
                return (
                    <View>
                        <input
                            type="file"
                            accept="image/*"
                            multiple
                            onChange={(e) => handleFileChange(field.name, e.target.files)}
                        />
                        {mediaPreviews[field.name] && (
                            <img
                                src={mediaPreviews[field.name]}
                                alt="Preview"
                                className="mt-2 w-24 h-24 object-cover"
                            />
                        )}
                        {error && <p className="text-red-500 text-sm">{error}</p>}
                    </View>
                );
            case 'video':
                return (
                    <View>
                        <input
                            type="file"
                            accept="video/*"
                            onChange={(e: any) => handleFileChange(field.name, e.target.files[0])}
                        />
                        {mediaPreviews[field.name] && (
                            <div className="mt-2">
                                <video
                                    src={mediaPreviews[field.name]}
                                    controls
                                    className="w-full h-auto"
                                />
                            </div>
                        )}
                        {error && <p className="text-red-500 text-sm">{error}</p>}
                    </View>
                );

            default:
                return null;
        }
    };

    const renderSection = (section, index) => (
        <div
            key={`section-${index}`}
            className={`${section.layout === 'row' ? 'flex flex-row flex-wrap' : 'flex-col'} gap-4 mb-4`}
        >
            {section.title && <h3 className="font-bold text-lg mb-5">{section.title}</h3>}
            {section.fields.map((field) => (
                <div key={field.name} className="flex flex-row flex-wrap">
                    <label htmlFor={field.name} className="block text-sm font-medium text-gray-900 dark:text-white">
                        {field.label}
                    </label>
                    {renderField(field)}
                </div>
            ))}
        </div>
    );

    return (
        <form className="w-full">
            {config?.sections?.map(renderSection)}
        </form>
    );
}


export default React.forwardRef(Form);
