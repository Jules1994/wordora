import React from 'react'
import axios from 'axios';
import { FetchingData, NoData, SeederData, State } from '../fetching';

export type CallbackResponseMedia = 'validate' | 'cancel'

export type MediaLibraryDialogType = (media?: any, action?: CallbackResponseMedia) => void

export const MediaLibraryDialog = (action: 'all' | 'upload' | 'explore', onResult: MediaLibraryDialogType, onCancel) => {
    return {
        header: {
            title: "Media Library",
            icon: (
                <svg className="w-6 h-6 text-green-600 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                    <path fillRule="evenodd" d="M3 6a2 2 0 0 1 2-2h5.532a2 2 0 0 1 1.536.72l1.9 2.28H3V6Zm0 3v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9H3Z" clipRule="evenodd" />
                </svg>
            ),
        },
        child: (<MediaLibrary action={action} onClickMedia={onResult} />),
        bottom: (
            <div
                onClick={onCancel}
                className="w-full border-t-2 border-slate-100 p-[2%] flex gap-x-2 justify-end items-center"
            >
                <button className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700" >
                    Fermer
                </button>
                {/*<button className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                    D'accord
                </button>*/}
            </div>
        ),
    };
};

const MediaLibrary = ({ action, onClickMedia }) => {

    const [state, setState] = React.useState(State.FETCHING_DATA)
    const [openUpload, setOpenUpload] = React.useState<boolean>(false)
    const [medias, setMedias] = React.useState<any[]>([])

    React.useEffect(() => {
        (async () => {

            if (action === 'upload') {
                setState(State.LOADED_DATA)
                return
            }

            try {
                const res = await axios.get('/admin/medias?responsetype=json');
                if (res.status === 200) {
                    setMedias(() => res.data?.medias ?? [])
                    setState(() => res.data.medias.length > 0 ? State.LOADED_DATA : State.NO_DATA)
                } else {
                    setState(State.NO_DATA)
                }
            } catch (e) {
                alert(e.message)
            }

        })()
    }, [])

    const onUpload = (media) => {
        setMedias([media, ...medias])
    }

    const handleSearch = (files) => {

    }

    const handleOpenUpload = () => {
        if (['upload', 'all'].includes(action)) {
            setOpenUpload(!openUpload)
        }
    }

    return <div className='w-full space-y-0'>
        <MediaLibrarySearch onSearch={handleSearch} action={action} onToggleUpload={handleOpenUpload} />
        {openUpload && <MediaLibraryDragAndDrop onUpload={onUpload} />}


        {['all', 'explore'].includes(action) &&
            <div className='w-full py-4 px-2'>
                <div className='flex items-center'>
                    <label className='text-gray-600 px-4 text-sm'>Search result : </label>
                </div>
                <SeederData
                    state={state}
                    FetchingComponent={<FetchingData
                        title="No data to show"
                        content="it may take up to 24h hours for data to show"
                        iconComponent={
                            <svg className="w-8 h-8 animate-spin text-green-400 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.651 7.65a7.131 7.131 0 0 0-12.68 3.15M18.001 4v4h-4m-7.652 8.35a7.13 7.13 0 0 0 12.68-3.15M6 20v-4h4" />
                            </svg>
                        }
                    />}

                    NoDataComponent={
                        <NoData
                            iconComponent={
                                <svg className="w-6 h-6 text-slate-400 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 13h3.439a.991.991 0 0 1 .908.6 3.978 3.978 0 0 0 7.306 0 .99.99 0 0 1 .908-.6H20M4 13v6a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-6M4 13l2-9h12l2 9" />
                                </svg>}
                        />
                    }
                >
                    <MediaLibraryList
                        medias={medias}
                        renderItem={({ media, index }) =>
                            <MediaView
                                media={media}
                                key={`upload-${index}`}
                                onClick={onClickMedia}
                            />
                        }
                    />
                </SeederData>
            </div>
        }
    </div>
}

const MediaLibraryList = ({ medias, renderItem }) => {

    const mediasRendered = medias.map((media, index) => renderItem({ media, index }))

    return <div className='w-full flex flex-wrap gap-1 p-4'>
        {mediasRendered}
    </div>
}

const MediaLibrarySearch = ({ action, onSearch, onToggleUpload }) => {

    return <div className='w-full flex justify-between items-center flex-wrap gap-1 p-4'>
        <div className="text-black dark:text-white py-3 relative">
            <input type="email" onChange={onSearch} className="w-72 pl-8 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700" placeholder="Search for a project" required />
            <span className="absolute left-2 top-1/3">
                <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" />
                </svg>
            </span>
        </div>
        {['upload', 'all'].includes(action) &&
            <button onClick={onToggleUpload} className="focus:outline-none flex items-center gap-x-2 text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-2 p-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                <svg className="w-4 h-4 white dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11v5m0 0 2-2m-2 2-2-2M3 6v1a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1Zm2 2v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8H5Z" />
                </svg>
                upload
            </button>}
    </div>
}

const MediaLibraryDragAndDrop = React.memo(({ onUpload }: any) => {

    const [uploadedMedias, setUploadMedia] = React.useState<any[]>([])

    const handleFileChange = (files) => {
        setUploadMedia([...files, ...uploadedMedias])
    }

    const onUploadComplete = (media) => {
        console.log(media)
        const index = uploadedMedias.findIndex(file => file.name === media.name)
        console.log(index)
        const newUploadMedias = uploadedMedias.splice(index, 1)
        if (onUpload) {
            onUpload(media)
        }

        setUploadMedia(newUploadMedias.slice(0))
    }

    const mediasRendered = uploadedMedias.map((file, index) => (
        <UploadView
            key={`media-upload-${index}`}
            file={file}
            onUploadComplete={onUploadComplete}
        />
    ))


    return (
        <div className='w-full flex flex-col xl:flex-row xl:gap-x-2 items-center justify-between bg-slate-50'>
            <div className='flex-shrink-0 h-20'>

                <div className="w-24 h-20 relative cursor-pointer flex flex-col justify-center items-center gap-y-4 border-dotted border-2 border-green-400 rounded-md bg-green-100 hover:bg-green-100/80 hover:border-green-600/80 transition-colors">

                    <input
                        type="file"
                        className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer"
                        onChange={(e: any) => handleFileChange(e.target?.files)}
                    />

                    <svg className="w-10 h-10 text-green-400 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5v9m-5 0H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2M8 9l4-5 4 5m1 8h.01" />
                    </svg>

                </div>

            </div>


            <div className='w-[80%] flex-shrink-0 h-20 gap-1'>
                <div className='w-full flex gap-x-2 overflow-x-auto'>
                    {mediasRendered}
                </div>
            </div>
        </div>
    )
})

const MediaView = React.memo(({ media, onClick }: any) => {

    const handleClick = () => {
        if (onClick) {
            onClick(media)
        }
    }

    if (media.file_type === 'images') {
        return (
            <div onClick={handleClick} className='cursor-pointer w-[24%] min-h-20 border-2 border-slate-100 rounded flex flex-col justify-center items-center hover:border-green-500 transition-colors'>
                <img className='w-full h-20 object-cover object-center rounded' src={`/${media.file_path}`} />
                <label className='text-left text-xs my-1 text-gray-500'>{media.name.substring(0, 20)}</label>
            </div>)
    }

    if (media.file_type === 'videos') {
        return (<div onClick={handleClick} className='cursor-pointer w-[24%] min-h-20 border-2 border-slate-100 rounded flex flex-col justify-center items-center hover:border-green-500 transition-colors'>
            <video className='w-full h-20 object-cover object-center rounded' controls src={`/${media.file_path}`} />
            <label className='text-left text-xs my-1 text-gray-500'>{media.name.substring(0, 20)}</label>
        </div>)
    }


    if (media.file_type === 'audios') {
        return <div onClick={handleClick} className='cursor-pointer w-[24%] min-h-24 border-2 border-slate-100 rounded flex flex-col justify-center items-center hover:border-green-500 transition-colors'>
            Audio
            <label className='text-left text-xs my-1 text-gray-500 rounded'>{media.name.substring(0, 20)}</label>
        </div>
    }

    return <div onClick={handleClick} className='cursor-pointer w-[24%] min-h-20 border-2 border-slate-100 rounded flex flex-col justify-center items-center'>
        Document
        <label className='text-left text-xs my-1 text-gray-500'>{media.name.substring(0, 20)}</label>
    </div>

})

const UploadView = React.memo(({ file, onUploadComplete }: any) => {

    const [progress, setProgress] = React.useState(0)
    React.useEffect(() => {
        (async () => {
            const res = await upload('/admin/medias/create', file, (p) => {
                console.log(p)
                setProgress(progress)
            })
            if (!res?.data.state) {
                setProgress(res?.data.message)
            } else {
                onUploadComplete(res?.data.media)
            }
        })()
    }, [])

    return (<div className='w-32 h-20 flex flex-col justify-center gap-y-1 items-center flex-shrink-0 border-2 border-slate-200 rounded'>

        {typeof (progress) === 'number' && <h5 className='text-xs text-gray-600'>{file.name.substring(0, 10)}</h5>}
        {typeof (progress) === 'number' && <span className='text-xs px-2 py-1 rounded-full bg-green-200 text-green-600 border-green-600 border'>{progress}%</span>}


        {typeof (progress) !== 'number' &&
            <span className='text-xs flex flex-row items-center gap-x-1 px-2 py-1 rounded-full bg-red-200 text-red-600 border-red-600 border'>
                <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path fill="currentColor" d="M12 17a2 2 0 0 1 2 2h-4a2 2 0 0 1 2-2Z" />
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.815 9H16.5a2 2 0 1 0-1.03-3.707A1.87 1.87 0 0 0 15.5 5 1.992 1.992 0 0 0 12 3.69 1.992 1.992 0 0 0 8.5 5c.002.098.012.196.03.293A2 2 0 1 0 7.5 9h3.388m2.927-.985v3.604M10.228 9v2.574M15 16h.01M9 16h.01m11.962-4.426a1.805 1.805 0 0 1-1.74 1.326 1.893 1.893 0 0 1-1.811-1.326 1.9 1.9 0 0 1-3.621 0 1.8 1.8 0 0 1-1.749 1.326 1.98 1.98 0 0 1-1.87-1.326A1.763 1.763 0 0 1 8.46 12.9a2.035 2.035 0 0 1-1.905-1.326A1.9 1.9 0 0 1 4.74 12.9 1.805 1.805 0 0 1 3 11.574V12a9 9 0 0 0 18 0l-.028-.426Z" />
                </svg>
                <p>Oups!</p>
            </span>}

    </div>)

})

export const upload = async (url, file, onProgress) => {

    try {

        const formData = new FormData();
        if (typeof (file) === "string") {
            formData.append("url", file);
        } else {

            const [file_type, extension] = file.type.split("/")
            formData.append("file", file);
            formData.append("metadata", JSON.stringify({
                name: file.name,
                size: file.size,
                ext: extension,
                file_type: `${file_type}s`
            }));
        }

        const res = await axios.post(url, formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            },
            onUploadProgress: (e) => {
                var percentCompleted = Math.round((e.loaded * 100) / file.size)
                console.log(percentCompleted)
                if (onProgress) {
                    onProgress(percentCompleted)
                }
            }
        })

        return res
    } catch (e) {
        alert(e.message)
        return null
    }
}