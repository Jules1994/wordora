import React, { useState } from 'react';

const StackView = ({ children }) => {
    const [index, setIndex] = useState(0); // Pour gérer l'index de la vue active

    // Fonction pour naviguer vers la vue suivante
    const pushView = () => {
        if (index < children.length - 1) {
            setIndex(index + 1);
        }
    };

    // Fonction pour revenir à la vue précédente
    const popView = () => {
        if (index > 0) {
            setIndex(index - 1);
        }
    };

    return (
        <div className="relative w-full h-full overflow-hidden">
            <div className="flex items-center justify-center p-4">
                {/* Bouton "Back" qui n'apparaît pas sur la première vue */}
                {index > 0 && (
                    <button
                        onClick={popView}
                        className="absolute top-4 left-4 bg-gray-200 text-gray-700 px-3 py-1 rounded hover:bg-gray-300 transition"
                    >
                        Back
                    </button>
                )}
                
                {/* Contenu de la vue actuelle avec animation */}
                <div
                    className={`transform transition-transform duration-300 ease-in-out ${
                        index === 0 ? '' : '-translate-x-full'
                    }`}
                    key={index}
                >
                    {children[index]}
                </div>
                
                {/* Bouton "Next" pour passer à la vue suivante */}
                {index < children.length - 1 && (
                    <button
                        onClick={pushView}
                        className="absolute top-4 right-4 bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 transition"
                    >
                        Next
                    </button>
                )}
            </div>
        </div>
    );
};

export default StackView;


{/***
    
    
    
    <StackView>
    <div>Children 1: Bienvenue sur la première vue</div>
    <div>Children 2: Ceci est la deuxième vue</div>
    <div>Children 3: Et voici la troisième vue</div>
</StackView>

    
    */}