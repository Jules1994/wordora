import React from 'react';

const ValidationProperties = ({ field, onUpdateField }) => {
    const handleValidationChange = (e) => {
        const { name, checked, value } = e.target;
        const validations = field.validations || {};

        onUpdateField(field.id, {
            ...field,
            validations: {
                ...validations,
                [name]: checked ? value : '',
            },
        });
    };

    return (
        <div className="p-4 bg-white shadow rounded">
            <h3 className="font-bold mb-2">Règles de Validation</h3>
            <label>
                <input
                    type="checkbox"
                    name="required"
                    value="required"
                    checked={field.validations?.required === 'required'}
                    onChange={handleValidationChange}
                />
                Required
            </label>
            <label>
                <input
                    type="checkbox"
                    name="string"
                    value="string"
                    checked={field.validations?.string === 'string'}
                    onChange={handleValidationChange}
                />
                String
            </label>
            <label>
                <input
                    type="text"
                    name="min"
                    placeholder="Min Length"
                    value={field.validations?.min || ''}
                    onChange={handleValidationChange}
                    className="border p-1 mb-2 w-full"
                />
            </label>
            <label>
                <input
                    type="text"
                    name="max"
                    placeholder="Max Length"
                    value={field.validations?.max || ''}
                    onChange={handleValidationChange}
                    className="border p-1 mb-2 w-full"
                />
            </label>
            {/* Ajouter d'autres règles comme "numeric", "email", etc. */}
        </div>
    );
};

export default ValidationProperties;
