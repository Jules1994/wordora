import React from 'react';

const FieldDetails = ({ field, onUpdateField }) => {
    const handleChange = (e) => {
        const { name, value } = e.target;
        onUpdateField(field.id, { ...field, [name]: value });
    };

    return (
        <div className="p-4 bg-white shadow rounded">
            <h3 className="font-bold mb-2">Détails du champ</h3>
            <label>
                Name:
                <input
                    type="text"
                    name="name"
                    value={field.name || ''}
                    onChange={handleChange}
                    className="border p-1 mb-2 w-full"
                />
            </label>
            <label>
                Placeholder:
                <input
                    type="text"
                    name="placeholder"
                    value={field.placeholder || ''}
                    onChange={handleChange}
                    className="border p-1 mb-2 w-full"
                />
            </label>
            <label>
                Default Value:
                <input
                    type="text"
                    name="defaultValue"
                    value={field.defaultValue || ''}
                    onChange={handleChange}
                    className="border p-1 mb-2 w-full"
                />
            </label>
            <label>
                CSS Classes:
                <input
                    type="text"
                    name="css"
                    value={field.css || ''}
                    onChange={handleChange}
                    className="border p-1 mb-2 w-full"
                />
            </label>
            {field.type === 'select' && (
                <label>
                    Data List (JSON format):
                    <textarea
                        name="dataList"
                        value={field.dataList || ''}
                        onChange={handleChange}
                        className="border p-1 mb-2 w-full"
                    />
                </label>
            )}
            <label>
                Width:
                <input
                    type="text"
                    name="width"
                    value={field.width || ''}
                    onChange={handleChange}
                    className="border p-1 mb-2 w-full"
                />
            </label>
        </div>
    );
};

export default FieldDetails;
