import React, { useState } from 'react';
import FormBuilder from './index';
import FieldDetails from './detail';
import ValidationProperties from './props';

const App = () => {
    const [fields, setFields] = useState([
        { id: '1', type: 'text', label: 'Titre Chart', name: 'title' },
        { id: '2', type: 'text', label: 'URL des données', name: 'dataUrl' },
    ]);
    const [selectedField, setSelectedField] = useState(null);

    const handleFieldUpdate = (id, updatedField) => {
        setFields(fields.map(field => (field.id === id ? updatedField : field)));
    };

    return (
        <div className="flex">
            <div className="w-2/3 p-4">
                <FormBuilder fields={fields} onFieldsChange={setFields} />
            </div>
            <div className="w-1/3 p-4">
                {selectedField ? (
                    <>
                        <FieldDetails
                            field={selectedField}
                            onUpdateField={handleFieldUpdate}
                        />
                        <ValidationProperties
                            field={selectedField}
                            onUpdateField={handleFieldUpdate}
                        />
                    </>
                ) : (
                    <p>Sélectionnez un champ pour voir ses propriétés.</p>
                )}
            </div>
        </div>
    );
};

export default App;
