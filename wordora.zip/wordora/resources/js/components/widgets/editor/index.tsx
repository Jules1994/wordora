import React from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';

const FormBuilder = ({ fields, onFieldsChange }) => {
    const handleDragEnd = (result) => {
        if (!result.destination) return;

        const reorderedFields = Array.from(fields);
        const [movedField] = reorderedFields.splice(result.source.index, 1);
        reorderedFields.splice(result.destination.index, 0, movedField);

        onFieldsChange(reorderedFields);
    };

    return (
        <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="fields">
                {(provided) => (
                    <div ref={provided.innerRef} {...provided.droppableProps}>
                        {fields.map((field, index) => (
                            <Draggable key={field.id} draggableId={field.id} index={index}>
                                {(provided) => (
                                    <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}
                                        className="bg-gray-100 p-4 mb-2 rounded shadow"
                                    >
                                        {field.label}
                                    </div>
                                )}
                            </Draggable>
                        ))}
                        {provided.placeholder}
                    </div>
                )}
            </Droppable>
        </DragDropContext>
    );
};

export default FormBuilder;
