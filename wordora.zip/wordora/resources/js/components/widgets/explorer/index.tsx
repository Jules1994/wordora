import axios from "axios";
import React from "react";
import { Searchbox } from "../search";
import View from "../../view";

const load_files = async(type, folder = null, page = 1, success, error)=> {
    try {   

        //const url = `/assets?${folder ? `folder_ref=${folder}&`: ""}type=${type}&responseType="json"`
        const url = `/assets?type=${type}&responseType="json"`
        const result = await axios.get(url)
        if(result.status !== 200) {
            throw "Error, somthing went wrong on server. Try later"
        }
        if(success) {
            success(result.data)
        }
    } catch (err) {
        if(error){
            error(err)
        }
    }
}

export const ExploreView = ({ type = "images", onChange, multiple, max = 5, base_url, renderItem }) => {

    const [files, setFiles] = React.useState({data:[], links: []});
    const [selected, setSelected] = React.useState([]);
    const [activePage, setActivePage] = React.useState(1)
    const [searchText, setSearchText] = React.useState([]);
    const [isLoading, setIsLoading] = React.useState(true)

    React.useEffect(()=> {

        load_files(type, undefined, activePage, (data)=> {
            setTimeout(()=> {
                console.log(data)
                setFiles(()=> { return {...data.files} })
                setIsLoading(false)
            }, 500)
        }, ({ message })=> {
            alert(message)
            setTimeout(()=> {
                setIsLoading(false)
            }, 500)
            return
        })
    }, [activePage])

    const assets = React.useMemo(()=> {
        return files.data.filter(file=> file.name.startsWith(searchText));
    }, [searchText, isLoading, activePage])

    const onSearchFile = async(mSearchText)=> {
        setSearchText(mSearchText)
    }

    const onPageChange = (_, { activePage }) => {
        setActivePage(activePage)
    }
    
    //console.log(files.links)
    return (
    <View
        flexDirection="column"
        justifyContent="center"
        alignItems="center"
        css={css_main_content}
    >
        {/*<View className="w-full h-auto px-4 py-4 rounded bg-slate-200">
            <h3>File explorer</h3>
        </View>*/}

        <View className="w-full ml-[1%] h-full p-4">

            <View flexDirection="row" justifyContent="space-between" alignItems="center">
                <View className="w-1/3">
                    <Searchbox placeholder="Type to search file" onSearchText={onSearchFile} />
                    {isLoading && <label>Chargement des données</label>}
                </View>

                <View className="p-0 rounded">
                    {false && <Pagination
                        activePage={activePage}
                        className="border-0 shadow-none"
                        totalPages={files.last_page}
                        onPageChange={onPageChange}
                    />}
                </View>
            </View>

            <br />
            <label className="mt-4 p-2 ">Result : </label>
            <br />

            <View className="w-full flex flex-row flex-wrap justify-start content-center laign-center items-start gap-4 pl-2 min-h-[30vh] max-h-[95vh] border-0 border-slate-100 rounded">
                {assets.slice(0, 12).map(((file, index)=> (

                    <a href="#" key={index.toString()} onClick={()=> {
                        const indexOf = selected.indexOf(index)
                        if(indexOf === -1) {
                            if(!multiple && selected.length === 1) {
                                selected.pop()
                                selected.push(index)
                            }else {
                                if(selected.length < max) {
                                    selected.push(index)
                                }
                            }
                        }else {
                            selected.splice(indexOf, 1)
                        }
                        if(onChange) {
                            const filesSelected = []
                            for(let i = 0; i < selected.length; i++) {
                                filesSelected.push(files.data[selected[i]])
                            }
                            onChange(filesSelected)
                        }
                        setSelected(selected.slice(0))
                    }}
                        className={`border-2 ${selected.indexOf(index) === -1 ? "border-slate-200": "border-sky-600"} p-1 rounded transition-colors duration-200 hover:border-sky-600`}
                    >
                        {renderItem({item: file, index})}
                    </a>
                )))}
            </View>
        </View>
    </View>
    );
};

const css_main_content = `

    width: 100%;
    height: 100%;
    border-radius: 5px;
    background-color: white;
    transition: 200ms;
    position: relative;
    
    &:hover {
        transform: scale(3deg);
    }
`;


