import axios, { AxiosProgressEvent } from "axios";
import React from "react";
import View from "../../view";

const getType = (file) => {

  if(typeof(file) === "string") {

    for(var ext of ["png", "jpg", "jpeg", "webp", "avif"]) {
      if(file.toLocaleLowerCase().endsWith(ext)) {
        return "image"
      }
    }
    
    return "video"
  }
  return  file.type
}

export const MultipleUploadFilesbox = ({ baseUrl = "/", folder, onCompleteUpload })=> {

    const [files, setFiles] = React.useState([])
    const handleChangeFile = async (e) => {
  
      setFiles([...files, ...e.target.files])
    };

    const onFileUploadCompletion = async(file)=> {
      if(onCompleteUpload) {
        onCompleteUpload(file)
      }
    }
  
    return (
      <View className="w-full p-8 min-h-max">

          <UploadInput
            folder={folder}
            baseUrl={baseUrl}
            onUploadComplete={(asset)=> {
              setFiles([asset, ...files])
            }}
          />

          <View className="relative flex flex-col items-center justify-center w-full px-8 border-2 border-dotted rounded-md h-44 border-slate-400">
            <h1 className="text-xl text-center">Drop your files to upload them</h1>
            <span name="upload" size="big" color="blue" />
            <input type="file" multiple className="absolute top-0 left-0 w-full h-full opacity-0" onChange={handleChangeFile}/>
            <p className="mt-6 text-slate-500">Taille de fichier maximale pour le téléversement : 40 Mo.</p>
          </View>
          <View className="flex flex-row flex-wrap w-full gap-2 mt-8">

            {files.map((file, index)=>
              <UploadFileboxView
                key={index.toString()}
                folder={folder}
                baseUrl={baseUrl}
                defaultFile={file}
                type={getType(file)}
                onFileUploadCompletion={onFileUploadCompletion}
              />)}

          </View>
          <br/>
          {files.length > 0 && <View flexDirection="row" justifyContent="flex-end" alignItems="flex-end">
            <button onClick={onCompleteUpload}>
              Fermer
            </button>
          </View>}
      </View>
    )
}

export const UploadInput = ({ onUploadComplete, baseUrl, folder = undefined })=> {

  const ref = React.useRef(null)
  const [uploading, setUploading] = React.useState(false)
  const handleUpload = async()=> {

    try {

      if(ref.current.value.trim() === "") {
        alert("Please, type url image")
        return
      }


      onUploadComplete(ref.current.value)
      ref.current.value = ""
      setUploading(false)

      /*setUploading(true)
      const { data } = await upload(`${baseUrl}upload/url?folder_uid=${folder}`, ref.current.value, (progress_value)=> {})
      //onUploadComplete(data)*/

    }catch(e) {
      alert(e.message)
    }
  }

  return (
    <div className="w-full relative mb-2 border-slate-300 rounded border-2">
      <input
        type="text"
        ref={ref}
        placeholder="https://www.europarl.europa.eu/images/20240205PHT17432-cl.png"
        className="w-full h-full p-3 border-0 rounded"
      />
      
      <button
        icon={`${uploading ? "circle notch": "upload"}`}
        loading={uploading}
        size="mini"
        className="absolute top-1 right-2"
        primary
        onClick={handleUpload}
      >
        x
      </button>
    </div>
  )
}
  
export const UploadFileboxView = React.memo(({ defaultFile, baseUrl, folder, type = "document", onFileUploadCompletion })=> {

  const [file, setFile] = React.useState(defaultFile)
  const [progress, setProgress] = React.useState(true)
  const [uploaded, setUploaded] = React.useState(false)


  React.useEffect(()=> {

      (async()=> {
        if(!uploaded) {

            try {

              const finalURL = `${baseUrl}${typeof(file) === 'string' ? "uploads/url": "uploads"}?folder_uid=${folder}`
              const res = await upload(finalURL, file, (progress_value)=> {
                setProgress(progress_value)
              })

              console.log(res?.data)
              setFile(file=> res?.data)
              setUploaded(true)
              if(onFileUploadCompletion) onFileUploadCompletion(res?.data)
            }catch(e) {
              alert(e.message)
            }
        }
      })()
  }, [])

  const FileElementbox = <>
      {type.indexOf("image") !== -1 && <img className="object-cover w-full h-full rounded-md" alt="Jeune afrique" loading="lazy" src={`${baseUrl}${file.path}`} />}
      {type.indexOf("video") !== -1 && <video className="object-cover w-full h-full rounded-md" controls src={`${baseUrl}${file.path}`} />}
      {type.indexOf("audio") !== -1 && <audio className="object-contain w-full h-full rounded-md" controls src={`${baseUrl}${file.path}`} />}
      {type.indexOf("image") === 0 && <span name="file" size="large"/>}
  </>


  return <View className="w-[32%] h-32 flex flex-col justify-center items-center border-2 rounded-md bg-slate-50 ">
      {uploaded ? FileElementbox : <input type='slider' inverted color='orange' percent={`${progress}`} size='small' className="w-[90%] mt-6" style={{backgroundColor: "lightgrey" }}/>}
  </View>
})

/*export const upload = async(url, file, onProgress)=> {

  try {

      //console.log(file)
      const [file_type, extension] = file.type.split("/")
      const formData = new FormData();
      formData.append("file", file);
      formData.append("metadata", JSON.stringify({
        name: file.name,
        size: file.size,
        extensions: extension,
        file_type: `${file_type}s`
      }));

      const res = await axios.post(url, formData, {
        headers: {
            "Content-Type": "multipart/form-data",
        },
        onUploadProgress: (progressEvent)=> {
            var percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total)
            if(onProgress) {
              onProgress(percentCompleted)
            }
        }
      })
      console.log(res)
      
      return res
  }catch(e) {
      alert(e.message)
      return null
  }
}*/

export const upload = async(url, file, onProgress)=> {

  try {

      const formData = new FormData();
      if(typeof(file) === "string") {
        formData.append("url", file);
      }else {

        const [file_type, extension] = file.type.split("/")
        formData.append("file", file);
        formData.append("metadata", JSON.stringify({
          name: file.name,
          size: file.size,
          extensions: extension,
          file_type: `${file_type}s`
        }));
      }

      const res = await axios.post(url, formData, {
        headers: {
            "Content-Type": "multipart/form-data",
        },
        onUploadProgress: (progressEvent: AxiosProgressEvent)=> {
            var percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent?.total)
            if(onProgress) {
              onProgress(percentCompleted)
            }
        }
      })
      
      return res
  }catch(e) {
      alert(e.message)
      return null
  }
}
