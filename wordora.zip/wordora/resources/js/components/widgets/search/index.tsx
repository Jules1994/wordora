import React from "react";
import View from "../../view";

export function Searchbox({
  maxItems = 10,
  onFilter = null,
  placeholder,
  renderItem,
  onSearchText = null,
  rootComponent = null,
  defaultValue = null,
  defaultData = [],
}) {
  var ListElements = null;
  const RootComponent = rootComponent
    ? rootComponent
    : ({ children }) => <ul>{children}</ul>;

  const Item = renderItem ? renderItem : ({ item }) => <li>{item}</li>;

  var data = defaultData;
  var inputRef = React.useRef(null);
  var [filteredData, setFilteredData] = React.useState(
    defaultData.slice(0, maxItems)
  );
  var [open, setOpen] = React.useState(false);

  const handleGainFocus = React.useCallback(() => {
    setOpen(true);
  }, [setOpen]);

  const handleLossFocus = React.useCallback(() => {
    setOpen(() => false);
  }, [setOpen]);

  const onTextChange = React.useCallback(
    (e) => {
      const textSearch = e.target.value;
      if(onSearchText) {
        onSearchText(textSearch)
        return 
      }
      if (onFilter) {
        const results = onFilter({ items: data, textSearch });
        setFilteredData(results.slice(0, maxItems));
      }
    },
    [filteredData]
  );

  ListElements = (
    <>
      {filteredData.map((el, index) => (
        <Item key={index.toString()} item={el} index={index} />
      ))}
    </>
  );

  return (
    <View css={css_search_content} open={open}>
      <View css={css_search}>
        <input
          ref={inputRef}
          defaultValue={defaultValue}
          placeholder={placeholder}
          onFocus={handleGainFocus}
          onBlur={handleLossFocus}
          onChange={onTextChange}
        />
        <Icon name="search" />
      </View>
      <View css={css_search_result_content} hidden={onFilter === null}>
        <RootComponent>{ListElements}</RootComponent>
      </View>
    </View>
  );
}

const css_search_content = ({ open }) => `
  position: relative;
  width: 100%;
  border-radius: 7px;
  
  
  & > div {
    ${!open ? "border-radius: 5px;" : null}
    ${open ? "border: 1px solid lightgrey;" : null}
  }
  
  & > div:first-child > input {
    ${!open ? "border-radius: 5px;" : null}
  }
  
  & > div:last-child {
      display: ${open ? "block" : "none"};
  }
  
`;

const css_search = `
  
  position: relative;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
  
  width: 100%;
  padding: 3px;
  
  background-color: white;
  
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  
  
  border: 1px solid #f1f1f1;
  
  & > input {
    width: 95%;
    padding: 7px;
    
    outline: none;
    
    border: none;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    
    color: rgba(0, 0, 0, .9);
  }
  
  lg {
      
  }
  
`;

const css_search_result_content = ({ hidden })=> `
  position: absolute;
  left: 0px;
  top: 100%;
  
  visibility: ${hidden ? "hidden": "visible"};
  text-align: left;
  
  
  z-index: 9999;
  
  width: 100%;
  min-height: 30px;
  transition: 200ms;
  
  background-color: #f1f1f1;
  
  
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  
  border: 1px solid lightgrey;
  
  & > ul {
    width: 100%;
    padding: 0px;
    margin: 0px;
    list-style-type: none;
  }
  
  & > ul > li {
    padding: 10px;
    border-bottom: 1px solid #f1f1f1;
  }
  
`;
