import React from 'react'
import Form from '../form'
import { Link } from '@inertiajs/react'

export const PanelForm = React.forwardRef(({ defaultData, config, content, onSubmit, back = null }: any, ref) => {

    const formRef = React.useRef<any>()

    return (
        <div className="w-[25%] mt-8 flex flex-col border-2 bg-white border-slate-200 rounded">

            <div className="px-6 py-4 flex flex-row justify-between items-center border-b-2 border-slate-100 dark:border-b-slate-700">
                {content && content.title &&
                    <div className={`flex flex-row justify-start items-center w-[90%] gap-2`}>
                        <h4 className="text-black dark:text-white font-semibold"> {content.title}</h4>
                    </div>
                }
            </div>

            <div className="w-full px-8 py-4">
                {content && content.subTitle && <h2 className="text-gray-800 xl:text-sm">{content.subTitle}</h2>}
                {content && content.description && <h3 className="text-gray-500 xl:text-sm">{content.description}</h3>}
            </div>

            <div className="w-full px-6">
                <Form
                    ref={ref}
                    config={config}
                    defaultData={defaultData}
                />
            </div>

            <br />

            <div className="w-full py-[3%] px-[5%] flex flex-row gap-x-4 justify-between items-center border-t-2 border-slate-100 dark:border-slate-900">
                {back &&
                    <Link href={`${back}`} className='flex flex-row justify-center items-center gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-8 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700'>
                        Cancel
                    </Link>
                }

                {onSubmit &&
                    <button onClick={onSubmit} className="text-center focus:outline-none text-white xl:text-md bg-green-700 hover:bg-green-900 focus:ring-6 focus:ring-green-300 rounded-lg text-sm px-8 py-1.5 dark:bg-green-700 dark:hover:bg-green-800 dark:focus:ring-green-900">
                        Validate
                    </button>
                }

            </div>

        </div>
    )
})
