import React, { useState, useEffect } from 'react';
import Toolbar from '../toolbar';

function DataTable({ data, columns }) {
    const [filteredData, setFilteredData] = useState(data);
    const [visibleColumns, setVisibleColumns] = useState(columns);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage] = useState(10);

    const onSearch = (term) => {
        const lowercasedTerm = term.toLowerCase();
        const filtered = data.filter((row) =>
            Object.values(row).some((value: any) => value.toString().toLowerCase().includes(lowercasedTerm))
        );
        setFilteredData(filtered);
    };

    const onAdd = () => {
        // Logique pour ajouter une nouvelle entrée
    };

    const onDelete = () => {
        // Logique pour supprimer des éléments
    };

    const onSort = (order) => {
        const sortedData = [...filteredData].sort((a, b) => (order === 'asc' ? a.id - b.id : b.id - a.id));
        setFilteredData(sortedData);
    };

    const onColumnToggle = (column, isVisible) => {
        setVisibleColumns((prev) =>
            isVisible ? [...prev, column] : prev.filter(col => col !== column)
        );
    };

    const onMultiSelect = () => {
        // Logique pour la sélection multiple
    };

    const startIndex = (currentPage - 1) * itemsPerPage;
    const currentPageData = filteredData.slice(startIndex, startIndex + itemsPerPage);

    return (
        <div>
            <Toolbar
                onSearch={onSearch}
                onAdd={onAdd}
                onDelete={onDelete}
                onSort={onSort}
                onColumnToggle={onColumnToggle}
                onMultiSelect={onMultiSelect}
            />
            <table className="w-full border-collapse">
                <thead>
                    <tr>
                        {visibleColumns.map((column) => (
                            <th key={column} className="border p-2">{column}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {currentPageData.map((row, index) => (
                        <tr key={index}>
                            {visibleColumns.map((column) => (
                                <td key={column} className="border p-2">{row[column]}</td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
            <div className="flex justify-center mt-4">
                <button
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    className="px-4 py-2 border rounded"
                >
                    Précédent
                </button>
                <span className="px-4">{currentPage}</span>
                <button
                    onClick={() => setCurrentPage((prev) => prev + 1)}
                    className="px-4 py-2 border rounded"
                >
                    Suivant
                </button>
            </div>
        </div>
    );
}

export default DataTable;
