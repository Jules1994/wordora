import React, { useState } from 'react';

export function Toolbar({ onSearch, onAdd, onDelete, onSort, onColumnToggle, onMultiSelect }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [sortOrder, setSortOrder] = useState('asc');
    const [selectedColumns, setSelectedColumns] = useState({
        column1: true,
        column2: true,
        column3: true,
    });

    const handleSearch = (event) => {
        setSearchTerm(event.target.value);
        onSearch(event.target.value);
    };

    const toggleSortOrder = () => {
        const newOrder = sortOrder === 'asc' ? 'desc' : 'asc';
        setSortOrder(newOrder);
        onSort(newOrder);
    };

    const handleColumnToggle = (column) => {
        const updatedColumns = { ...selectedColumns, [column]: !selectedColumns[column] };
        setSelectedColumns(updatedColumns);
        onColumnToggle(column, updatedColumns[column]);
    };

    return (
        <div className="flex items-center gap-4 p-4 bg-gray-200 border-b">
            {/* Search Input */}
            <input
                type="text"
                value={searchTerm}
                onChange={handleSearch}
                placeholder="Search..."
                className="px-2 py-1 border rounded"
            />

            {/* Add Button */}
            <button
                onClick={onAdd}
                className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
            >
                Ajouter
            </button>

            {/* Multi-select Toggle */}
            <button
                onClick={() => onMultiSelect(true)}
                className="bg-gray-500 text-white px-3 py-1 rounded hover:bg-gray-600"
            >
                Sélectionner plusieurs
            </button>

            {/* Delete Button */}
            <button
                onClick={onDelete}
                className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
            >
                Supprimer
            </button>

            {/* Sort Button */}
            <button
                onClick={toggleSortOrder}
                className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600"
            >
                {sortOrder === 'asc' ? 'Trier ↑' : 'Trier ↓'}
            </button>

            {/* Column Toggle Menu */}
            <div className="relative">
                <button className="bg-gray-500 text-white px-3 py-1 rounded hover:bg-gray-600">
                    Gérer les colonnes
                </button>
                <div className="absolute bg-white border shadow-lg mt-2 w-48 p-2 rounded">
                    {Object.keys(selectedColumns).map((column) => (
                        <div key={column} className="flex items-center">
                            <input
                                type="checkbox"
                                checked={selectedColumns[column]}
                                onChange={() => handleColumnToggle(column)}
                                className="mr-2"
                            />
                            <label>{column}</label>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default Toolbar;
