/* eslint-disable prettier/prettier */
import React from 'react'
//import { Link } from '@inertiajs/react'

export const PaymentMethod = React.memo(({ content }: any) => (
  <div className="w-full relative flex flex-col p-8 gap-y-4 h-auto dark:bg-slate-800 border-2 border-grey-200 rounded hover:shadow-xl hover:shadow-green-200 hover:border-green-500 transition-all duration-200">

    <img src={content.img} className='w-20 h-20 object-contain' />

    <div className='w-full'>
      <h1 className="dark:text-white font-medium">{content.name}</h1>
      <p className="font-light text-xs text-slate-400 line-clamp-2">{content.desc}</p>
    </div>


    <label className="inline-flex items-center cursor-pointer">
      <input type="checkbox" value="" defaultChecked className="sr-only peer" />
      <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
      <span className="ms-3 text-xs font-light text-gray-900 dark:text-gray-300">Active</span>
    </label>

    {/*<Link href="#" className="absolute top-8 right-4 ml-2 transition-all">
      <svg className="w-6 h-6 text-gray-800 dark:text-gray-300" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m10 16 4-4-4-4" />
      </svg>
    </Link>*/}

  </div>
))