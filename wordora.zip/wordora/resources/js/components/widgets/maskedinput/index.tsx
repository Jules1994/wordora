import React, { useState } from 'react';

export function MaskedInput({ name, type, defaultValue, className, maskType, placeholder, onChange }) {
    const [value, setValue] = useState('');

    // Fonction de mise en forme pour les différents masques
    const formatValue = (input) => {
        // Supprimer tous les espaces pour gérer le formatage
        let cleaned = input.replace(/\D+/g, '');

        // Appliquer les masques en fonction du type spécifié
        switch (maskType) {
            case 'credit-card':
                // Regrouper par blocs de 4 chiffres
                return cleaned.replace(/(\d{4})(?=\d)/g, '$1 ');
            case 'phone':
                // Format: (123) 456-7890
                return cleaned
                    .replace(/^(\d{3})(\d{3})(\d{4})$/, '($1) $2-$3')
                    .substring(0, 14); // Limiter la longueur
            case 'currency':
                // Affichage de monnaie, format simple (USD par exemple)
                return new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: 'USD',
                }).format(Number(cleaned) / 100); // Convertir en décimales
                
            default:
                return input;
        }
    };

    const handleInputChange = (event) => {
        const formattedValue = formatValue(event.target.value);
        setValue(formattedValue);
        onChange(formattedValue); // Transmettre la valeur masquée
    };

    return (
        <input
            name={name}
            value={value}
            type={type}
            defaultValue={defaultValue}
            onChange={handleInputChange}
            placeholder={placeholder}
            className={className}
        />
    );
}

export default MaskedInput;
