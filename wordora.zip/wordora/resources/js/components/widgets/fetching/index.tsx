import React from 'react'

export const State = { FETCHING_DATA: 1, NO_DATA: 2, LOADED_DATA: 3 }

export const NoData = ({ iconComponent }) => {
  return (
    <div className="w-full border-2 px-4 py-8 flex flex-col gap-y-2 justify-center items-center border-dotted rounded-md border-slate-200">
      {iconComponent}
      <div>
        <h1 className="text-green-400 text-center text-sm">No data to show</h1>
        <p className="text-slate-400 text-center text-xs">
          it may take up to 24h hours for data to show
        </p>
      </div>
    </div>
  )
}

export const FetchingData = ({ title, content, iconComponent }) => {
  return (
    <div className="w-full py-8  flex flex-col justify-center items-center">
      {iconComponent}
      <div className="w-full space-y-2">
        <h1 className="text-green-400 text-center text-sm">{title}</h1>
        <p className="text-slate-400 text-center text-xs">{content}</p>
      </div>
    </div>
  )
}

export const SeederData = ({ state, children, NoDataComponent, FetchingComponent }: any) => (
  <>
    {state === State.FETCHING_DATA && FetchingComponent}
    {state === State.NO_DATA && NoDataComponent}
    {state === State.LOADED_DATA && children}
  </>
)

export const Stat = ({ iconComponent, title, value, desc, children }) => {
  const clonesChildren = React.Children.toArray(children)
  return (
    <div className="w-full flex flex-col p-8 gap-y-3 border-2 border-grey-200 rounded hover:shadow-xl hover:shadow-green-200 hover:border-green-500 transition-all duration-200">
      <div className="w-full flex flex-row items-center gap-x-2">
        {iconComponent}
        <h1 className="text-slate-700 font-medium">{title}</h1>
      </div>
      <div className="w-full flex flex-col gap-y-1">
        <h1 className="text-slate-500 text-xs font-thin">{desc}</h1>
        <h2 className="text-grey-700 font-bold text-xl">{value}</h2>
      </div>

      {clonesChildren.length > 0 && <div className="w-full mt-8">{clonesChildren}</div>}
    </div>
  )
}
