import {
    Chart,
    CategoryScale,
    LinearScale,
    BarElement,
    PointElement,
    LineElement,
    ArcElement,
    Title,
    Filler,
    Tooltip,
    Legend,
} from 'chart.js';
import React from "react"
import axios from "axios"
import { Bar, Line, Pie, Doughnut, Bubble } from 'react-chartjs-2';
import View from '../../view';


Chart.register(
    CategoryScale,
    ArcElement,

    LinearScale,
    BarElement,

    PointElement,
    LineElement,

    Filler,

    Title,
    Tooltip,
    Legend
);


export const Chartbox = React.memo(({ title, chartType, match, url, method = "GET", onDelete }) => {

    const [data, setData] = React.useState(null)
    const [forceUpdate, setForceUpdate] = React.useState(false)
    React.useEffect(() => {

        const loadData = async () => {

            try {
                const res = await axios[method.toLowerCase()](url)
                setData(() => res.data)
                setForceUpdate(true)
            } catch (e) {
                alert(e.message)
            }
        }

        if (!forceUpdate) {
            loadData()
        }
    })

    if (data === null) {
        return null
    }

    return (
        <OverviewCard
            match={match}
            headComponent={<HeaderCardbox icon="Bar Chart" title={title} onDelete={onDelete} />}
            bottomComponent={null} children={undefined}        >
            <div className='w-full p-2'>
                {
                    chartType === "dougnut" &&
                    <Doughnut
                        options={{
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }}
                        data={data}
                    />
                }

                {
                    (chartType === "pie") &&
                    <Pie
                        options={{
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }}
                        data={data}
                    />
                }

                {
                    (chartType === "hbar" || chartType) === "vbar" &&
                    <Bar
                        data={data}
                    />
                }

                {
                    (chartType === "line" || chartType === "fline" || chartType === "fxline") &&
                    <Line
                        options={{
                            responsive: true,
                            plugins: {
                                legend: {
                                    position: 'top',
                                },
                                title: {
                                    display: false,
                                    text: 'Chart.js Line Chart',
                                },
                            },
                        }}
                        data={data}
                    />
                }


                {
                    (chartType === "bubble") &&
                    <Bubble options={{
                        scales: {
                            y: {
                                beginAtZero: true,
                            },
                        },
                    }}
                        data={data}
                    />
                }


                {
                    (chartType === "tables") &&
                    <tableView
                        data={data}
                    />
                }

            </div>
        </OverviewCard>
    )
})

export const tableView = ({ data }) => {

    return (
        <table basic='very' celled collapsing>
            <tableHeader>
                <tr>
                    <th>Name</th>
                    <th>Registration Date</th>
                    <th>E-mail address</th>
                    <th>Premium Plan</th>
                </tr>
            </tableHeader>

            <tableBody>
                <tr>
                    <td>John Lilki</td>
                    <td>September 14, 2013</td>
                    <td>jhlilk22@yahoo.com</td>
                    <td>No</td>
                </tr>
                <tr>
                    <td>Jamie Harington</td>
                    <td>January 11, 2014</td>
                    <td>jamieharingonton@yahoo.com</td>
                    <td>Yes</td>
                </tr>
                <tr>
                    <td>Jill Lewis</td>
                    <td>May 11, 2014</td>
                    <td>jilsewris22@yahoo.com</td>
                    <td>Yes</td>
                </tr>
            </tableBody>
        </table>
    )
}

export const Statbox = React.memo(({ title, url, method = "GET", onDelete }) => (
    <Cardbox
        backgroundColor="white"
        headComponent={<HeaderCardbox icon="box" title="Title Stat" onDelete={onDelete} />}
        bottomComponent={null} 
    >
        <View style={Styles.card.main_content} clasName="w-full">
            <label style={Styles.card.sub_title}>Header Title</label>
            <h2 style={{ textAlign: "left" }}>12000</h2>
            {false && <View style={Styles.card.content}></View>}
        </View>
    </Cardbox>
))

export const HeaderCardbox = ({ icon, title, onDelete }) => (
    <View
        flexDirection="row"
        justifyContent="space-between"
        alignItems="center"
        style={{
            borderBottomWidth: 1,
            paddingBlock: 5
        }}
    >
        {/*<Button icon={icon} size="tiny" />*/}
        <label style={{ marginLeft: 10, fontSize: "1em", fontWeight: "bold" }}>
            {title}
        </label>
        <button icon="angle down" size='mini' basic onClick={onDelete}>
            Delete
        </button>
    </View>
);

const Cardbox = ({ children, headComponent, bottomComponent, backgroundColor }) => (
    <View css={css_card_box} style={{ backgroundColor }}>
        {headComponent}
        {children}
        {bottomComponent}
    </View>
);

export const OverviewCard = ({ children, headComponent, bottomComponent, match }) => (
    <View css={css_card_box} match={match}>
        {headComponent}
        {children}
        {bottomComponent}
    </View>
);

const Styles = {
    h3: { textAlign: "left" },
    card: {
        sub_title: { color: "grey", textAlign: "left", marginTop: 10 },
        main_content: { width: "100%", padding: 5, gap: 5 },
        content: {
            border: "2px dotted lightgrey",
            borderRadius: 5,
            marginTop: 10,
            minHeight: 150,
        },
    },
};

const css_card_box = (match) => `
      width: ${match ? 'auto' : '24%'};
      align-self: start;
      min-height: 50px;
      height: auto;
      border-radius: 5px;
      background-color: white;
      transition: 200ms;
      border: 1px solid #E6E8EB;
      
      &:hover {
          border: 1px solid rgba(144, 238, 144, .4);
          box-shadow: 0px 0px 5px rgba(144, 238, 144, .7);
      }
  `;