import React from "react";

export default function({  }) {
    return <div className="w-full h-screen">
        <h1>Ceci est plugin</h1>
    </div>
}