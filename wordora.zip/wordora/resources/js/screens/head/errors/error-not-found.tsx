import React from "react"

export default function NotFound() {
    return (
      <>
        <div className="container">
          <div className="title">Page not found</div>
  
          <span>This page does not exist.</span>
        </div>
      </>
    )
  }
  