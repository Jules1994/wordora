/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/head'
import Toolbar from '../../../components/widgets/toolbar'
import { PanelForm } from '../../../components/widgets/panelform'

const FormData = {
    "layout": "row",
    "sections": [
        {
            "title": "Personal",
            "layout": "column",
            "fields": [
                {
                    "type": "input",
                    "name": "firstname",
                    "label": "Firstname",
                    "placeholder": "john.doe",
                    "validation": {
                        "required": true,
                        "minLength": 10,
                        "maxLength": 30
                    }
                },
                {
                    "type": "input",
                    "name": "lastname",
                    "label": "Lastname",
                    "placeholder": "johndoe@gmail.com",
                    "validation": {
                        "required": true,
                        "minLength": 10,
                        "maxLength": 30
                    }
                },

                {
                    "type": "input",
                    "name": "email",
                    "label": "Email",
                    "placeholder": "johndoe@gmail.com",
                    "validation": {
                        "required": true,
                        "email": true
                    }
                },

                {
                    "type": "input",
                    "name": "phones",
                    "label": "Phone",
                    "placeholder": "(+241 0X 00 00 00)",
                    "validation": {
                        "required": true
                    }
                }

            ]
        },

        {
            "title": "System",
            "layout": "column",
            "fields": [
                {
                    "type": "input",
                    "name": "name",
                    "label": "Identifiant connexion",
                    "placeholder": "john.doe",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 30
                    }
                },

                /*{
                    "type": "select",
                    "name": "role_id",
                    "label": "Role",
                    "source": {
                        "type": "url",
                        "url": "/roles?format=json"
                    }
                },*/

                {
                    "type": "input",
                    "name": "displayname",
                    "label": "Display name",
                    "placeholder": "John Doe",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 30
                    }
                },

                {
                    "type": "input",
                    "secureText": true,
                    "name": "password",
                    "label": "Mot de passe",
                    "placeholder": "***************",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 30
                    }
                },

                {
                    "type": "input",
                    "name": "password_confirm",
                    "label": "Confirme mot de passe",
                    "secureText": true,
                    "placeholder": "**************",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 30
                    }
                },

            ]
        }
    ]
}

export const UserForm = ({ user }: any) => {
    const ref = React.useRef<any>(null)

    const handleSubmit = ()=> {
        if(ref) {
            const { value, errors } = ref.current?.submit()
            if(ref.current?.hasErrors()) {
                alert(JSON.stringify(errors))
            }else {
                if(user) {
                    router.put("/users/" + user.id + "/update", value)
                }else {
                    if(value.password !== value.password_confirm) {
                        alert("Passwords don't match")
                        return 
                    }
                    router.post("/users/create", value)
                }
            }
        }
    }

    return (
        <div className="w-full flex flex-col justify-center items-center">
            <PanelForm
                ref={ref}
                content={{
                    title: `${user ? 'Edit' : 'Create'} user`
                }}
                onSubmit={handleSubmit}
                defaultData={user}
                config={FormData}
            />
        </div>)
}

UserForm.layout = page => <Layout children={page} title="Organization" />
export default UserForm
