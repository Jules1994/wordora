/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/overview'
import { PanelForm } from '../../../components/widgets/panelform'

const FormDataFields = {
    "layout": "row",
    "sections": [
        {
            "layout": "column",
            "fields": [
                {
                    "type": "input",
                    "name": "title",
                    "label": "Title",
                    "placeholder": "Voie de contournement du Grand Libreville ...",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 200
                    }
                }
            ]
        }
    ]
}

const Forms = ({ post, error }) => {

    const ref = React.useRef<any>(null)

    const handleSubmit = async () => {
        if (ref) {

            try {
                const { value } = ref.current?.submit()
                console.log(value)
                router.post("/admin/posts/create", value, {
                    forceFormData: true,
                })

            } catch (e) {
                alert(e.message)
            }
        }
    }

    return (
        <div className="w-full flex flex-col justify-center items-center">
            <PanelForm
                ref={ref}
                content={{
                    title: `${post ? 'Edit' : 'Create'} article`
                }}
                onSubmit={handleSubmit}
                defaultData={post}
                config={FormDataFields}
            />

            {
                error && (
                    <label className='bg-red-200 text-sm text-red-700 py-2 px-4 rounded mt-4'>{error}</label>
                )
            }
        </div>)
}



Forms.layout = page => <Layout children={page}  />
export default Forms