/* eslint-disable prettier/prettier */
import React from 'react'
import { router } from '@inertiajs/react'
import Layout from '../../../layouts/head'
import { PanelForm } from '../../../components/widgets/panelform'
import axios from 'axios'
import { useStorage } from '../../../libs/api-react'

const FormDataFields = {
    "layout": "row",
    "sections": [
        {
            "layout": "column",
            "fields": [
                {
                    "name": "theme_file",
                    "type": "documentPicker",
                    "placeholder": "Click or drag'and drop file here"
                }
            ]
        }
    ]
}

export const ThemeForm = ({ theme, error }: any) => {

    const storage = useStorage()
    const ref = React.useRef<any>(null)

    const handleSubmit = async () => {
        if (ref) {

            try {
                const { value } = ref.current?.submit()
                console.log(value)

                /*const formData = new FormData();
                formData.append('plugin_file', value.plugin_file);

                const res = await axios.post("/plugins/upload", formData, {
                    headers: { 'Content-Type': 'multipart/form-data' },
                    onUploadProgress: (e) => {
                        console.log(e.progress)
                    }
                });

                if (res.status === 200) {
                    alert(res.data.message)
                }*/

                router.post("/admin/themes/create", value, {
                    forceFormData: true,
                })

            } catch (e) {
                alert(e.message)
            }
        }
    }

    return (
        <div className="w-full flex flex-col justify-center items-center">
            <PanelForm
                ref={ref}
                content={{
                    title: `${theme ? 'Edit' : 'Create'} Theme`
                }}
                onSubmit={handleSubmit}
                defaultData={theme}
                config={FormDataFields}
            />

            {
                error && (
                    <label className='bg-red-200 text-sm text-red-700 py-2 px-4 rounded mt-4'>{error}</label>
                )
            }
        </div>)
}

ThemeForm.layout = page => <Layout children={page} title="Upload theme" />
export default ThemeForm
