import React from "react"
import { Head, Link, router } from '@inertiajs/react'
import Form from "../../../components/widgets/form"

const FormData = {
    "layout": "row",
    "sections": [
        {
            "layout": "column",
            "fields": [
                {
                    "type": "input",
                    "name": "token",
                    "label": "Token",
                    "placeholder": "748455",
                    "validation": {
                        "required": true,
                        "minLength": 6,
                        "maxLength": 6
                    }
                }
            ]
        },
    ]
}

export default ({ error }) => {

    const ref = React.useRef<any>(null);

    const handleSubmit = () => {
        if (ref) {
            const { value, errors } = ref.current?.submit()
            if (ref.current?.hasErrors()) {
                alert(JSON.stringify(errors))
            } else {
                router.post("/admin/auth/twofactor-validator", value)
            }
        }
    }

    return (
        <div className='w-full h-auto min-h-screen bg-[#f1f1f1] dark:bg-slate-900'>
            <Head title="Login" />

            <main className='w-screen h-screen flex flex-row justify-center items-start'>
                <section className='xl:w-[35%] xl:px-[7%] h-full relative flex flex-col justify-center items-center gap-y-10 bg-inherit dark:bg-slate-800 border-x-0 border-slate-200 dark:border-slate-800 pt-6'>

                    <div className="w-full text-center flex flex-col justify-center items-center">
                        <svg
                            className='w-16 h-16'
                            viewBox="0 0 109 113"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M63.7076 110.284C60.8481 113.885 55.0502 111.912 54.9813 107.314L53.9738 40.0627L99.1935 40.0627C107.384 40.0627 111.952 49.5228 106.859 55.9374L63.7076 110.284Z"
                                fill="url(#paint0_linear)"
                            />
                            <path
                                d="M63.7076 110.284C60.8481 113.885 55.0502 111.912 54.9813 107.314L53.9738 40.0627L99.1935 40.0627C107.384 40.0627 111.952 49.5228 106.859 55.9374L63.7076 110.284Z"
                                fill="url(#paint1_linear)"
                                fillOpacity="0.2"
                            />
                            <path
                                d="M45.317 2.07103C48.1765 -1.53037 53.9745 0.442937 54.0434 5.041L54.4849 72.2922H9.83113C1.64038 72.2922 -2.92775 62.8321 2.1655 56.4175L45.317 2.07103Z"
                                fill="#3ECF8E"
                            />
                            <defs>
                                <linearGradient
                                    id="paint0_linear"
                                    x1="53.9738"
                                    y1="54.974"
                                    x2="94.1635"
                                    y2="71.8295"
                                    gradientUnits="userSpaceOnUse"
                                >
                                    <stop stopColor="#249361" />
                                    <stop offset="1" stopColor="#3ECF8E" />
                                </linearGradient>
                                <linearGradient
                                    id="paint1_linear"
                                    x1="36.1558"
                                    y1="30.578"
                                    x2="54.4844"
                                    y2="65.0806"
                                    gradientUnits="userSpaceOnUse"
                                >
                                    <stop />
                                    <stop offset="1" stopOpacity="0" />
                                </linearGradient>
                            </defs>
                        </svg>
                        <h1 className='text-2xl dark:text-white'>Adresse mail page</h1>
                    </div>


                    <div className="w-[90%] xl:w-[80%] flex flex-col gap-9 bg-white border border-green-300 hover:border-green-400 shadow-md shadow-green-200 mx-auto py-8 rounded">

                        <div className='w-full flex flex-col justify-center items-center px-10'>
                            <Form
                                ref={ref}
                                config={FormData}
                            />
                            <button onClick={handleSubmit} className="w-full text-center focus:outline-none text-white xl:text-md bg-green-700 hover:bg-green-900 focus:ring-6 focus:ring-green-300 rounded-lg text-sm px-0 py-2.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                                Validation de l'adresse mail
                            </button>
                        </div>

                    </div>

                    {
                        error && (
                            <label className='bg-red-200 text-sm text-red-700 py-2 px-4 rounded'>{error}</label>
                        )
                    }

                    {/******Separator *********/}


                    <p className='text-center xl:text-xs text-slate-600'>
                        Designed and developed by AKORA © 2024. Tous droits réservés.
                    </p>

                </section>
            </main>
        </div>
    )
}