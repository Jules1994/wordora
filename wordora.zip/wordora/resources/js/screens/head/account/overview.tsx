/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/account'
import { Project } from '../../../components/widgets/project'

export const Overview = ({})=> {

  const [ loaded, setLoaded ] = React.useState(false)
  const [ orgSelected, setOrgSelected ] = React.useState({key: "all", value: "all", text: "Tout"})
  const [ organizations, setOrganizations ] = React.useState<any>([])
  const [ apps, setApps ] = React.useState<any>([])

  React.useEffect(()=> {

    const loadOverviews = async()=> {
      /*try {
        var res = await client.from('organizations').select()
        if(res.error) {
          alert(res.error.message)
          return
        }

        const tempOrgs: any[] = res.data.map((org)=> {
          return {
            key: org.id,
            value: org.id,
            text: org.name
          }
        })

        res = await client.from('get_apps').select()
        if(res.error) {
          alert(res.error.message)
          return
        }
        
        const tempApps: any[] = res.data
        setOrganizations(()=> [{key: "all", value: "all", text: "Tout"}, ...tempOrgs])
        setApps(()=> [...tempApps])
        setLoaded(true)
      }catch(e) {
        alert(e.message)
      }*/
    }

    if(!loaded) {
      loadOverviews()
    }
  }, [])

  const filteredApps = React.useMemo(()=> {
    if(orgSelected.key.startsWith("all")) {
      return apps
    }

    return apps.filter((app: any)=> app.orgid.startsWith(orgSelected.key))
  }, [orgSelected, apps])


  const onSearch = (evt)=> {
    const q = evt.target.value
    if(q.length >= 3) {
      router.get("/account/overview", { q }, {preserveState: true})
    }
  }

  const onSelect = (evt)=> {
    setOrgSelected(organizations.find((el: any)=> el.key.startsWith(evt.target.value)))
  }

  return (
    <div className="w-full xl:px-10 2xl:ppx-20">

      <ul className="w-full flex flex-row justify-start items-center gap-x-2">

        {organizations.length > 0 && <li className="group/nav-item relative text-black dark:text-white">
          <Link href='/account/projects/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
            New project
          </Link>
        </li>}

        <li className="text-black dark:text-white py-3">
          <Link href='/account/organization/create' type='button' className="text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
            New organization
          </Link>
        </li>

        <li className="text-black dark:text-white py-3 relative">
          <input type="email" onChange={onSearch} className="w-72 pl-8 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700" placeholder="Search for a project" required />
          <span className="absolute left-2 top-1/3">
            <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
              <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"/>
            </svg>
          </span>
        </li>


        <li className="text-black dark:text-white py-3 relative">
          <select
            onChange={onSelect}
            className="min-w-72  bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full px-2 py-[1.6%] dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          >
            {organizations.map(
              (option: any, index: any) => (
                <option
                  key={index.toString()}
                  value={option.value}
                >
                  {option.text}
                </option>
              )
            )}
          </select>
        </li>

      </ul>

      <section className="w-full flex flex-row gap-6 py-10">
        {filteredApps.map((app, index)=> (
          <Project key={index.toString()} content={app} />
        ))}
      </section>
    </div>)
}


Overview.layout = page=> <Layout children={page} title="Welcome" />
export default Overview
