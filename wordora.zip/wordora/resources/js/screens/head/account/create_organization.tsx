/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/head'
import Form from '../../../components/widgets/form'
import Toolbar from '../../../components/widgets/toolbar'

const FormData = {
  "layout": "row",
  "sections": [
      {
          "layout": "column",
          "fields": [
              {
                  "type": "input",
                  "name": "name",
                  "label": "Pseudonyme",
                  "placeholder": "john.doe",
                  "validation": {
                      "required": true,
                      "minLength": 3,
                      "maxLength": 15
                  }
              },
              {
                  "type": "input",
                  "name": "email",
                  "label": "Email",
                  "placeholder": "johndoe@gmail.com",
                  "validation": {
                      "required": true,
                      "email": true
                  }
              },

              {
                  "type": "input",
                  "secureText": true,
                  "name": "password",
                  "label": "Mot de passe",
                  "placeholder": "***************",
                  "validation": {
                      "regex": "^\\+?[0-9]{10,15}$"
                  }
              },

              {
                  "type": "input",
                  "name": "password_confirm",
                  "label": "Confirme mot de passe",
                  "secureText": true,
                  "placeholder": "**************",
                  "validation": {
                      "regex": "^\\+?[0-9]{10,15}$"
                  }
              },

          ]
      }
  ]
}

export const CreateOrganization = ({ })=> {
  return (
    <div className="w-full flex flex-col justify-center items-center">
        <PanelForm />
    </div>)
}


const PanelForm = ()=> {

    const formRef = React.useRef<any>()
    const onClick = async() => {      
      /*try {
        const { data: { current } } = formRef.current.onSubmit()
        console.log(current)
        const res = await client.from('organizations').insert({...current, user_id: session?.user.id })
        if(res.error) {
          alert(res.error.message)
          return
        }
        router.get("/account/overview")
      }catch(e) {
        alert(e.message)
      }*/
    }

    return (
    <div className="w-[25%] mt-8 flex flex-col border-2 bg-white border-slate-200 rounded">

        <div className="px-6 py-4 flex flex-row justify-between items-center border-b-2 border-slate-100 dark:border-b-slate-700">
            <div className={`flex flex-row justify-start items-center w-[90%] gap-2`}>
                <h4 className="text-black dark:text-white font-semibold">
                    Create a new organization
                </h4>
            </div>
        </div>

        <div className="w-full px-8 py-4">
            <h2 className="text-gray-800 xl:text-sm">This is your organization within Transax.</h2>
            <h3 className="text-gray-500 xl:text-sm">For example, you can use the name of your company or department.</h3>
        </div>

        <div className="w-full px-6">
            <Form
                config={FormData}
            />
        </div>

        <br/>

        <div className="w-full py-[3%] px-[5%] flex flex-row gap-x-4 justify-between items-center border-t-2 border-slate-100 dark:border-slate-900">
            <Link href="/account/overview" className='flex flex-row justify-center items-center gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-8 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700'>
                Cancel
            </Link>

            <button onClick={onClick} className="text-center focus:outline-none text-white xl:text-md bg-green-700 hover:bg-green-900 focus:ring-6 focus:ring-green-300 rounded-lg text-sm px-8 py-1.5 dark:bg-green-700 dark:hover:bg-green-800 dark:focus:ring-green-900">
                Validate
            </button>

        </div>

      </div>
    )
}

CreateOrganization.layout = page=> <Layout children={page} title="Organization" />
export default CreateOrganization
