/* eslint-disable prettier/prettier */
import React from "react"
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/account'
import Form from '../../../components/widgets/form'

const FormData = {
  "layout": "row",
  "sections": [
      {
          "layout": "column",
          "fields": [
              {
                  "type": "input",
                  "name": "name",
                  "label": "Pseudonyme",
                  "placeholder": "john.doe",
                  "validation": {
                      "required": true,
                      "minLength": 3,
                      "maxLength": 15
                  }
              },
              {
                  "type": "input",
                  "name": "email",
                  "label": "Email",
                  "placeholder": "johndoe@gmail.com",
                  "validation": {
                      "required": true,
                      "email": true
                  }
              },

              {
                  "type": "input",
                  "secureText": true,
                  "name": "password",
                  "label": "Mot de passe",
                  "placeholder": "***************",
                  "validation": {
                      "regex": "^\\+?[0-9]{10,15}$"
                  }
              },

              {
                  "type": "input",
                  "name": "password_confirm",
                  "label": "Confirme mot de passe",
                  "secureText": true,
                  "placeholder": "**************",
                  "validation": {
                      "regex": "^\\+?[0-9]{10,15}$"
                  }
              },

          ]
      }
  ]
}

export const Organization = ({ slug, name, tabTitle = "General", tabs, logs })=> {

  const [organization , setOrganization] = React.useState<any>(null)
  React.useEffect(()=> {

  }, [])
  
  
  return (
    <div className="w-full py-[1.13%]">

      <div className='w-full flex flex-row px-[10%]'>
        
        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              {name} settings
            </h1>
          </li>
        </ul>

      </div>

      <div className="px-[10%] w-full text-sm font-medium text-center text-gray-500 border-b-2 border-gray-200 dark:text-gray-400 dark:border-slate-800">
          <ul className="flex flex-wrap -mb-px">

              {
                tabs.map((tab: any, index: number)=> (
                  <>
                    {tab.title === tabTitle &&             
                      <li className="me-2" key={index.toString()}>
                        <Link href={`/account/organization/${slug}?tab=${tab.title}&org=${name}`} className="inline-block p-4 text-blue-600 border-b-2 border-blue-600 rounded-t-lg active dark:text-blue-500 dark:border-blue-500" aria-current="page">{tab.title}</Link>
                      </li>
                    }

                    {
                      tab.title !== tabTitle && 
                        <li className="me-2" key={index.toString()}>
                          <Link href={`/account/organization/${slug}?tab=${tab.title}&org=${name}`} className="inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300">{tab.title}</Link>
                        </li>
                    }
                  </>
                ))
              }
          </ul>
      </div>

      <div className="w-full px-[10%] py-10">
       {tabTitle === "General" && <TabGeneral/>}
       {tabTitle === "Team" && <TabTeams teams={[1, 2, 3, 4, 5]} />}
       {tabTitle === "Invoices" && <TabInvoice invoices={[1, 2, 3, 4, 5]} />}
       {tabTitle === "Audit Logs" && <TabAuditLogs logs={[1, 2, 3, 4, 5]} />}
      </div>

    </div>)
}




const TabAuditLogs = React.memo(({ logs = [] })=> {

  const formRef = React.useRef<any>()
  const onClick = async() => {      
    /*try {
      const { data: { current } } = formRef.current.onSubmit()
      console.log(current)
      const res = await client.from('applications').insert(current)
      if(res.error) {
        alert(res.error.message)
        return
      }

      router.get("/account/overview")
    }catch(e) {
      alert(e.message)
    }*/
  }

  return( 
  <>
    <div className='w-full px-0 py-10 space-y-10'>
      
      <div className='w-full flex flex-row'>
      
        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              Account audit logs
            </h1>
          </li>


          <li className="relative text-black dark:text-white">
            <p className="text-xl text-slate-600 xl:text-sm">
              View the audit log trail of actions made from your account
            </p>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="group/nav-item relative text-black dark:text-white">
            <Link href='/account/projects/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
              Invite
            </Link>
          </li>


          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              Leave team

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>
              </svg>

            </Link>
          </li>

        </ul>

      </div>

      <div className='w-full flex flex-row'>
      
        <ul className="flex-1 flex flex-row justify-start items-center gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              Filter by
            </h1>
          </li>

          <li className="relative text-black dark:text-white">
            <select
              className="min-w-auto border-dashed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-2 py-[1.6%] dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            >
              <option>Choose category</option>
            </select>
          </li>

          <li className="relative text-black dark:text-white">
            <input type="date"
              className="min-w-auto border-dashed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-2 py-[1.6%] dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            />
          </li>

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              |
            </h1>
          </li>

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              Viewing 7 logs in total
            </h1>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              Refresh
              <svg className="w-4 h-4 text-gray-700 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.651 7.65a7.131 7.131 0 0 0-12.68 3.15M18.001 4v4h-4m-7.652 8.35a7.13 7.13 0 0 0 12.68-3.15M6 20v-4h4"/>
              </svg>
            </Link>
          </li>

        </ul>

      </div>

      <div className='w-full'>

        <div className="w-full relative overflow-x-auto border-[1px] border-slate-200 rounded-md">
          <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
              <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                  <tr>
                      <th scope="col" className="px-6 py-3">
                          User
                      </th>
                      <th scope="col" className="px-6 py-3">
                          Enable MFA
                      </th>
                      <th scope="col" className="px-6 py-3">
                          Role
                      </th>

                  </tr>
              </thead>
              <tbody>
                {logs.map((_: any, index: any)=> (
                  <tr key={index.toString()} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <th scope="row" className="px-6 py-4 font-medium text-slate-400 whitespace-nowrap dark:text-white">
                      Jules1994
                    </th>
                    <td className="px-6 py-4 text-slate-400">
                      <a href="#">
                        <svg className="w-6 h-6 text-slate-400 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                          <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18 17.94 6M18 18 6.06 6"/>
                        </svg>
                      </a>
                    </td>
                    <td className="px-6 py-4 text-slate-400">
                      Own
                    </td>
                  </tr>
                ))}
              </tbody>
          </table>
        </div>

      </div>

    </div>
  </>)
})

const TabInvoice = React.memo(({ invoices = [] })=> {

  const formRef = React.useRef<any>()
  const onClick = async() => {      
    /*try {
      const { data: { current } } = formRef.current.onSubmit()
      console.log(current)
      const res = await client.from('applications').insert(current)
      if(res.error) {
        alert(res.error.message)
        return
      }

      router.get("/account/overview")
    }catch(e) {
      alert(e.message)
    }*/
  }

  return( 
  <>
    <div className='w-full px-0 py-10 space-y-10'>
      
      <div className='w-full flex flex-row'>
      
        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              Account audit logs
            </h1>
          </li>


          <li className="relative text-black dark:text-white">
            <p className="text-xl text-slate-600 xl:text-sm">
              View the audit log trail of actions made from your account
            </p>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="group/nav-item relative text-black dark:text-white">
            <Link href='/account/projects/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
              Invite
            </Link>
          </li>


          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              Leave team

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>
              </svg>

            </Link>
          </li>

        </ul>

      </div>

      <div className='w-full'>

        <div className="w-full relative overflow-x-auto border-[1px] border-slate-200 rounded-md">
          <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
              <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                  <tr>

                      <th scope="col" className="px-6 py-3">
                      </th>

                      <th scope="col" className="px-6 py-3">
                        Date
                      </th>
                      <th scope="col" className="px-6 py-3">
                        Amount
                      </th>
                      <th scope="col" className="px-6 py-3">
                        Invoice number
                      </th>

                      <th scope="col" className="px-6 py-3">
                        Status
                      </th>

                      <th scope="col" className="px-6 py-3">
                      </th>

                  </tr>
              </thead>
              <tbody>
                {invoices.map((_: any, index: any)=> (
                  <tr key={index.toString()} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">

                    <td scope="row" className="px-6 py-4 font-medium text-slate-400 whitespace-nowrap dark:text-white">
                      
                      <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M10 3v4a1 1 0 0 1-1 1H5m14-4v16a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7.914a1 1 0 0 1 .293-.707l3.914-3.914A1 1 0 0 1 9.914 3H18a1 1 0 0 1 1 1Z"/>
                      </svg>

                    </td>

                    <td scope="row" className="px-6 py-4 font-medium text-slate-400 whitespace-nowrap dark:text-white">
                      Jul 06, 2024
                    </td>
                    <td className="px-6 py-4 text-slate-400 text-lg">
                      $0
                    </td>
                    <td className="px-6 py-4 text-slate-400">
                      4AE2F378-0037
                    </td>
                    <td className="px-6 py-4 text-slate-400">
                      <Link href="#" className="py-2 px-4 rounded-full text-green-800 text-xs border-2 border-green-600 bg-green-200">
                        Paid
                      </Link>
                    </td>

                    <td className="px-6 py-4 text-slate-400 text-right">
                      <svg className="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 13V4M7 14H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2m-1-5-4 5-4-5m9 8h.01"/>
                      </svg>
                    </td>

                  </tr>
                ))}
              </tbody>
          </table>
        </div>

      </div>

    </div>
  </>)
})

const TabTeams = React.memo(({ teams = [] })=> {

  const formRef = React.useRef<any>()
  const onClick = async() => {      
    /*try {
      const { data: { current } } = formRef.current.onSubmit()
      console.log(current)
      const res = await client.from('applications').insert(current)
      if(res.error) {
        alert(res.error.message)
        return
      }

      router.get("/account/overview")
    }catch(e) {
      alert(e.message)
    }*/
  }

  return( 
  <>
    <div className='w-full px-0 py-10 space-y-10'>
      
      <div className='w-full flex flex-row'>
      
        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              Account audit logs
            </h1>
          </li>


          <li className="relative text-black dark:text-white">
            <p className="text-xl text-slate-600 xl:text-sm">
              View the audit log trail of actions made from your account
            </p>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="group/nav-item relative text-black dark:text-white">
            <Link href='/account/projects/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
              Invite
            </Link>
          </li>


          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              Leave team

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>
              </svg>

            </Link>
          </li>

        </ul>

      </div>

      {/*<div className='w-full flex flex-row'>
      
        <ul className="flex-1 flex flex-row justify-start items-center gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              Filter by
            </h1>
          </li>

          <li className="relative text-black dark:text-white">
            <select
              className="min-w-auto border-dashed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-2 py-[1.6%] dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            >
              <option>Choose category</option>
            </select>
          </li>

          <li className="relative text-black dark:text-white">
            <input type="date"
              className="min-w-auto border-dashed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-2 py-[1.6%] dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            />
          </li>

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              |
            </h1>
          </li>

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              Viewing 7 logs in total
            </h1>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              Refresh
              <svg className="w-4 h-4 text-gray-700 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.651 7.65a7.131 7.131 0 0 0-12.68 3.15M18.001 4v4h-4m-7.652 8.35a7.13 7.13 0 0 0 12.68-3.15M6 20v-4h4"/>
              </svg>
            </Link>
          </li>

        </ul>

      </div>*/}

      <div className='w-full'>

        <div className="w-full relative overflow-x-auto border-[1px] border-slate-200 rounded-md">
          <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
              <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                  <tr>
                      <th scope="col" className="px-6 py-3">
                          User
                      </th>
                      <th scope="col" className="px-6 py-3">
                          Enable MFA
                      </th>
                      <th scope="col" className="px-6 py-3">
                          Role
                      </th>

                  </tr>
              </thead>
              <tbody>
                {teams.map((_: any, index: any)=> (
                  <tr key={index.toString()} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <th scope="row" className="px-6 py-4 font-medium text-slate-400 whitespace-nowrap dark:text-white">
                      Jules1994
                    </th>
                    <td className="px-6 py-4 text-slate-400">
                      <a href="#">
                        <svg className="w-6 h-6 text-slate-400 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                          <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18 17.94 6M18 18 6.06 6"/>
                        </svg>
                      </a>
                    </td>
                    <td className="px-6 py-4 text-slate-400">
                      Own
                    </td>
                  </tr>
                ))}
              </tbody>
          </table>
        </div>

      </div>

    </div>
  </>)
})

const TabGeneral = React.memo(({ })=> {

  const formRef = React.useRef<any>()
  const onClick = async() => {      
    /*try {
      const { data: { current } } = formRef.current.onSubmit()
      console.log(current)
      const res = await client.from('applications').insert(current)
      if(res.error) {
        alert(res.error.message)
        return
      }

      router.get("/account/overview")
    }catch(e) {
      alert(e.message)
    }*/
  }

  return( 
  <>
    <div className="w-full p-10 flex flex-row justify-start items-start white dark:bg-slate-900 border-2 border-slate-200 rounded-md">

      <div className="flex-1">
        <h1 className="font-medium">General setting</h1>
      </div>

      <div className="flex-1 flex flex-col border-0 bg-white border-slate-200 rounded">

        <div className="w-full px-8 py-4">
          <h2 className="text-gray-800 xl:text-sm">This is your project within Transax.</h2>
          <h3 className="text-gray-500 xl:text-sm">For example, you can use the name of your company or department.</h3>
        </div>
 
        <div className="w-full px-6">
            <Form
                config={FormData}
            />
        </div>

        <br/>

        <div className="w-full py-[3%] px-[5%] flex flex-row gap-x-4 justify-between items-center border-t-0 border-slate-100 dark:border-slate-900">
            <Link href="/account/overview" className='flex flex-row justify-center items-center gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-8 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700'>
                Cancel
            </Link>

            <button onClick={onClick} className="text-center focus:outline-none text-white xl:text-md bg-green-700 hover:bg-green-900 focus:ring-6 focus:ring-green-300 rounded-lg text-sm px-8 py-1.5 dark:bg-green-700 dark:hover:bg-green-800 dark:focus:ring-green-900">
                Validate
            </button>

        </div>

      </div>

    </div>
  </>)
})

Organization.layout = page=> <Layout children={page} title="Welcome" />
export default Organization
