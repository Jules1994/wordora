/* eslint-disable prettier/prettier */
import React from 'react'
import { Link } from '@inertiajs/react'
import Layout from '../../../layouts/account'

const Tabs = [
  {title: "General" }, {title: "Team" }, {title: "Integration" }, {title: "Billing"}, {title: "Usage"}, {title: "Invoices"}, {title: "OAuth Apps"}, {title: "Audit Logs"}, {title: "Legal Documents"}]

export const ProjectApp = ({ slug, tabTitle = "General" })=> {

  console.log(tabTitle)
  return (
    <div className="w-full py-[1.13%]">

      <div className='w-full flex flex-row px-[10%]'>
        
        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              {slug} settings
            </h1>
          </li>
        </ul>


        {/*<ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              API Doc

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>
              </svg>

            </Link>
          </li>

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              CLI Doc

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>
              </svg>

            </Link>
          </li>

          <li className="group/nav-item relative text-black dark:text-white">
            <Link href='/account/projects/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
              Generate new token
            </Link>
          </li>

        </ul>*/}

      </div>

      <div className="px-[10%] w-full text-sm font-medium text-center text-gray-500 border-b-2 border-gray-200 dark:text-gray-400 dark:border-slate-800">
          <ul className="flex flex-wrap -mb-px">

              {
                Tabs.map((tab, index)=> (
                  <>
                    {tab.title === tabTitle &&             
                      <li className="me-2" key={index.toString()}>
                        <Link href={`/account/projects/${slug}?tab=${tab.title}`} className="inline-block p-4 text-blue-600 border-b-2 border-blue-600 rounded-t-lg active dark:text-blue-500 dark:border-blue-500" aria-current="page">{tab.title}</Link>
                      </li>
                    }

                    {
                      tab.title !== tabTitle && 
                        <li className="me-2" key={index.toString()}>
                          <Link href={`/account/projects/${slug}?tab=${tab.title}`} className="inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300">{tab.title}</Link>
                        </li>
                    }
                  </>
                ))
              }
          </ul>
      </div>

    </div>)
}


ProjectApp.layout = page=> <Layout children={page} title="Welcome" />
export default ProjectApp
