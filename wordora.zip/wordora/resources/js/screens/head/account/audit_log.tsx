/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/account'

export const AuditLog = ({ logs = [], organizations = [] })=> {

  const onSearch = (evt)=> {
    const q = evt.target.value
    if(q.length >= 3) {
      router.get("/account/access_token", { q }, {preserveState: true})
    }
  }

  return (
    <div className='w-full px-24 py-10 space-y-10'>
      
      <div className='w-full flex flex-row'>
      
        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              Account audit logs
            </h1>
          </li>


          <li className="relative text-black dark:text-white">
            <p className="text-xl text-slate-600 xl:text-sm">
              View the audit log trail of actions made from your account
            </p>
          </li>

        </ul>


        {/*<ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              API Doc

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>
              </svg>

            </Link>
          </li>

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              CLI Doc

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>
              </svg>

            </Link>
          </li>

          <li className="group/nav-item relative text-black dark:text-white">
            <Link href='/account/projects/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
              Generate new token
            </Link>
          </li>

        </ul>*/}

      </div>

      <div className='w-full flex flex-row'>
      
        <ul className="flex-1 flex flex-row justify-start items-center gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              Filter by
            </h1>
          </li>

          <li className="relative text-black dark:text-white">
            <select
              className="min-w-auto border-dashed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-2 py-[1.6%] dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            >
              {organizations.map(
                (option: any, index: any) => (
                  <option
                    key={index.toString()}
                    value={option.slug}
                  >
                    {option.name}
                  </option>
                )
              )}
            </select>
          </li>

          <li className="relative text-black dark:text-white">
            <input type="date"
              className="min-w-auto border-dashed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-2 py-[1.6%] dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            />
          </li>

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              |
            </h1>
          </li>

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              Viewing 7 logs in total
            </h1>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              Refresh
              <svg className="w-4 h-4 text-gray-700 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.651 7.65a7.131 7.131 0 0 0-12.68 3.15M18.001 4v4h-4m-7.652 8.35a7.13 7.13 0 0 0 12.68-3.15M6 20v-4h4"/>
              </svg>
            </Link>
          </li>

        </ul>

      </div>

      <div className='w-full'>

        <div className="w-full relative overflow-x-auto border-[1px] border-slate-200 rounded-md">
          <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
              <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                  <tr>
                      <th scope="col" className="px-6 py-3">
                          Action
                      </th>
                      <th scope="col" className="px-6 py-3">
                          Target
                      </th>
                      <th scope="col" className="px-6 py-3">
                          Date
                      </th>

                      <th scope="col" className="px-6 py-3">
                          
                      </th>

                  </tr>
              </thead>
              <tbody>
                {logs.map((log: any, index: any)=> (
                  <tr key={index.toString()} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <th scope="row" className="px-6 py-4 font-medium  text-slate-400 whitespace-nowrap dark:text-white">
                      {log.action}
                    </th>
                    <td className="px-6 py-4 text-slate-400">
                      {log.target}
                    </td>
                    <td className="px-6 py-4 text-slate-400">
                      01/03/2024 18:32:28
                    </td>

                    <td className="px-6 py-4 text-slate-400 text-right">
                      <button type='button' className="w-auto flex flex-row flex-start items-start gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                        View details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
          </table>
        </div>

      </div>

    </div>)
}


AuditLog.layout = page=> <Layout children={page} title="AuditLog" />
export default AuditLog
