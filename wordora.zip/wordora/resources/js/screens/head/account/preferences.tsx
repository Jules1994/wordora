/* eslint-disable prettier/prettier */
import React from 'react'
//import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/account'
import Form from '../../../components/widgets/form'

const FormData = {
  "layout": "row",
  "sections": [
      {
          "layout": "column",
          "fields": [
              {
                  "type": "input",
                  "name": "name",
                  "label": "Pseudonyme",
                  "placeholder": "john.doe",
                  "validation": {
                      "required": true,
                      "minLength": 3,
                      "maxLength": 15
                  }
              },
              {
                  "type": "input",
                  "name": "email",
                  "label": "Email",
                  "placeholder": "johndoe@gmail.com",
                  "validation": {
                      "required": true,
                      "email": true
                  }
              },

              {
                  "type": "input",
                  "secureText": true,
                  "name": "password",
                  "label": "Mot de passe",
                  "placeholder": "***************",
                  "validation": {
                      "regex": "^\\+?[0-9]{10,15}$"
                  }
              },

              {
                  "type": "input",
                  "name": "password_confirm",
                  "label": "Confirme mot de passe",
                  "secureText": true,
                  "placeholder": "**************",
                  "validation": {
                      "regex": "^\\+?[0-9]{10,15}$"
                  }
              },

          ]
      }
  ]
}

export const Preferences = ({ })=> {

  const refs = React.useRef<any>([])

  return (
    <div className='w-full px-24 py-10 space-y-10'>

      <div className='w-full flex flex-col items-center'>

          <Form 
            config={FormData}
          />

      </div>

    </div>)
}



Preferences.layout = page=> <Layout children={page} title="Preferences" />
export default Preferences
