/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/account'

export const Security = ({ })=> {

  const onSearch = (evt)=> {
    const q = evt.target.value
    if(q.length >= 3) {
      router.get("/account/access_token", { q }, {preserveState: true})
    }
  }

  return (
    <div className='w-full px-24 py-10 space-y-10'>
      
      <div className='w-full flex flex-row'>
      
        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              Multi-factor authentication
            </h1>
          </li>


          <li className="relative text-black dark:text-white">
            <p className="text-xl text-slate-600 xl:text-sm">
              Add an additional layer of security to your account by requiring more than just a password to sign in.
            </p>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              API Doc

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>
              </svg>

            </Link>
          </li>

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              CLI Doc

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>
              </svg>

            </Link>
          </li>

          <li className="group/nav-item relative text-black dark:text-white">
            <Link href='/account/projects/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
              Generate new token
            </Link>
          </li>

        </ul>

      </div>


      <div className='w-full'>
        <div id="accordion-collapse" data-accordion="collapse">
          <h2 id="accordion-collapse-heading-1">
            <button type="button" className="flex items-center justify-between w-full p-2 font-medium rtl:text-right text-gray-500 border border-b-0 bg-gray-100 rounded-t-xl focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 gap-3" data-accordion-target="#accordion-collapse-body-1" aria-expanded="true" aria-controls="accordion-collapse-body-1">
              <span>Athenticator app</span>
              <svg data-accordion-icon className="w-3 h-3 rotate-180 shrink-0" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5 5 1 1 5"/>
              </svg>
            </button>
          </h2>
          <div id="accordion-collapse-body-1" className="block" aria-labelledby="accordion-collapse-heading-1">
            <div className="p-5 space-y-4 border rounded-es-md rounded-b-md border-gray-200 dark:border-gray-700 dark:bg-gray-900">
              <p className="mb-2 text-slate-600 xl:text-sm dark:text-gray-400">Generate one-time passwords via authenticator apps like 1Password, Authy, etc. as a second factor to verify your identity during sign-in.</p>
              <button className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                Add new app
              </button>
            </div>
          </div>
        </div>
      </div>

    </div>)
}


Security.layout = page=> <Layout children={page} title="Security" />
export default Security
