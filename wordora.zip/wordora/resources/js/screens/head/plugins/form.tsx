/* eslint-disable prettier/prettier */
import React from 'react'
import { router } from '@inertiajs/react'
import Layout from '../../../layouts/head'
import { PanelForm } from '../../../components/widgets/panelform'
import axios from 'axios'
import { useStorage } from '../../../libs/api-react'

const FormDataFields = {
    "layout": "row",
    "sections": [
        {
            "layout": "column",
            "fields": [
                {
                    "name": "plugin_file",
                    "type": "documentPicker"
                }
            ]
        }
    ]
}

export const UserForm = ({ user }: any) => {

    const storage = useStorage()
    const ref = React.useRef<any>(null)

    const handleSubmit = async () => {
        if (ref) {

            try {
                const { value } = ref.current?.submit()
                console.log(value)

                /*const formData = new FormData();
                formData.append('plugin_file', value.plugin_file);

                const res = await axios.post("/plugins/upload", formData, {
                    headers: { 'Content-Type': 'multipart/form-data' },
                    onUploadProgress: (e) => {
                        console.log(e.progress)
                    }
                });

                if (res.status === 200) {
                    alert(res.data.message)
                }*/

                router.post("/plugins/upload", value, {
                    forceFormData: true,
                })

            } catch (e) {
                alert(e.message)
            }
        }
    }

    return (
        <div className="w-full flex flex-col justify-center items-center">
            <PanelForm
                ref={ref}
                content={{
                    title: `${user ? 'Edit' : 'Create'} user`
                }}
                onSubmit={handleSubmit}
                defaultData={user}
                config={FormDataFields}
            />
        </div>)
}

UserForm.layout = page => <Layout children={page} title="Organization" />
export default UserForm
