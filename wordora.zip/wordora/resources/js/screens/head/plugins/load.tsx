/* eslint-disable prettier/prettier */
import React from 'react';
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { Link } from '@inertiajs/react'
import Layout from '../../../layouts/account'


const PluginLoad = ({ plugin }) => {

    
    const PluginComponent: React.FC<any> = React.lazy(() => {
        if (plugin.cdn_url) {
            return import( /* @vite-ignore */ plugin.cdn_url)
                .catch(() => {
                    console.error("Plugin distant introuvable.");
                    return {
                        default: () =>
                        (<div className='w-full h-screen/2 flex flex-col justify-center items-center'>
                            <img src='https://static.vecteezy.com/system/resources/thumbnails/023/033/009/small_2x/rocket-spaceship-fail-landing-at-space-planet-for-something-went-wrong-error-message-empty-state-illustration-vector.jpg' className='mt-[5%] w-auto h-auto' />
                        </div>)
                    };
                });
        }

        //const local_path = `http://localhost:8000/plugin-headless-sample/plugin-headless-sample/with_react_healdess-plugin.es.js`;
        //const local_path = `http://localhost:8000/plugin-headless-sample/plugin-headless-sample/_healdess-plugin.es.js`;
        //const local_path = `http://localhost:8000/plugin-headless-sample/plugin-headless-sample/without_react_healdess-plugin.es`
        const local_path = `http://localhost:8000/plugin-headless-sample/plugin-headless-sample/healdess-plugin.es.js`;
        return import(/* @vite-ignore */ local_path)
            .catch(() => {
                console.error("Plugin local introuvable.");
                return {
                    default: () =>
                    (<div className='w-full h-screen/2 flex flex-col justify-center items-center capitalize'>
                        <img src='https://t4.ftcdn.net/jpg/05/24/04/51/360_F_524045110_UXnCx4GEDapddDi5tdlY96s4g0MxHRvt.jpg' className='mt-[5%] w-auto h-auto' />
                    </div>)
                };
            });


    });

    return (
        <div className="w-full xl:px-10">

            <div className='sticky top-0 w-full flex flex-row'>

                <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

                    <li className="text-black dark:text-white py-3">
                        <Link href='#' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                            CLI Doc

                            <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778" />
                            </svg>

                        </Link>
                    </li>

                    <li className="group/nav-item relative text-black dark:text-white">
                        <Link href='#' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                            Plugin connected
                        </Link>
                    </li>

                </ul>

            </div>

            <section className="w-full flex flex-column gap-6 py-10">
                <React.Suspense fallback={<div>Chargement du plugin...</div>}>
                    <PluginComponent {...plugin.values} />
                </React.Suspense>
            </section>

        </div>)
}


PluginLoad.layout = page => <Layout children={page} title="Plugin List" />
export default PluginLoad
