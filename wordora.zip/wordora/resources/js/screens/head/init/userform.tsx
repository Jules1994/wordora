import React from "react"
import { Head, Link, router } from '@inertiajs/react'
import Form from "../../../components/widgets/form"

const FormData = {
    "layout": "row",
    "sections": [
        {
            "layout": "column",
            "fields": [
                {
                    "type": "input",
                    "name": "name",
                    "label": "Pseudonyme",
                    "placeholder": "john.doe",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 15
                    }
                },
                {
                    "type": "input",
                    "name": "email",
                    "label": "Email",
                    "placeholder": "johndoe@gmail.com",
                    "validation": {
                        "required": true,
                        "email": true
                    }
                },

                {
                    "type": "input",
                    "secureText": true,
                    "name": "password",
                    "label": "Mot de passe",
                    "placeholder": "***************",
                    "validation": {
                        "required": true
                    }
                },

                {
                    "type": "input",
                    "name": "password_confirm",
                    "label": "Confirme mot de passe",
                    "secureText": true,
                    "placeholder": "**************",
                    "validation": {
                        "required": true
                    }
                },

            ]
        },
    ]
}

export default ({ user }) => {

    const ref = React.useRef<any>(null);

    const handleSubmit = ()=> {
        if(ref) {
            const { value, errors } = ref.current?.submit()
            if(ref.current?.hasErrors()) {
                alert(JSON.stringify(errors))
            }else {
                //alert(JSON.stringify(ref.current.data()))
                if(value.password !== value.password_confirm) {
                    alert("Passwords don't match")
                    return 
                }
                router.post("/admin/init/create-default-user-validate", value)
            }
        }
    }

    return (
        <div className='w-full h-auto min-h-screen bg-[#f1f1f1] dark:bg-slate-900'>
            <Head title="Login" />

            <main className='w-screen h-screen flex flex-row justify-center items-start'>
                <section className='xl:w-[35%] xl:px-[7%] h-full relative flex flex-col justify-start items-start gap-y-10 bg-white dark:bg-slate-800 border-x-2 border-slate-200 dark:border-slate-800 pt-6'>  

                    <div className='w-full px-10'>
                        <h1 className='text-2xl dark:text-white'>Login credentials</h1>
                        <p className='text-slate-600'>This user will be admin, don't forget credential.</p>
                    </div>

                    <div className='w-full flex flex-col justify-center items-center px-10'>
                        <Form
                            ref={ref}
                            config={FormData}
                            defaultData={user}
                        />
                        <button onClick={handleSubmit} className="w-full text-center focus:outline-none text-white xl:text-md bg-green-700 hover:bg-green-900 focus:ring-6 focus:ring-green-300 rounded-lg text-sm px-0 py-2.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                            Validation de création du compte
                        </button>
                    </div>


                    {/******Separator *********/}

                    <div className='w-full flex flex-row justify-center gap-x-2 xl:text-sm dark:text-white'>
                        Don't have an account? <Link href="#" className='underline text-green-900'>Documentation</Link>
                    </div>


                    <p className='text-center xl:text-xs text-slate-600'>
                        By continuing, you agree to Supabase's Terms of Service and Privacy Policy, and to receive periodic emails with updates.
                    </p>

                </section>
            </main>
        </div>
    )
}