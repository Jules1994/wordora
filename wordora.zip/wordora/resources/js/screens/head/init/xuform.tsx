import React from "react"
import { Head, Link } from '@inertiajs/react'
import Form from "../../../components/widgets/form"

const FormData = {
    "sections": [
        {
            "title": "Section 1",
            "layout": "column",
            "fields": [
                {
                    "type": "input",
                    "name": "username",
                    "label": "Username",
                    "placeholder": "john.doe",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 15
                    }
                },
                {
                    "type": "input",
                    "name": "email",
                    "label": "Email",
                    "maskType": "xxxxxx.xxxxxxx",
                    "placeholder": "johndoe@gmail.com",
                    "validation": {
                        "required": true,
                        "email": true
                    }
                },
                {
                    "type": "input",
                    "name": "phone",
                    "label": "Phone",
                    "placeholder": "+241 77 64 06 25",
                    "validation": {
                        "regex": "^\\+?[0-9]{10,15}$"
                    }
                }
            ]
        }
    ]
}

export default ({ }) => {
    return (
        <div className='w-full min-h-screen bg-white dark:bg-slate-900'>
            <Head title="Login" />

            <main className='w-screen h-screen flex flex-row'>
                <section className='xl:w-[35%] xl:px-[7%] h-full relative flex flex-col justify-center items-start gap-y-10 dark:bg-slate-800 border-r-2 border-slate-200 dark:border-slate-800'>

                    <Link href="/" className="flex-1 flex flex-row justify-center items-center gap-x-4 absolute left-8 top-8">
                        <svg
                            className='w-10 h-10'
                            viewBox="0 0 109 113"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M63.7076 110.284C60.8481 113.885 55.0502 111.912 54.9813 107.314L53.9738 40.0627L99.1935 40.0627C107.384 40.0627 111.952 49.5228 106.859 55.9374L63.7076 110.284Z"
                                fill="url(#paint0_linear)"
                            />
                            <path
                                d="M63.7076 110.284C60.8481 113.885 55.0502 111.912 54.9813 107.314L53.9738 40.0627L99.1935 40.0627C107.384 40.0627 111.952 49.5228 106.859 55.9374L63.7076 110.284Z"
                                fill="url(#paint1_linear)"
                                fillOpacity="0.2"
                            />
                            <path
                                d="M45.317 2.07103C48.1765 -1.53037 53.9745 0.442937 54.0434 5.041L54.4849 72.2922H9.83113C1.64038 72.2922 -2.92775 62.8321 2.1655 56.4175L45.317 2.07103Z"
                                fill="#3ECF8E"
                            />
                            <defs>
                                <linearGradient
                                    id="paint0_linear"
                                    x1="53.9738"
                                    y1="54.974"
                                    x2="94.1635"
                                    y2="71.8295"
                                    gradientUnits="userSpaceOnUse"
                                >
                                    <stop stopColor="#249361" />
                                    <stop offset="1" stopColor="#3ECF8E" />
                                </linearGradient>
                                <linearGradient
                                    id="paint1_linear"
                                    x1="36.1558"
                                    y1="30.578"
                                    x2="54.4844"
                                    y2="65.0806"
                                    gradientUnits="userSpaceOnUse"
                                >
                                    <stop />
                                    <stop offset="1" stopOpacity="0" />
                                </linearGradient>
                            </defs>
                        </svg>
                        <h1 className='font-bold text-xl dark:text-white'>Transax</h1>
                    </Link>

                    <div className='w-full px-10'>
                        <h1 className='text-2xl dark:text-white'>Welcome back</h1>
                        <p className='text-slate-600'>Sign in to your account</p>
                    </div>

                    <div className='w-full flex flex-col justify-center items-center px-10'>

                        <div className="mb-5 w-full">
                            <label htmlFor="email" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Email</label>
                            <input type="email" id="email" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="you@example.com" required />
                        </div>
                        <div className="mb-5 w-full">
                            <label htmlFor="password" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Password</label>
                            <input type="password" id="password" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="****************" required />
                        </div>
                        <button onClick={() => { }} className="w-full text-center focus:outline-none text-white xl:text-md bg-green-700 hover:bg-green-900 focus:ring-6 focus:ring-green-300 rounded-lg text-sm px-0 py-2.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                            Sign in
                        </button>
                    </div>


                    {/******Separator *********/}

                    <div className='w-full flex flex-row justify-center items-center gap-x-4 px-10'>
                        <div className='flex-1 border-t-2 border-slate-200 dark:border-slate-800' />
                        <div className='flex-0 dark:text-white'>or</div>
                        <div className='flex-1 border-t-2 border-slate-200 dark:border-slate-800' />
                    </div>

                    {/***** Socials buttons *****/}
                    <div className='w-full flex flex-col justify-center items-center px-10'>


                        {/*<button onClick={()=> signInWithOAuth('facebook')} className="w-full flex flex-row justify-center items-center text-white bg-[#3b5998] hover:bg-[#3b5998]/90 focus:ring-4 focus:outline-none focus:ring-[#3b5998]/50 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:focus:ring-[#3b5998]/55 me-2 mb-2">
                <svg className="w-4 h-4 me-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 8 19">
                  <path fillRule="evenodd" d="M6.135 3H8V0H6.135a4.147 4.147 0 0 0-4.142 4.142V6H0v3h2v9.938h3V9h2.021l.592-3H5V3.591A.6.6 0 0 1 5.592 3h.543Z" clipRule="evenodd"/>
                </svg>
                Sign in with Facebook
              </button>*/}

                        <button onClick={() => { }} className="w-full  flex flex-row justify-center items-center text-white bg-[#24292F] hover:bg-[#24292F]/90 focus:ring-4 focus:outline-none focus:ring-[#24292F]/50 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:focus:ring-gray-500 dark:hover:bg-[#050708]/30 me-2 mb-2 dark:bg-black">
                            <svg className="w-4 h-4 me-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M10 .333A9.911 9.911 0 0 0 6.866 19.65c.5.092.678-.215.678-.477 0-.237-.01-1.017-.014-1.845-2.757.6-3.338-1.169-3.338-1.169a2.627 2.627 0 0 0-1.1-1.451c-.9-.615.07-.6.07-.6a2.084 2.084 0 0 1 1.518 1.021 2.11 2.11 0 0 0 2.884.823c.044-.503.268-.973.63-1.325-2.2-.25-4.516-1.1-4.516-4.9A3.832 3.832 0 0 1 4.7 7.068a3.56 3.56 0 0 1 .095-2.623s.832-.266 2.726 1.016a9.409 9.409 0 0 1 4.962 0c1.89-1.282 2.717-1.016 2.717-1.016.366.83.402 1.768.1 2.623a3.827 3.827 0 0 1 1.02 2.659c0 3.807-2.319 4.644-4.525 4.889a2.366 2.366 0 0 1 .673 1.834c0 1.326-.012 2.394-.012 2.72 0 .263.18.572.681.475A9.911 9.911 0 0 0 10 .333Z" clipRule="evenodd" />
                            </svg>
                            Sign in with Github
                        </button>

                        <button onClick={() => { }} className="w-full  flex flex-row justify-center items-center text-white bg-red-600 hover:bg-red-600/90 focus:ring-4 focus:outline-none focus:ring-red-600/50 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:focus:ring-red-600/55 me-2 mb-2">
                            <svg className="w-4 h-4 me-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 18 19">
                                <path fillRule="evenodd" d="M8.842 18.083a8.8 8.8 0 0 1-8.65-8.948 8.841 8.841 0 0 1 8.8-8.652h.153a8.464 8.464 0 0 1 5.7 2.257l-2.193 2.038A5.27 5.27 0 0 0 9.09 3.4a5.882 5.882 0 0 0-.2 11.76h.124a5.091 5.091 0 0 0 5.248-4.057L14.3 11H9V8h8.34c.066.543.095 1.09.088 1.636-.086 5.053-3.463 8.449-8.4 8.449l-.186-.002Z" clipRule="evenodd" />
                            </svg>
                            Sign in with Google
                        </button>

                        {/*<button onClick={()=> signInWithOAuth('apple')} className="w-full  flex flex-row justify-center items-center text-white bg-[#050708] hover:bg-[#050708]/90 focus:ring-4 focus:outline-none focus:ring-[#050708]/50 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:focus:ring-[#050708]/50 dark:hover:bg-[#050708]/30 me-2 mb-2">
                <svg className="w-5 h-5 me-2 -ms-1" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="apple" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"></path></svg>
                Sign in with Apple
              </button>*/}

                    </div>

                    <div className='w-full flex flex-row justify-center gap-x-2 xl:text-sm dark:text-white'>
                        Don't have an account? <Link href="#" className='underline text-green-900'>Sign Up Now</Link>
                    </div>


                    <p className='text-center xl:text-xs text-slate-600'>
                        By continuing, you agree to Supabase's Terms of Service and Privacy Policy, and to receive periodic emails with updates.
                    </p>

                </section>



                {/********* Message  ********/}
                <aside className='relative xl:w-[65%] h-full bg-[#f1f1f1] dark:bg-slate-700 flex flex-col justify-center items-center'>

                    <Link href="/docs" className="flex flex-row justify-center items-center absolute top-10 right-10 gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-2 py-1 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                        <span className="text-gray-800 dark:text-white mb-0">
                            <svg className="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fillRule="evenodd" d="M11 4.717c-2.286-.58-4.16-.756-7.045-.71A1.99 1.99 0 0 0 2 6v11c0 1.133.934 2.022 2.044 2.007 2.759-.038 4.5.16 6.956.791V4.717Zm2 15.081c2.456-.631 4.198-.829 6.956-.791A2.013 2.013 0 0 0 22 16.999V6a1.99 1.99 0 0 0-1.955-1.993c-2.885-.046-4.76.13-7.045.71v15.081Z" clipRule="evenodd" />
                            </svg>
                        </span>
                        <label>
                            Documentation
                        </label>
                    </Link>

                    <div className='w-[50%] flex flex-col justify-center relative gap-y-5'>
                        <span className="text-slate-400 dark:text-white absolute left-0 -top-16">
                            <svg className='w-24 h-24' aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fillRule="evenodd" d="M6 6a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a3 3 0 0 1-3 3H5a1 1 0 1 0 0 2h1a5 5 0 0 0 5-5V8a2 2 0 0 0-2-2H6Zm9 0a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a3 3 0 0 1-3 3h-1a1 1 0 1 0 0 2h1a5 5 0 0 0 5-5V8a2 2 0 0 0-2-2h-3Z" clipRule="evenodd" />
                            </svg>
                        </span>
                        <p className='w-auto dark:text-white font-semibold xl:text-4xl xl:px-[5%]'>
                            I just learned about @supabase and im in love 😍 Supabase is an open source Firebase alternative! EarListen (& react) to database changes 💁 Manage users & permissions 🔧 Simple UI for database interaction
                        </p>

                        <div className="flex items-center gap-4 ml-10">
                            <img className="w-10 h-10 rounded-full" src="https://supabase.com/images/twitter-profiles/OCDKFUOp_400x400.jpg" alt="" />
                            <div className="font-bold dark:text-white">
                                <div>J@PaoloRicciuti</div>
                            </div>
                        </div>

                    </div>
                </aside>

            </main>
        </div>
    )
}