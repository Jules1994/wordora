import React from "react"
import { Head, Link } from '@inertiajs/react'

export default ({ }) => {
    return (
        <div className='w-full h-auto min-h-screen bg-[#f1f1f1] dark:bg-slate-900'>
            <Head title="Login" />

            <main className='w-screen h-screen flex flex-row justify-center items-start'>
                <section className='xl:w-[35%] xl:px-[7%] h-full relative flex flex-col justify-center items-center gap-y-10 bg-white dark:bg-slate-800 border-x-2 border-slate-200 dark:border-slate-800'>

                    <div className='w-full px-10 flex flex-col justify-center items-center'>
                        <svg
                            className='w-32 h-32'
                            viewBox="0 0 109 113"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M63.7076 110.284C60.8481 113.885 55.0502 111.912 54.9813 107.314L53.9738 40.0627L99.1935 40.0627C107.384 40.0627 111.952 49.5228 106.859 55.9374L63.7076 110.284Z"
                                fill="url(#paint0_linear)"
                            />
                            <path
                                d="M63.7076 110.284C60.8481 113.885 55.0502 111.912 54.9813 107.314L53.9738 40.0627L99.1935 40.0627C107.384 40.0627 111.952 49.5228 106.859 55.9374L63.7076 110.284Z"
                                fill="url(#paint1_linear)"
                                fillOpacity="0.2"
                            />
                            <path
                                d="M45.317 2.07103C48.1765 -1.53037 53.9745 0.442937 54.0434 5.041L54.4849 72.2922H9.83113C1.64038 72.2922 -2.92775 62.8321 2.1655 56.4175L45.317 2.07103Z"
                                fill="#3ECF8E"
                            />
                            <defs>
                                <linearGradient
                                    id="paint0_linear"
                                    x1="53.9738"
                                    y1="54.974"
                                    x2="94.1635"
                                    y2="71.8295"
                                    gradientUnits="userSpaceOnUse"
                                >
                                    <stop stopColor="#249361" />
                                    <stop offset="1" stopColor="#3ECF8E" />
                                </linearGradient>
                                <linearGradient
                                    id="paint1_linear"
                                    x1="36.1558"
                                    y1="30.578"
                                    x2="54.4844"
                                    y2="65.0806"
                                    gradientUnits="userSpaceOnUse"
                                >
                                    <stop />
                                    <stop offset="1" stopOpacity="0" />
                                </linearGradient>
                            </defs>
                        </svg>
                        <h1 className='text-2xl dark:text-white'>Welcome back</h1>
                        <p className='text-slate-600'>Sign in to your account</p>
                    </div>

                    <div className='w-full flex flex-col justify-center items-center px-10'>
                        <Link href='/admin/init/install' className="w-full flex flex-row justify-center items-center gap-x-4 text-center focus:outline-none text-white xl:text-md bg-green-700 hover:bg-green-900 focus:ring-6 focus:ring-green-300 rounded-lg text-sm px-0 py-2.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                            <span>Commencer l'installation</span>
                            <svg className="w-6 h-6 text-white dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m10 16 4-4-4-4" />
                            </svg>

                        </Link>
                    </div>


                    {/******Separator *********/}

                    <div className='w-full flex flex-row justify-center gap-x-2 xl:text-sm dark:text-white'>
                        Don't have an account? <Link href="#" className='underline text-green-900'>Documentation</Link>
                    </div>


                    <p className='text-center xl:text-xs text-slate-600'>
                        By continuing, you agree to Supabase's Terms of Service and Privacy Policy, and to receive periodic emails with updates.
                    </p>

                </section>
            </main>
        </div>
    )
}