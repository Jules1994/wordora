import React from "react"
import { Head, Link, router } from '@inertiajs/react'
import Form from "../../../components/widgets/form"

const FormData = {
    "layout": "row",
    "sections": [
        {
            "layout": "column",
            "fields": [

                {
                    "type": "input",
                    "name": "app_name",
                    "label": "Name",
                    "placeholder": "Nom de l'entreprise",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 15
                    }
                },

                {
                    "type": "input",
                    "name": "app_url",
                    "label": "Adresse URL",
                    "placeholder": "myapplication.com",
                    "validation": {
                        "required": true
                    }
                },

            ]
        }
    ]
}

export default ({ appinfo }) => {

    const ref = React.useRef<any>(null)
    const defaultData = appinfo === null ? null: (appinfo.value ? JSON.parse(appinfo.value): {})

    const handleSubmit = ()=> {
        if(ref) {
            const { value, errors } = ref.current?.submit()
            if(ref.current.hasErrors()) {
                alert(JSON.stringify(errors))
            }else {
                //alert(JSON.stringify(ref.current.data()))
                router.post("/admin/init/install-validate", value)
            }
        }
    }

    return (
        <div className='w-full h-auto min-h-screen bg-[#f1f1f1] dark:bg-slate-900'>
            <Head title="Login" />
            <main className='w-screen h-screen flex flex-row justify-center items-start'>
                <section className='xl:w-[35%] xl:px-[7%] h-full relative flex flex-col justify-start items-start gap-y-10 bg-white dark:bg-slate-800 border-x-2 border-slate-200 dark:border-slate-800 pt-6'>

                    <div className='w-full px-10'>
                        <h1 className='text-2xl dark:text-white'>Application Enterprise</h1>
                        <p className='text-slate-600'>Please enter your app's information.</p>
                    </div>

                    <div className='w-full flex flex-col justify-center items-center px-10'>
                        <Form
                            ref={ref}
                            config={FormData}
                            defaultData={defaultData}
                        />
                        <button onClick={handleSubmit} className="w-full flex flex-row justify-center items-center gap-x-4 text-center focus:outline-none text-white xl:text-md bg-green-700 hover:bg-green-900 focus:ring-6 focus:ring-green-300 rounded-lg text-sm px-0 py-2.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                            <span>Continuer la configuration</span>
                            <svg className="w-6 h-6 text-white dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m10 16 4-4-4-4" />
                            </svg>
                        </button>
                    </div>


                    {/******Separator *********/}

                    <div className='w-full flex flex-row justify-center gap-x-2 xl:text-sm dark:text-white'>
                        Don't have an account? <Link href="#" className='underline text-green-900'>Documentation</Link>
                    </div>


                    <p className='text-center xl:text-xs text-slate-600'>
                        By continuing, you agree to Supabase's Terms of Service and Privacy Policy, and to receive periodic emails with updates.
                    </p>

                </section>
            </main>
        </div>
    )
}