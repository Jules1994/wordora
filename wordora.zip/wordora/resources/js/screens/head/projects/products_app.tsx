/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/overview'
import { Project } from '../../../components'

const Products = ({})=> {
  return (
    <div className="w-full xl:px-10 2xl:px-[15%]">
        <h1>Product Plan</h1>
    </div>)
}


Products.layout = page=> <Layout children={page} />
export default Products
