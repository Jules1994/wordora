/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/overview'
import { Project } from '../../../components'

const PaymentsMethods = ({})=> {
 

  return (
    <div className="w-full xl:px-10 2xl:px-[15%]">
        <h1>PaymentsMethods</h1>
    </div>)
}


PaymentsMethods.layout = page=> <Layout children={page} />
export default PaymentsMethods
