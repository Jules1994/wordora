/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/overview'
import { Project } from '../../../components'

const PaymentMethods = ({})=> {

  return (
    <div className="w-full xl:px-10 2xl:ppx-20">
        <h1>PaymentMethods</h1>
    </div>)
}


PaymentMethods.layout = page=> <Layout children={page} />
export default PaymentMethods
