/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/overview'
import { Project } from '../../../components'

const UsersTypes = [
  {key: "all-users", value: "all-users",  text: "All Users"},
  {key: "verified-users", value: "verified-users",  text: "Verified Users"},
  {key: "un-all-users", value: "un-all-users",  text: "Un-Verified Users"},
  {key: "anonymous-users", value: "anonymous-users",  text: "Anonymous Users"}
]

const UsersAuth = ({ }) => {

  const onSearch = (evt)=> {
    const q = evt.target.value
    if(q.length >= 3) {
      router.get("/account/overview", { q }, {preserveState: true})
    }
  }

  const onSelect = (evt)=> {
   
  }

  return (
    <div className="px-[15%] py-10 space-y-10">

      <div className='w-full flex flex-row'>

        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              Users
            </h1>
          </li>


          <li className="relative text-black dark:text-white">
            <p className="text-xl text-slate-600 xl:text-sm">
              Personal access tokens to manage API or CLI.
            </p>
          </li>

        </ul>


        <ul className="flex-0 flex flex-row justify-end items-center gap-x-2">

          <li className="text-black dark:text-white py-3 relative">
            <input type="email" onChange={onSearch} className="w-72 pl-8 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700" placeholder="Search for a project" required />
            <span className="absolute left-2 top-1/3">
              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" />
              </svg>
            </span>
          </li>

          <li className="text-black dark:text-white py-3 relative">
          <select
            onChange={onSelect}
            className="min-w-72  bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full px-2 py-[1.6%] dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          >
            {UsersTypes.map(
              (option: any, index: any) => (
                <option
                  key={index.toString()}
                  value={option.value}
                >
                  {option.text}
                </option>
              )
            )}
          </select>
        </li>


          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              Reload

              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.651 7.65a7.131 7.131 0 0 0-12.68 3.15M18.001 4v4h-4m-7.652 8.35a7.13 7.13 0 0 0 12.68-3.15M6 20v-4h4" />
              </svg>


            </Link>
          </li>

          <li className="group/nav-item relative text-black dark:text-white">
            <Link href='/account/projects/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
              Create new user
            </Link>
          </li>

        </ul>

      </div>

      <h1 className="flex flex-row gap-x-4 bg-red-50 border-[1px] border-red-200 text-red-800 rounded-lg p-4">
        <svg className="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
          <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 13V8m0 8h.01M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
        </svg>

        Personal access tokens can be used to control your whole account and use features added in the future. Be careful when sharing them!
      </h1>

      <div className='w-full'>

        <div className="w-full relative overflow-x-auto border-[1px] border-slate-200 rounded-md">
          <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th scope="col" className="px-6 py-3">
                  Display Name
                </th>

                <th scope="col" className="px-6 py-3">
                  Email
                </th>

                <th scope="col" className="px-6 py-3">
                  Phone
                </th>

                <th scope="col" className="px-6 py-3">
                  Provider
                </th>

                <th scope="col" className="px-6 py-3">
                  Created
                </th>

                <th scope="col" className="px-6 py-3">
                  Last Sign In
                </th>

                <th scope="col" className="px-6 py-3">
                  User UID
                </th>
              </tr>
            </thead>
            <tbody>
              <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                <th scope="row" className="px-6 py-4 font-medium  text-slate-400 whitespace-nowrap dark:text-white">
                  Jules Davis
                </th>
                <td className="px-6 py-4 text-slate-400">
                  mihindoujulesdavis@yahoo.fr
                </td>
                <td className="px-6 py-4 text-slate-400">
                  -
                </td>
                <td className="px-6 py-4 text-slate-400">
                  Github
                </td>
                <td className="px-6 py-4 text-slate-400">
                  01/03/2024 18:32:28
                </td>

                <td className="px-6 py-4 text-slate-400">
                  01/03/2024 18:32:28
                </td>
                <td className="px-6 py-4 text-slate-400">
                  304c5ca4-e84d-4cf1-825c-b4397e51408a
                </td>
              </tr>

            </tbody>
          </table>
        </div>

      </div>

    </div>)
}


UsersAuth.layout = page => <Layout children={page} />
export default UsersAuth
