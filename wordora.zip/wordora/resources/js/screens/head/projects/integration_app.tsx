/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/overview'
import { FetchingData, NoData, SeederData, Stat, State, PaymentMethod } from '../../../components'


const Stats = [
  {
    title: "Database", desc: "REST", data: () => 59, icon: <svg className="w-6 h-6 text-slate-500 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
      <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 6c0 1.657-3.134 3-7 3S5 7.657 5 6m14 0c0-1.657-3.134-3-7-3S5 4.343 5 6m14 0v6M5 6v6m0 0c0 1.657 3.134 3 7 3s7-1.343 7-3M5 12v6c0 1.657 3.134 3 7 3s7-1.343 7-3v-6" />
    </svg>
  },
  {
    title: "Auth", desc: "Auth", data: async () => 48, icon: <svg className="w-6 h-6 text-slate-500 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
      <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0 0a8.949 8.949 0 0 0 4.951-1.488A3.987 3.987 0 0 0 13 16h-2a3.987 3.987 0 0 0-3.951 3.512A8.948 8.948 0 0 0 12 21Zm3-11a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
    </svg>
  },
  {
    title: "Storage", desc: "Storage", data: 0, icon: <svg className="w-6 h-6 text-slate-500 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
      <path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M10 12v1h4v-1m4 7H6a1 1 0 0 1-1-1V9h14v9a1 1 0 0 1-1 1ZM4 5h16a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Z" />
    </svg>
  },
  {
    title: "Realtime", desc: "Reatime", data: 0, icon: <svg className="w-6 h-6 text-slate-500 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
      <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.5 11H5a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h4.5M7 11V7a3 3 0 0 1 6 0v1.5m2.5 5.5v1.5l1 1m3.5-1a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0Z" />
    </svg>
  },
]

const ActivesPayments = [
  { name: "Airtel Money", desc: "Notre plateforme API vous permet d'accéder facilement aux solutions et produits financiers et de les intégrer de manière transparente à vos produits et services.", img: "https://pbs.twimg.com/profile_images/1440300597979222025/49YTv0_o_400x400.png" },
  { name: "Mobicash", desc: "Découvrez un nouveau niveau d'autonomisation financière avec MobileCash, votre application de gestion financière complète et intuitive.", img: "https://gstoremusic.com/artistes/uploads/images/artists/gsm_artiste_20230306101519_a33m1md3d4h58oe6gjg0hg6s0i.png" },
  { name: "Paypal", desc: "Payez vos achats sans saisir vos coordonnées bancaires, recevez vos paiements en ligne et envoyez de l'argent de manière sécurisée avec votre compte PayPal.", img: "https://cdn.prod.website-files.com/6437d506b0e56c918e301844/6475070190c18a4eb7b45911_6474d64dd1374e3e0c18a026_6474d0ee8afb9e950541e4f2_paypal.webp" },
  { name: "Stripe", desc: "Rejoignez Stripe, votre plateforme de paiement en ligne. Avec notre suite d'API, acceptez des paiements et développez rapidement votre entreprise.", img: "https://www.ecommerce-nation.fr/wp-content/uploads/2019/08/stripe-solution.png" },
]

const Integration = ({ }) => {


  return (
    <div className='w-full px-[15%] py-10 space-y-10'>

      <section className='w-full flex flex-row'>

        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              Integration
            </h1>
          </li>


          <li className="relative text-black dark:text-white">
            <p className="text-xl text-slate-600 xl:text-sm">
              View the audit log trail of actions made from your account
            </p>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row items-center gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              <div className="w-2 h-2 rounded-full bg-green-700" /> Project Status
            </Link>
          </li>

          <li className="group/nav-item relative text-black dark:text-white">
            <Link href='/account/projects/create' className="focus:outline-none flex flex-row items-center gap-x-2 text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
              <svg className="w-4 h-4 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 8v8m0-8a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm0 8a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm6-2a2 2 0 1 1 4 0 2 2 0 0 1-4 0Zm0 0h-1a5 5 0 0 1-5-5v-.5" />
              </svg>
              Connect
            </Link>
          </li>

        </ul>

      </section>

      <section className='w-full flex flex-row'>

        <ul className="flex-1 flex flex-row justify-start items-center gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              Filter by
            </h1>
          </li>

          <li className="relative text-black dark:text-white">
            <input type="date"
              className="min-w-auto border-dashed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-2 py-[1.6%] dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            />
          </li>

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              |
            </h1>
          </li>

          <li className="relative text-black dark:text-white">
            <h1 className="text-xs text-gray-500 font-medium">
              Viewing 7 logs in total
            </h1>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="text-black dark:text-white py-3">
            <Link href='/account/organization/create' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              Refresh
              <svg className="w-4 h-4 text-gray-700 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.651 7.65a7.131 7.131 0 0 0-12.68 3.15M18.001 4v4h-4m-7.652 8.35a7.13 7.13 0 0 0 12.68-3.15M6 20v-4h4" />
              </svg>
            </Link>
          </li>

        </ul>

      </section>

      <section className='w-full flex flex-row justify-between gap-x-4'>
        {
          Stats.map((stat, index) => (
            <div className='w-2/5' key={index.toString()}>
              <ViewStat stat={stat} />
            </div>
          ))
        }
      </section>

      <section className='w-full flex flex-col justify-between gap-y-8'>
        <h1 className='font-bold text-xl'>Payments Methods: </h1>

        <div className='w-full flex flex-row justify-between gap-2'>

          {
            ActivesPayments.map((method, index) => (
              <div key={index.toString()} className='w-1/4'>
                <PaymentMethod
                  content={method}
                />
              </div>
            ))
          }
        </div>

      </section>

      <section className='w-full flex flex-col gap-y-8'>

        <h1 className='font-bold text-xl'>Transaction(s)</h1>

        <div className='w-full flex flex-row gap-x-2'>
          <div className='flex-1'>

            <div className="w-full relative overflow-x-auto border-[1px] border-slate-200 rounded-md">
              <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                  <tr>
                    <th scope="col" className="px-6 py-3">
                      Action
                    </th>
                    <th scope="col" className="px-6 py-3">
                      Target
                    </th>
                    <th scope="col" className="px-6 py-3">
                      Date
                    </th>

                  </tr>
                </thead>
                <tbody>
                  {[1, 2, 3].map((log, index) => (
                    <tr key={index.toString()} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                      <th scope="row" className="px-6 py-4 font-medium  text-slate-400 whitespace-nowrap dark:text-white">
                        -
                      </th>
                      <td className="px-6 py-4 text-slate-400">
                        -
                      </td>
                      <td className="px-6 py-4 text-slate-400">
                        01/03/2024 18:32:28
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>

          <div className='flex-1'>

            <div className="w-full relative overflow-x-auto border-[1px] border-slate-200 rounded-md">
              <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                  <tr>
                    <th scope="col" className="px-6 py-3">
                      Action
                    </th>
                    <th scope="col" className="px-6 py-3">
                      Target
                    </th>
                    <th scope="col" className="px-6 py-3">
                      Date
                    </th>

                  </tr>
                </thead>
                <tbody>
                  {[1, 2, 3].map((log, index) => (
                    <tr key={index.toString()} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                      <th scope="row" className="px-6 py-4 font-medium  text-slate-400 whitespace-nowrap dark:text-white">
                        -
                      </th>
                      <td className="px-6 py-4 text-slate-400">
                        -
                      </td>
                      <td className="px-6 py-4 text-slate-400">
                        01/03/2024 18:32:28
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>

          <div className='flex-1'>

            <div className="w-full relative overflow-x-auto border-[1px] border-slate-200 rounded-md">
              <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                  <tr>
                    <th scope="col" className="px-6 py-3">
                      Action
                    </th>
                    <th scope="col" className="px-6 py-3">
                      Target
                    </th>
                    <th scope="col" className="px-6 py-3">
                      Date
                    </th>

                  </tr>
                </thead>
                <tbody>
                  {[1, 2, 3].map((log, index) => (
                    <tr key={index.toString()} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                      <th scope="row" className="px-6 py-4 font-medium  text-slate-400 whitespace-nowrap dark:text-white">
                        -
                      </th>
                      <td className="px-6 py-4 text-slate-400">
                        01/03/2024 18:32:28
                      </td>

                      <td className="px-6 py-4 text-slate-400 text-right">
                        View details
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        </div>

      </section>

    </div>)
}


const ViewStat = ({ stat }) => {

  const [state, setState] = React.useState(State.FETCHING_DATA)
  const [value, setValue] = React.useState(null)
  React.useEffect(() => {

    (async () => {
      if (state === State.FETCHING_DATA) {
        if (typeof (stat.data) === 'function') {
          var resultCall = stat.data()
          if (resultCall instanceof Promise) {
            resultCall = await (await (resultCall.then()))
          }
          setValue(() => resultCall)
        } else {
          resultCall = stat.data
          setValue(() => stat.data)
        }
        setTimeout(() => setState(State.NO_DATA), 1000)
      }
    })()
  }, [])

  return (
    <Stat
      title={stat.title}
      desc={`${stat.desc} Requests`}
      value={`${value ? value : 'NB'}`}
      iconComponent={
        <div className='p-2 bg-slate-100 rounded-md'>
          {stat.icon}
        </div>
      }
    >
      <SeederData
        state={state}
        FetchingComponent={<FetchingData
          title="No data to show"
          content="it may take up to 24h hours for data to show"
          iconComponent={<svg className="w-8 h-8 animate-spin text-green-400 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
            <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.651 7.65a7.131 7.131 0 0 0-12.68 3.15M18.001 4v4h-4m-7.652 8.35a7.13 7.13 0 0 0 12.68-3.15M6 20v-4h4" />
          </svg>} />}

        NoDataComponent={<NoData
          iconComponent={<svg className="w-6 h-6 text-slate-400 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
            <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 13h3.439a.991.991 0 0 1 .908.6 3.978 3.978 0 0 0 7.306 0 .99.99 0 0 1 .908-.6H20M4 13v6a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-6M4 13l2-9h12l2 9" />
          </svg>} />} children={undefined} />
    </Stat>
  )
}



Integration.layout = page => <Layout children={page} />
export default Integration
