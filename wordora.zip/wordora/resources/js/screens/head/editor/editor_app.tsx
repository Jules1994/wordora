/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import SunEditor from "suneditor-react";
import 'suneditor/dist/css/suneditor.min.css';
import Layout from '../../../layouts/overview'
import View from '../../../components/view';
import * as Dialog from '../../../contexts/dialog.context'
import * as MediaLibrary from '../../../components/widgets/medialibrary'


const Types = [
    {
        key: "paragraph",
        value: "ARTICLE",
        text: "Article",
    },
    {
        key: "video",
        value: "VIDEOS",
        text: "Video",
    },
];

const Times = [
    {
        key: "1",
        value: "1",
        text: "1 minute",
    },
    {
        key: "2",
        value: "2",
        text: "2 minutes",
    },

    {
        key: "3",
        value: "3",
        text: "3 minutes",
    },
];

const Editor = ({ post, error }) => {


    const postRef = React.useRef(post)
    const dialogContext = Dialog.useDialogContext()
    const [isOpen, setIsOpen] = React.useState(false)
    const [forceUpdate, setForceUpdate] = React.useState(false)
    const [loading, setLoading] = React.useState(false)

    const handleSaveAction = function () {

        try {
            router.put(`/admin/posts/${postRef.current.id}/update`, { ...postRef.current, post_status: 'draft' })
        } catch (e) {
            /*contextDialog.actions.openDialog({
              component: Dialog.InfoDialog(
                e.message,
                {
                  validate: contextDialog.actions.closeDialog
                }
              )
            })*/
            return
        }
    };

    const handleOnChangeTitle = function () {

        /*contextDialog.actions.openDialog({
          component: Dialog.PromptDialog(postRef.current.title, {
            onTextChange: (value)=> {
    
              postRef.current.title = value 
              setForceUpdate(!forceUpdate)
            },
            validate: contextDialog.actions.closeDialog,
            cancel: contextDialog.actions.closeDialog
          })
        })*/
    }

    const handleOnChangePublishAt = function () {

        /*contextDialog.actions.openDialog({
          component: Dialog.PromptDialog(postRef.current.published_at, {
            type: "datetime-local",
            onTextChange: (published_at)=> {
    
              postRef.current.published_at = published_at 
              setForceUpdate(!forceUpdate)
            },
            validate: contextDialog.actions.closeDialog,
            cancel: contextDialog.actions.closeDialog
            },
          )
        })*/
    }

    const handlePublishAction = function () {

        try {

            try {
                router.put(`/admin/posts/${postRef.current.id}/update`, { ...postRef.current, post_status: 'publish' })
            } catch (e) {
                /*contextDialog.actions.openDialog({
                  component: Dialog.InfoDialog(
                    e.message,
                    {
                      validate: contextDialog.actions.closeDialog
                    }
                  )
                })*/
                return
            }

        } catch (e) {
            /*contextDialog.actions.openDialog({
              component: Dialog.InfoDialog(
                e.message,
                {
                  validate: contextDialog.actions.closeDialog
                }
              )
            })*/
            return
        }
    };

    const handleExplorerAction = function (max, type = "images") {

        const renderItem = ({ item, _ }) => (
            <View className="w-44 xl:w-44 h-40">
                <img src={`/${item.path.replace('storage/', '')}`} loading="lazy" alt={item.alias} className="object-cover w-full h-full rounded" />
            </View>
        )

        const onSelectChange = (photos) => {
            postRef.current.thumbnail = photos[0].path
            setForceUpdate(() => !forceUpdate)
        }

        //contextUploader.actions.openExplorerDialog("image", renderItem, onSelectChange, 1)

        /*contextDialog.actions.openDialog({
          component: {
            header: {
              title: "Preview files",
              icon: "clone",
            },
            child:
              <ExploreView
                type={type}
                max={1}
                base_url="/"
                multiple={max > 1}
                renderItem={({ item, _ })=> (
                  <div className="w-40 h-40">
                    <img src={`/${item.path}`} loading="lazy" alt={item.alias} className="object-cover w-full h-full rounded" />
                  </div>
                )}
                onChange={(photos)=> {
    
                  if(photos.length > 0) {
                    postRef.current.thumbnail = photos[0].path
                    setForceUpdate(()=> !forceUpdate)
                  }
                }}
              />,
            bottom: <Flexbox flexDirection="row" justifyContent="flex-end" alignItems="flex-end" className="border-t-2">
              <button title="Add Files" primary onClick={contextDialog.actions.closeDialog}>
                Add files
              </button>
            </Flexbox>,
          },
          size: "fit"
        });*/
    };

    const handleCreateFileAction = function (_) {

        /*contextUploader.actions.openUploadDialog(null, (file)=> {
          postRef.current.thumbnail = `${file.path}`
          contextDialog.actions.closeDialog()
          setForceUpdate(()=> !forceUpdate)
        })*/
    }

    const handleOnChange = function (content) {
        postRef.current.post_content = content
        //setForceUpdate(()=> !forceUpdate)
    };

    const handleOnDetailToggle = function () {
        setIsOpen(!isOpen)
    }

    const handleOnChangeTags = function (e) {
        postRef.current.metadata = e.target.value
    }

    const handleOnChangeDescription = function (e) {
        postRef.current.description = e.target.value
    }

    const handleOnChangeCategory = function () {

    };

    const handleOnChangeType = function (e) {
        postRef.current.type = e.target.value
        setForceUpdate(() => !forceUpdate)
    };

    const handleOnChangeTime = function (_, { value }) {
        postRef.current.minutes = value
        setForceUpdate(() => !forceUpdate)
    };

    const openDialog = () => {
        const onCancel = () => {
            cancel: dialogContext.actions.closeDialog()
            router.get('/admin/medias');
        }

        const onResult = (media, action?) => {
            dialogContext.actions.closeDialog()
            postRef.current.thumbnail = media.file_path 
            setForceUpdate(!forceUpdate)
        }

        dialogContext.actions.openDialog({
            component: MediaLibrary.MediaLibraryDialog(
                'all',
                onResult,
                onCancel
            )
        })
    }


    return (
        <div className="w-full flex flex-col justify-center items-center bg-white">

            {error && (<label className='bg-red-200 text-sm py-2 px-4 rounded mt-4'>{error}</label>)}

            <div className='w-full flex flex-col justify-center items-center xl:mt-8 bg-white xl:px-[10%] 2xl:px-[20%] xl:min-h-[400px] 2xl:min-h-[200px]'>

                <div className='w-full flex flex-col min-h-[500px]'>
                    {/***** Head bar *****/}
                    <div className="sticky top-16 flex flex-row w-full py-4 bg-white border border-slate-200 rounded" style={{ zIndex: 10000000000000000000 }}>

                        <div className="w-[50%] px-4 flex items-center relative">
                            <button className="absolute -left-8 -top-4 bg-green-70 focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-2 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-9000" onClick={handleOnChangeTitle}>
                                Edit
                            </button>
                            <label className="text-lg text-slate-600 line-clamp-1">{postRef.current.post_title}</label>
                        </div>

                        <div className="w-[50%] px-4 flex gap-x-1 justify-end">

                            <button onClick={handleSaveAction} className="flex gap-x-2 items-center justify-center focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                                Brouillon
                                <svg className="w-4 h-4 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M4 5a1 1 0 0 1 1-1h11.586a1 1 0 0 1 .707.293l2.414 2.414a1 1 0 0 1 .293.707V19a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5Z" />
                                    <path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M8 4h8v4H8V4Zm7 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </button>

                            <button onClick={handleOnChangePublishAt} className="flex gap-x-2 items-center justify-center text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                                Save as draft
                                <svg className="w-4 h-4 text-gray-800" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M4 5a1 1 0 0 1 1-1h11.586a1 1 0 0 1 .707.293l2.414 2.414a1 1 0 0 1 .293.707V19a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5Z" />
                                    <path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M8 4h8v4H8V4Zm7 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </button>
                            <button onClick={handleOnDetailToggle} className="flex gap-x-2 items-center justify-center text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                                <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5.005 11.19V12l6.998 4.042L19 12v-.81M5 16.15v.81L11.997 21l6.998-4.042v-.81M12.003 3 5.005 7.042l6.998 4.042L19 7.042 12.003 3Z" />
                                </svg>
                            </button>
                            <button className={`flex gap-x-2 items-center justify-center text-white xl:text-xs bg-blue-600 border-gray-300 focus:outline-none hover:bg-blue-600/90 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-blue-600 dark:text-white dark:border-gray-600 dark:hover:bg-blue-600/90 dark:hover:border-gray-600 dark:focus:ring-gray-700`} onClick={handlePublishAction}>
                                Publish
                                <svg className="w-4 h-4 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="M12.0001 20v-4M7.00012 4h9.99998M9.00012 5v5c0 .5523-.46939 1.0045-.94861 1.279-1.43433.8217-2.60135 3.245-2.25635 4.3653.07806.2535.35396.3557.61917.3557H17.5859c.2652 0 .5411-.1022.6192-.3557.3449-1.1204-.8221-3.5436-2.2564-4.3653-.4792-.2745-.9486-.7267-.9486-1.279V5c0-.55228-.4477-1-1-1h-4c-.55226 0-.99998.44772-.99998 1Z" />
                                </svg>
                            </button>
                        </div>

                    </div>


                    {/***Content Editor Space */}


                    <div className="flex flex-col justify-center items-start content-start w-full gap-4 mt-4 lg:flex-row">

                        {/***************EDITOR POST****************/}

                        <div className="w-full lg:w-[70%] bg-white rounded">
                            <SunEditor
                                name="editor"
                                hideToolbar={false}
                                placeholder="Saississez votre text ici"
                                defaultValue={postRef.current.post_content}
                                width="100%"
                                height="80vh"
                                setDefaultStyle="font-size: 18px; font-family: tahoma"
                                onChange={handleOnChange}
                                showInline={() => <div />}
                                setOptions={{
                                    buttonList: [
                                        ['undo', 'redo', 'fontSize', 'formatBlock', 'fontColor', 'outdent', 'indent', 'align', 'horizontalRule', 'list', 'link', 'bold', 'image', 'video', 'underline', 'italic', 'strike', 'subscript']
                                    ]
                                }}
                                setAllPlugins={true}
                            />
                        </div>


                        {/************* DETAIL QUICK *************/}

                        <div className="w-full flex flex-col gap-y-2 flex-wrap lg:w-[30%]">

                            <div className="w-full p-4 bg-white rounded">

                                <div className="flex flex-row justify-between w-full">
                                    <h6 className="font-light">Category : </h6>
                                </div>

                                <div className="flex flex-row flex-wrap w-full mt-4 bg-white rounded gap-x-1 h-min-32">
                                    <select
                                        className="w-full flex flex-row gap-x-2 text-gray-900 xl:text-xs border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"
                                        onChange={handleOnChangeType}
                                    >
                                        {
                                            Types.map((type, index) => (
                                                <option key={type.key} value={type.value}>{type.text}</option>
                                            ))
                                        }
                                    </select>

                                </div>

                            </div>

                            <div className="w-full p-4 bg-white rounded">

                                <div className="flex flex-row justify-between w-full">
                                    <h6 className="font-light">Temps de lecture : </h6>
                                </div>

                                <div className="flex flex-row flex-wrap w-full mt-4 bg-white rounded gap-x-1 h-min-32">
                                    <select
                                        className="w-full flex flex-row gap-x-2 text-gray-900 xl:text-xs border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"
                                        onChange={handleOnChangeType}
                                    >
                                        {
                                            Times.map((time) => (
                                                <option key={time.key} value={time.value}>{time.text}</option>
                                            ))
                                        }
                                    </select>

                                </div>

                            </div>

                            <div className="w-full p-4 bg-white rounded">

                                <div className="flex flex-row justify-between w-full">
                                    <h6 className="font-light">Thumbnail</h6>
                                </div>

                                <div className="flex flex-row flex-wrap w-full mt-4 bg-white rounded gap-x-1 h-min-32">
                                    <a onClick={openDialog} href="#/" className="w-full duration-200 border-2 rounded cursor-pointer h-52 hover:border-sky-600">
                                        <img
                                            className="object-cover w-full h-full rounded"
                                            loading="lazy"
                                            src={postRef.current.thumbnail ?
                                                `/${postRef.current.thumbnail}` :
                                                "https://e-filtre.fr/assets/img/image-default.webp"}
                                            alt={postRef.current.title}
                                        />
                                    </a>
                                </div>

                            </div>

                            <div className="w-full p-4 bg-white rounded">

                                <div className="flex flex-row justify-between w-full">
                                    <h6 className="font-light">Description</h6>
                                </div>

                                <div className="flex flex-row flex-wrap w-full mt-4 bg-white rounded gap-x-1 h-min-32">
                                    <textarea
                                        className="w-full border-slate-300 border-2 h-32 rounded p-2"
                                        onChange={handleOnChangeDescription}
                                    >
                                        {postRef.current.description}
                                    </textarea>
                                </div>

                            </div>

                        </div>
                    </div>

                </div>

            </div>

        </div>)
}



Editor.layout = page => <Layout children={page} />
export default Editor