/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/head'
import Toolbar from '../../../components/widgets/toolbar'
import { PanelForm } from '../../../components/widgets/panelform'

const FormData = {
    "layout": "row",
    "sections": [
        {
            "title": "Personal",
            "layout": "column",
            "fields": [
                {
                    "type": "input",
                    "name": "name",
                    "label": "Name",
                    "placeholder": "admin",
                    "validation": {
                        "required": true,
                    }
                },

                {
                    "type": "paragraph",
                    "name": "description",
                    "label": "Description",
                    "placeholder": "Role use be ....",
                    "validation": {
                        "required": true
                    }
                },

                {
                    "type": "input",
                    "name": "color",
                    "label": "Color",
                    "placeholder": "red, #333333, rgba(0, 0, 5, .7)...",
                    "validation": {
                        "required": true
                    }
                }

            ]
        }
    ]
}

export const RoleForm = ({ role }: any) => {
    const ref = React.useRef<any>(null)

    const handleSubmit = ()=> {
        if(ref) {
            const { value, errors } = ref.current?.submit()
            if(ref.current?.hasErrors()) {
                alert(JSON.stringify(errors))
            }else {
                if(role) {
                    router.put("/roles/" + role.id + "/update", value)
                }else {
                    router.post("/roles/create", value)
                }
            }
        }
    }

    return (
        <div className="w-full flex flex-col justify-center items-center">
            <PanelForm
                ref={ref}
                content={{
                    title: `${role ? 'Edit' : 'Create'} role`
                }}
                onSubmit={handleSubmit}
                defaultData={role}
                config={FormData}
            />
        </div>)
}

RoleForm.layout = page => <Layout children={page} title="Organization" />
export default RoleForm
