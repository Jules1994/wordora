/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/account'

export const RoleList = ({ roles }) => {

    const onSearch = (evt) => {
        const q = evt.target.value
        if (q.length >= 3) {
            router.get("/account/overview", { q }, { preserveState: true })
        }
    }

    return (
        <div className="w-full xl:px-10 2xl:ppx-20">


            <div className='w-full flex flex-row'>

                <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

                    <li className="relative text-black dark:text-white">
                        <h1 className="text-xl font-medium">
                            Access Tokens
                        </h1>
                    </li>


                    <li className="relative text-black dark:text-white">
                        <p className="text-xl text-slate-600 xl:text-sm">
                            Personal access tokens can be used with our Management API or CLI.
                        </p>
                    </li>

                </ul>


                <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

                    <li className="text-black dark:text-white py-3">
                        <Link href='#' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                            API Doc

                            <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778" />
                            </svg>

                        </Link>
                    </li>

                    <li className="text-black dark:text-white py-3">
                        <Link href='#' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                            CLI Doc

                            <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778" />
                            </svg>

                        </Link>
                    </li>

                </ul>

            </div>

            <div className='sticky top-0 w-full flex flex-row'>

                <ul className="w-auto flex flex-row justify-start items-center gap-x-2">


                    <li className="text-black dark:text-white py-3 relative">
                        <input type="email" onChange={onSearch} className="w-72 pl-8 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700" placeholder="Search for a project" required />
                        <span className="absolute left-2 top-1/3">
                            <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" />
                            </svg>
                        </span>
                    </li>
                </ul>


                <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

                    <li className="text-black dark:text-white py-3">
                        <Link href='#' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                            API Doc

                            <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778" />
                            </svg>

                        </Link>
                    </li>

                    <li className="text-black dark:text-white py-3">
                        <Link href='#' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                            CLI Doc

                            <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778" />
                            </svg>

                        </Link>
                    </li>

                    <li className="group/nav-item relative text-black dark:text-white">
                        <Link href='/roles/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
                            Create new role
                        </Link>
                    </li>

                </ul>

            </div>

            <section className="w-full flex flex-row gap-6 py-10">
                <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            {/*<th scope="col" className="px-6 py-3">
                                ID
                            </th>*/}
                            <th scope="col" className="px-6 py-3">
                                SLUG
                            </th>
                            <th scope="col" className="px-6 py-3">
                                NAME
                            </th>
                            <th scope="col" className="px-6 py-3">
                                PERMISSION
                            </th>
                            <th scope="col" className="px-6 py-3">
                                ICON
                            </th>
                            <th scope="col" className="px-6 py-3">
                                DESCRIPTION
                            </th>
                            <th scope="col" className="px-6 py-3">
                                COLOR
                            </th>
                            <th scope="col" className="px-6 py-3">
                                ACTIONS
                            </th>
                        </tr>
                    </thead>
                    <tbody>

                        {roles.map((role, index) => (
                            <tr key={`role-${index}`} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                {/*<th scope="row" className="px-6 py-4 font-medium  text-slate-400 whitespace-nowrap dark:text-white">
                                    {index}
                                </th>*/}
                                <td className="px-6 py-4 text-slate-400">
                                    {role.slug}
                                </td>

                                <td className="px-6 py-4 text-slate-400">
                                    {role.name}
                                </td>
                                <td className="px-6 py-4 text-slate-400">
                                    {role.permissions}
                                </td>
                                <td className="px-6 py-4 text-slate-400">
                                    <div className="w-10 h-10 p-4 bg-slate-200 rounded-full" />
                                </td>
                                <td className="px-6 py-4 text-slate-400">
                                    {role.description}
                                </td>
                                <td className="px-6 py-4 text-slate-400 flex flex-row items-center gap-x-4">
                                    <div className={`w-2 h-2 p-1 bg-[${role.color}] rounded-full`} />
                                    {role.color.toUpperCase()}
                                </td>
                                <td className="px-6 py-4 text-slate-400">

                                    <Link href="#">
                                        <svg className="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                            <path stroke="currentColor" strokeWidth="2" d="M21 12c0 1.2-4.03 6-9 6s-9-4.8-9-6c0-1.2 4.03-6 9-6s9 4.8 9 6Z" />
                                            <path stroke="currentColor" strokeWidth="2" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                        </svg>
                                    </Link>

                                    <Link href={`/roles/${role.id}/edit`} type='button'>
                                        <svg className="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                            <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m14.304 4.844 2.852 2.852M7 7H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1v-4.5m2.409-9.91a2.017 2.017 0 0 1 0 2.853l-6.844 6.844L8 14l.713-3.565 6.844-6.844a2.015 2.015 0 0 1 2.852 0Z" />
                                        </svg>
                                    </Link>
                                    <Link href={`/roles/${role.id}/delete`} type='button' method='delete'>
                                        <svg className="w-6 h-6 text-[orangered]" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                            <path fill-rule="evenodd" d="M8.586 2.586A2 2 0 0 1 10 2h4a2 2 0 0 1 2 2v2h3a1 1 0 1 1 0 2v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V8a1 1 0 0 1 0-2h3V4a2 2 0 0 1 .586-1.414ZM10 6h4V4h-4v2Zm1 4a1 1 0 1 0-2 0v8a1 1 0 1 0 2 0v-8Zm4 0a1 1 0 1 0-2 0v8a1 1 0 1 0 2 0v-8Z" clip-rule="evenodd" />
                                        </svg>
                                    </Link>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </section>
        </div>)
}


RoleList.layout = page => <Layout children={page} title="role List" />
export default RoleList
