/* eslint-disable prettier/prettier */
import React from 'react'
import { router } from '@inertiajs/react'
import Layout from '../../../layouts/head'
import { PanelForm } from '../../../components/widgets/panelform'

const FormDataFields = {
    "layout": "row",
    "sections": [
        {
            "layout": "column",
            "fields": [

                {
                    "type": "input",
                    "name": "slug",
                    "label": "Slug",
                    "placeholder": "Menu principale",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 200
                    }
                },

                {
                    "type": "input",
                    "name": "name",
                    "label": "Name",
                    "placeholder": "A Propos",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 200
                    }
                },

                {
                    "type": "paragraph",
                    "name": "description",
                    "label": "Description",
                    "placeholder": "Menu de la barre de navigation...",
                    "validation": {
                        "required": true,
                        "minLength": 3,
                        "maxLength": 200
                    }
                },
            ]
        }
    ]
}

const Forms = ({ menu, error }) => {

    console.log(menu)
    const ref = React.useRef<any>(null)

    const handleSubmit = async () => {
        if (ref) {

            try {
                const { value } = ref.current?.submit()
                console.log(value)

                if(!menu) {
                    router.post("/admin/menus/create", value, {
                        forceFormData: true,
                    })
                }else {

                    router.put(`/admin/menus/${menu.id}/update`, value, {
                        forceFormData: true,
                    })
                }

            } catch (e) {
                alert(e.message)
            }
        }
    }

    return (
        <div className="w-full flex flex-col justify-center items-center">
            <PanelForm
                ref={ref}
                content={{
                    title: `${menu ? 'Edit' : 'Create'} menu`
                }}
                onSubmit={handleSubmit}
                defaultData={menu}
                config={FormDataFields}
            />

            {
                error && (
                    <label className='bg-red-200 text-sm text-red-700 py-2 px-4 rounded mt-4'>{error}</label>
                )
            }
        </div>)
}



Forms.layout = page => <Layout children={page} title="Create menu"  />
export default Forms