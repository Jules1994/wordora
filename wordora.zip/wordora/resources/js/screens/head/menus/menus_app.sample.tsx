/* eslint-disable prettier/prettier */
import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../../../layouts/overview'

export const Menus = ({ menus = [] }) => {

  const onSearch = (evt) => {
    const search = evt.target.value
    if (search.length >= 3) {
        router.get("/admin/menus", { search }, { preserveState: true })
    }
}

  const handleEditTheme = async (menu) => {
    router.get(`/admin/menus/${menu.id}/edit`)
  }

  const handleDeleteTheme = async (menu) => {
    router.put(`/admin/menus/${menu.id}/delete`)
  }


  return (
    <div className='w-full px-24 py-10 space-y-10'>


      <div className='w-full flex flex-row'>

        <ul className="flex-1 flex flex-col justify-center items-start gap-x-2">

          <li className="relative text-black dark:text-white">
            <h1 className="text-xl font-medium">
              Menu management
            </h1>
          </li>

          <li className="text-black dark:text-white py-3 relative">
            <input type="email" onChange={onSearch} className="w-72 pl-8 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700" placeholder="Search for a project" required />
            <span className="absolute left-2 top-1/3">
              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" />
              </svg>
            </span>
          </li>

        </ul>


        <ul className="flex-1 flex flex-row justify-end items-center gap-x-2">

          <li className="group/nav-item relative text-black dark:text-white">
            <Link href='/admin/menus/create' className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
              Create new menu
            </Link>
          </li>

          <li className="text-black dark:text-white py-3">
            <Link href='#' type='button' className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
              API Doc
              <svg className="w-4 h-4 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778" />
              </svg>
            </Link>
          </li>
        </ul>

      </div>

      <div className='w-full'>

        <div className="w-full relative overflow-x-auto border-[1px] border-slate-200 rounded-md">
          <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th scope="col" className="px-6 py-3">
                  ID
                </th>

                <th scope="col" className="px-6 py-3">
                  Slug
                </th>

                <th scope="col" className="px-6 py-3">
                  Title
                </th>

                <th scope="col" className="px-6 py-3">
                  Thumbnail
                </th>

                <th scope="col" className="px-6 py-3">
                  Status
                </th>

                <th scope="col" className="px-6 py-3">
                  Action
                </th>

              </tr>
            </thead>
            <tbody>
              {menus.map((menu: any, index: any) => (
                <tr key={index.toString()} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                  <th scope="row" className="px-6 py-4 font-medium  text-slate-400 whitespace-nowrap dark:text-white">
                    {index + 1}
                  </th>

                  <td className="px-6 py-4 text-slate-400">
                    {menu.slug}
                  </td> 

                  <td className="px-6 py-4 text-slate-400">
                    {menu.name}
                  </td> 

                  <td className="px-6 py-4 text-slate-400">
                    {menu.description}
                  </td>


                  <td className="px-6 py-4 text-slate-400">
                    <label className={`${menu.post_status === 'draft' ? 'bg-white border border-slate-200' : 'bg-green-300 text-green-800'} px-3 py-2 rounded`}>{menu.taxonomy}</label>
                  </td>

                  <td className="px-6 py-4 space-x-4 text-slate-400 text-right">

                    <button className='w-auto'>
                      <svg className="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeWidth="2" d="M21 12c0 1.2-4.03 6-9 6s-9-4.8-9-6c0-1.2 4.03-6 9-6s9 4.8 9 6Z" />
                        <path stroke="currentColor" strokeWidth="2" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                      </svg>
                    </button>

                    <button onClick={() => handleEditTheme(menu)}>
                      <svg className="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m14.304 4.844 2.852 2.852M7 7H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1v-4.5m2.409-9.91a2.017 2.017 0 0 1 0 2.853l-6.844 6.844L8 14l.713-3.565 6.844-6.844a2.015 2.015 0 0 1 2.852 0Z" />
                      </svg>
                    </button>

                    <button onClick={() => handleDeleteTheme(menu)}>
                      <svg className="w-6 h-6 text-[orangered]" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                        <path fillRule="evenodd" d="M8.586 2.586A2 2 0 0 1 10 2h4a2 2 0 0 1 2 2v2h3a1 1 0 1 1 0 2v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V8a1 1 0 0 1 0-2h3V4a2 2 0 0 1 .586-1.414ZM10 6h4V4h-4v2Zm1 4a1 1 0 1 0-2 0v8a1 1 0 1 0 2 0v-8Zm4 0a1 1 0 1 0-2 0v8a1 1 0 1 0 2 0v-8Z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>

    </div>)
}


Menus.layout = page => <Layout children={page} />
export default Menus
