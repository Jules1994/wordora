import React from "react"
import { Head, Link } from '@inertiajs/react'

export default ({  })=> {
    return (
        <div className="w-full h-full fixed justify-center items-center">
            <Head title="Headless Starter" />
            <h1>Headless Template</h1>
            <Link href="/auth">
                Se connecter
            </Link>
        </div>
    )
}