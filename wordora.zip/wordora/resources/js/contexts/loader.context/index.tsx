import React from "react";

const INIT_DATA = { strings: [], colors: [], assets: [] };

const LoaderContext = React.createContext<any>(null);
export default function LoaderProviderContext({ children }) {
  const [data, setData] = React.useState<any>(INIT_DATA);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);

  React.useEffect(function () {
    /*const asyncLoadResources = async function () {
      try {
        await load(["strings", "colors", "assets"], (results) => {
          setData(results);
          setLoading(false);
        });
      } catch (e) {
        console.log(e.message);
        setError(() => e.message);
        setLoading(false);
      }
    };

    if (loading) {
      //asyncLoadResources();
    }*/
  }, []);

  //&&

  return (
    <LoaderContext.Provider value={{ loading, error, data }}>
      {!loading && <>{children}</>}
    </LoaderContext.Provider>
  );
}

export const useResources = function () {
  const { data, loading, error } = React.useContext<any>(LoaderContext);
  const string = function (key) {
    return getValue(data.strings, key);
  };

  const asset = function (key) {
    return getValue(data.assets, key);
  };

  const color = function (key) {
    return getValue(data.colors, key);
  };

  return { string, asset, color, error, loading };
};

/*const load = async function (paths, callback) {
  try {
    const results = {};
    for await (var path of paths) {
      const key = path.split(".")[0];
      var textFile = await import(`../../res/${path}.txt`);
      textFile = textFile.default;
      const result = await fetch(textFile);
      const content = await result.text();
      results[`${key}`] = content.split("\n");
    }
    callback(results);
  } catch (e) {
    throw e.message;
  }
};*/

const getValue = function (data, key) {
  const value = data.find((el) => {
    const segs = el.split("=");
    return segs.length > 0 && segs[0].toUpperCase() === key.toUpperCase();
  });

  if (!value) {
    return null;
  }

  return value.split("=")[1];
};
