import React from "react";
export const ThemeContext = React.createContext(null);

export default function ThemeProviderContext({ children }) {
  const [theme, setTheme] = React.useState("light");
  const [minimize, setMinimize] = React.useState(true);

  const toggleTheme = React.useCallback(() => {
    setTheme(theme === "light" ? "dark" : "light");
  }, [theme]);

  const toggleMinimize = React.useCallback(() => {
    setMinimize(minimize === false);
  }, [minimize]);

  const matchTheme = React.useCallback(
    (value) => {
      return theme === value;
    },
    [theme]
  );

  const matchMinimize = React.useCallback(
    (value) => {
      return minimize === value;
    },
    [minimize]
  );

  return (
    <ThemeContext.Provider
      value={{
        theme,
        toggleTheme,
        matchTheme,
        minimize,
        toggleMinimize,
        matchMinimize,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}
