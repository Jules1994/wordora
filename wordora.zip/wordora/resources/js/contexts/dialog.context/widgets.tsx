import React from "react"

function fn(): void {};

const INFO_CONTENT = `
  Le lorem ipsum est, en imprimerie, une suite de mots sans
  signification utilisée à titre provisoire pour calibrer une mise en
  page, le texte définitif venant remplacer le faux-texte dès qu'il est
  prêt ou que la mise en page est achevée. Généralement, on utilise un
  texte en faux latin, le Lorem ipsum ou Lipsum.
`;

export const InfoDialog = (
  state = INFO_CONTENT,
  actions = { validate: fn, cancel: fn, onRequestClose: fn }
) => {
  return {
    header: {
      title: "Information",
      icon: "info",
    },

    child: (
      <div style={{ width: "100%", padding: "2%" }}>
        <p style={{ fontSize: 16 }}>{state}</p>
      </div>
    ),
    bottom: (
      <div
        style={{ width: "100%", padding: "2%" }}
      >
        <button onClick={actions.cancel}>
          Ok
        </button>
      </div>
    ),
  };
};

export const CustomDialog = (
  header = { title: "Information", icon: "info" },
  ContentElement = null,
  actions = { validate: fn, cancel: fn }
) => {
  return {
    header,
    child: ContentElement,
    bottom: (
      <div
        className="flex justify-end items-center"
        style={{ width: "100%", padding: "2%" }}
      >
        <button onClick={actions.validate}>
          Ok
        </button>
      </div>
    ),
  };
};

export const PromptDialog = (
  state = "",
  actions = { type: "text", placeholder: "type here",  validate: fn, cancel: fn, onTextChange: (text: string) => {} }
) => {
  return {
    header: {
      title: "Warning",
      icon: "warning",
    },
    child: (
      <div style={{ width: "100%", padding: "2%" }}>
        <input
          type={actions.type}
          placeholder={actions.placeholder}
          defaultValue={state}
          onChange={(e) => {
            const value = e.target.value;
            actions.onTextChange(value);
          }}
        />
      </div>
    ),
    bottom: (
      <div
        className="flex justify-end items-center"
        style={{ width: "100%", padding: "2%" }}
      >
        <button title="Cancel" color="orange" onClick={actions.cancel}>
          Cancel
        </button>
        <button title="Validate" onClick={actions.validate}>
          Ok
        </button>
      </div>
    ),
  };
};

export const ConfirmDialog = (
  state = "",
  actions = { validate: fn, cancel: fn }
) => {
  return {
    header: {
      title: "Warning",
      icon: "warning",
    },
    child: (
      <div className="w-full p-4 xl:p-[2%]">
        <div
          dangerouslySetInnerHTML={{ __html: state }}
        />
      </div>
    ),
    bottom: (
      <div
        className="w-full border-t-2 border-slate-100 p-[2%] flex gap-x-4 justify-end items-center"
      >
        <button title="Cancel" color="orange" onClick={actions.cancel} className="flex flex-row gap-x-2 text-gray-900 xl:text-xs bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700" >
          Cancel
        </button>
        <button title="Validate" onClick={actions.validate} className="focus:outline-none text-white xl:text-xs bg-green-700 hover:bg-green-900 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-1.5 dark:bg-green-900 dark:hover:bg-green-800 dark:focus:ring-green-900">
          Ok
        </button>
      </div>
    ),
  };
};
