import React from 'react';
import View from '../../components/view'

const DURATION = 250;
const INITIAL_OBJECT = {
    component: { header: null, child: null, bottom: null },
    backgroundColor: "bg-white/50",
};
export const DialogContext = React.createContext<any>(null);
export const useDialogContext = () => React.useContext(DialogContext);

export function DialogContextProvider({ children }: any) {
    const ref = React.useRef<any>(INITIAL_OBJECT);
    const [state, setState] = React.useState({
        isOpen: false,
        hidden: true,
        inputText: "",
    });

    const toggle = React.useCallback(() => {
        setState({
            ...state,
            isOpen: !state.isOpen,
        });
    }, [state]);

    const openDialog = ({ component, opacity, size = "small" }: any) => {
        ref.current.opacity = opacity;
        ref.current.size = size;
        if (component) {
            if (component.header) {
                //alert(typeof component.header === "object");
                if (typeof component.header === "object") {
                    ref.current.component.header = (
                        <DialogHeaderbox
                            centered
                            title={component.header.title}
                            icon={component.header.icon}
                            onClose={closeDialog}
                        />
                    );
                } else {
                    ref.current.component.header = component.header;
                }
            }

            if (component.child) {
                ref.current.component.child = component.child;
            }

            if (component.bottom) {
                ref.current.component.bottom = component.bottom;
            }
        }

        setState({
            ...state,
            isOpen: true,
        });
    };

    const closeDialog = () => {
        setState({
            ...state,
            isOpen: false,
        });
        ref.current.component.bottom = null;
    };

    return (
        <DialogContext.Provider
            value={{
                state,
                actions: { toggle, openDialog, closeDialog },
            }}
        >
            {children}
            <div className={`fixed left-0 ${state.isOpen ? 'flex opacity-1 top-0': 'hidden opacity-0 -top-10'} transition-all duration-500 flex-col items-center z-100 w-full h-screen bg-white/70`} style={{ zIndex: 9999999999999 }}>
                {state.isOpen && <Dialogbox
                    size={ref.current.size}
                    header={ref.current.component.header}
                    bottom={ref.current.component.bottom}
                    onClose={closeDialog}
                >
                    {ref.current.component.child}
                </Dialogbox>
                }
            </div>
        </DialogContext.Provider>
    );
}

export const DialogHeaderbox = ({ title, onClose, icon }: any) => (
    <View className="w-full py-2 px-2 flex flex-row justify-between items-center border-b-2 border-slate-100">
        <View className='w-[90%] flex items-center gap-x-5'>
            {icon}
            {title && <h4 style={{ color: "black", marginTop: 5 }}>{title}</h4>}
        </View>
        <button onClick={onClose}>
            <svg className="w-5 h-5 text-gray-400 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18 17.94 6M18 18 6.06 6" />
            </svg>
        </button>
    </View>
);

const Dialogbox = ({ size, header = null, bottom = null, children }: any) => {

    const getSize = (p) => {
        if (!p) return "w-1/3"
        else if (p === "small") {
            return "w-1/3"
        } else if (p === "full") {
            return "w-full h-full"
        } else {
            return "w-1/2"
        }
    }

    return (
        <View className={`${getSize(size)} min-h-1/5 max-h-[95%] mt-[2%] flex flex-col justify-between bg-white rounded border-2 border-gray-100transition-colors`}>
            {header}
            <View className='w-full h-auto max-h-[95%] overflow-y-auto bg-inherit'>{children}</View>
            {bottom}
        </View>
    );
};
