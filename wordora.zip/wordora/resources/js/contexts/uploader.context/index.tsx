import React from "react";
import View from "../../components/view";
import { ExploreView } from "../../components/Widgets/explorer";
import { MultipleUploadFilesbox } from "../../components/Widgets/multipleuploadfilesbox";
import { useDialogContext } from "../Dialog.context";

export const UploaderContext = React.createContext<any>(null);
export const useUploaderContext = () => React.useContext(UploaderContext);

export const UploaderContextProvider = ({ children }) => {
    const contextDialog = useDialogContext();
    const [forceUpdate, setForceUpdate] = React.useState(true)


    React.useEffect(()=> {
        if(forceUpdate) {
            setForceUpdate(false)
        }
    }, [])

    const openUploadDialog = React.useCallback((folder_uid, onCompleteUpload) => {
        contextDialog.actions.openDialog({
            component: {
                header: {
                    title: "Files Upload",
                    icon: "file",
                },
                child: (
                    <MultipleUploadFilesbox
                        folder={folder_uid}
                        onCompleteUpload={onCompleteUpload}
                    />
                ),
                bottom: null,
            },
            opacity: true,
        });
    }, []);

    const openExplorerDialog = React.useCallback((type, renderItem, onSelectItem, max = 1) => {
        contextDialog.actions.openDialog({
            component: {
                header: {
                    title: "Preview files",
                    icon: "clone",
                },
                child: (
                    <ExploreView
                        type={type}
                        max={max}
                        base_url="/"
                        multiple={max > 1}
                        renderItem={renderItem}
                        onChange={(photos) => {
                            if (photos.length > 0) {
                                onSelectItem(photos)
                            }
                        }}
                    />
                ),
                bottom: (
                    <View
                        flexDirection="row"
                        justifyContent="flex-end"
                        alignItems="flex-end"
                        className="border-t-2"
                    >
                        <button
                            title="Add Files"
                            onClick={contextDialog.actions.closeDialog}
                        >
                            Add files
                        </button>
                    </View>
                ),
            },
            size: "fit",
        });
    }, []);

    return (
        <UploaderContext.Provider value={{ actions: { openExplorerDialog, openUploadDialog } }}>
            {children}
        </UploaderContext.Provider>
    );
};
