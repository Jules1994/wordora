import axios from "axios";
import React from "react";
export const PoliciesContext = React.createContext<any>(null);

const Key = "#current_user"
const Url = "/users/me"

export default function PoliciesProvider({ children }) {

  const [fetching, setFetching] = React.useState(true)
  const [user, setUser] = React.useState(null)


  React.useEffect(() => {
    (async () => {

      if (fetching) {
        var userObject = null
        const _userJson = localStorage.getItem(Key)
        if (_userJson) {
          userObject = JSON.parse(_userJson)
        } else {
          const res = await axios.get(Url)
          userObject = res.data
        }

        setUser(() => userObject)
        setFetching(false)
      }
    })()
  }, [])

  if (fetching) {
    return <div className="fixed w-full h-full justify-center items-center">
      <h1>Fetching...</h1>
    </div>
  }

  return (
    <PoliciesContext.Provider
      value={{
        state: {
          fetching,
          user
        },
        actions: {
          setUser,
          setFetching
        }
      }}
    >
      {children}
    </PoliciesContext.Provider>
  );
}

export const RolePolicy = React.memo(({ roles, children }: any) => {
  const { state } = React.useContext<any>(PoliciesContext)

  if (!state.user) {
    return null
  }

  if (Array.isArray(roles)) {
    if (!roles.includes(state.user.roleSlug.toLowerCase())) {
      return null
    }
  } else if (typeof roles && roles !== '*') {
    return null
  }

  return <>
    {children}
  </>
})


export const CreatePolicy = React.memo(({ roles, children }: any) => {
  const { state } = React.useContext<any>(PoliciesContext)

  if (!state.user) {
    return null
  }

  if (Array.isArray(roles)) {
    if (!roles.includes(state.user.roleSlug.toLowerCase())) {
      return null
    }
  } else if (typeof roles && roles !== '*') {
    return null
  }

  return <>
    {children}
  </>
})


export const EditPolicy = React.memo(({ roles, children }: any) => {
  const { state } = React.useContext<any>(PoliciesContext)

  if (!state.user) {
    return null
  }

  if (Array.isArray(roles)) {
    if (!roles.includes(state.user.roleSlug.toLowerCase())) {
      return null
    }
  } else if (typeof roles && roles !== '*') {
    return null
  }

  return <>
    {children}
  </>
})


export const ViewPolicy = React.memo(({ roles, children }: any) => {
  const { state } = React.useContext<any>(PoliciesContext)

  if (!state.user) {
    return null
  }

  if (Array.isArray(roles)) {
    if (!roles.includes(state.user.roleSlug.toLowerCase())) {
      return null
    }
  } else if (typeof roles && roles !== '*') {
    return null
  }

  return <>
    {children}
  </>
})

export const PermPolicy = ({ requiredPermission, children }) => {
  const policy = usePolicy()

  if (policy.user.permissions.includes(requiredPermission)) {
    return children;
  }

  return <>
    {children}
  </>
}

export const usePolicy = () => {

  const context = React.useContext(PoliciesContext)
  return context
}

const isValid = (userPermissions, permissions)=> {

  for(var permission of userPermissions) {
    if(permissions.includes(permission)) {
      return true
    }
  }
  return false
}
