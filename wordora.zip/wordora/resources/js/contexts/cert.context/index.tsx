import React from "react";
  import { Cert, createCert } from "./cert";
  
  export const CertContext = React.createContext(null);
  export default function CertificateProviderContext({ children }) {
    const certificateRef = React.useRef(null);
    const [loaded, setLoaded] = React.useState(false);
  
    React.useEffect(() => {
      const loadCertificate = async () => {
        const JsonDataCert = window.localStorage.getItem("@cert.1.0.0");
        if (JsonDataCert === null) {
          certificateRef.current = createCert(new Date().addDays(30));
        } else {
          certificateRef.current = Cert.fromJSON(JsonDataCert);
        }
  
        setLoaded(true);
      };
  
      if (!loaded) {
        loadCertificate();
      }
    }, []);
  
    const renewal = React.useCallback(() => {
      certificateRef.current = createCert(new Date());
      const JsonDataCert = JSON.stringify(certificateRef.current);
      const Base64Data = Buffer.from(JsonDataCert, "base64");
  
      window.localStorage.setItem("@cert.1.0.0", JsonDataCert);
  
      alert(certificateRef.current.expiredDate.formatToBillingToHuman());
      //window.location = "https://ho28z7-3000.csb.app/post/le-matheux-1993";
    }, []);
  
    if (certificateRef.current === null) {
      return null;
    }
  
    return (
      <CertContext.Provider
        value={{ certificate: certificateRef.current, renewal }}
      >
        {children}
      </CertContext.Provider>
    );
  }
  
  export const useCert = () => {
    const context = React.useContext(CertContext);
    return context;
  };
  