export const Cert = class {
    
    constructor(public reference, public startedDate, public expiredDate) {}
  
    isValid() {
      return this.expiredDate.getTime() - new Date().getTime() > 0;
    }
  
    static create(startedDate, expiredDate) {
      return new Cert(uuidv4(), startedDate, expiredDate);
    }
  
    static formJSON(CertJsonData) {
      return new Cert(
        CertJsonData.reference,
        new Date(CertJsonData.startedDate),
        new Date(CertJsonData.expiredDate)
      );
    }
  };
  
  export const createCert = function (startedDate, days = 30) {
    return Cert.create(uuidv4(), startedDate, startedDate.addDays(days));
  };
  
  export function uuidv4() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
      (c ^ (Math.random(new Uint8Array(1))[0] & (15 >> (c / 4)))).toString(16)
    );
  }
  