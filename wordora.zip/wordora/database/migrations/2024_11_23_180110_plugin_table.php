<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('plugins', function (Blueprint $table) {
            $table->id();
            $table->string('slug')->unique();
            $table->string('name');
            $table->string('description')->nullable();
            $table->boolean('is_active')->default(false);
            $table->string('cdn_url')->nullable();
            $table->string('local_path')->nullable();
            $table->string('version')->default('1.0.0');
            $table->boolean('installed')->default(false);
            $table->unsignedBigInteger('id_form')->nullable(); // Associer à un formulaire
            $table->json('values')->nullable(); // Stocker les données spécifiques du plugin
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
        Schema::dropIfExists('plugins');
    }
};
