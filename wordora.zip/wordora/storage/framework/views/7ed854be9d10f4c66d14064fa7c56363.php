<?php $__env->startSection('page'); ?>
    <?php if(isset($posts)): ?>
        
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cellulegeek/Documents/akora-wordpress/resources/views/web/blog.blade.php ENDPATH**/ ?>