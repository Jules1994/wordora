<?php $__env->startSection('page'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cellulegeek/Documents/akora-wordpress/storage/app/public/themes/default/page.blade.php ENDPATH**/ ?>