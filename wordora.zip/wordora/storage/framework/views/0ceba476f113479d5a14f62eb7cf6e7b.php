<?php $__env->startSection('page'); ?>
    <div class="w-full flex flex-row gap-x-10 justify-start items-start bg-white xl:px-[16%]">

        <!--- Articles --->
        <section
            class="w-[70%] flex flex-col justify-start items-start flex-wrap gap-y-10 py-10">
            <nav class="flex" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                  <li class="inline-flex items-center">
                    <a href="#" class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                      <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z"></path>
                      </svg>
                      Acceuil
                    </a>
                  </li>
                  <li>
                    <div class="flex items-center">
                      <svg class="rtl:rotate-180 w-3 h-3 text-gray-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"></path>
                      </svg>
                      <a href="#" class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Achat Public</a>
                    </div>
                  </li>
                  <li aria-current="page">
                    <div class="flex items-center">
                      <svg class="rtl:rotate-180 w-3 h-3 text-gray-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"></path>
                      </svg>
                      <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">[Croissance et vie d'entreprise]</span>
                    </div>
                  </li>
                </ol>
            </nav>



            <div class="flex-1">
                <h1 class="pl-4 xl:pl-0 text-4xl font-bold text-black">
                    En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de test équipes.
                </h1>
            </div>


            <div class="flex-1">
                [Croissance et vie d'entreprise]<br><br>

                Nous sommes ravis d'accueillir un nouveau talent au sein de notre équipe Externalisation-Marchés publics chez <a href="#" class="text-sky-800 font-semibold">N-KAKE Conseil !</a>
                
                <a href="#" class="text-sky-800 font-semibold">Rode MBOUALA</a> a rejoint notre équipe en tant que Consultante Juriste Marchés publics.<br> <br>
                
                Spécialisée en commande publique, forte d'expériences complémentaires en tant que Juriste, Acheteur, que ce soit en collectivité, secteur privé ou encore chez les opérateurs de compétences, elle a désormais en charge la gestion des procédures d'achats au sein du cabinet. 
                
                Avec cette expertise et son engagement, nous sommes impatients de continuer à offrir à nos clients des solutions efficaces dans l'accompagnement à l'externalisation sécurisée de la fonction Achat et plus globalement dans la gestion de la commande publique.[Croissance et vie d'entreprise]

                Nous sommes ravis d'accueillir un nouveau talent au sein de notre équipe Externalisation-Marchés publics chez N-KAKE Conseil !

                Rode MBOUALA a rejoint notre équipe en tant que Consultante Juriste Marchés publics.<br> <br>

                Spécialisée en commande publique, forte d'expériences complémentaires en tant que Juriste, Acheteur, que ce soit en collectivité, secteur privé ou encore chez les opérateurs de compétences, elle a désormais en charge la gestion des procédures d'achats au sein du cabinet. 

                Avec cette expertise et son engagement, nous sommes impatients de continuer à offrir à nos clients des solutions efficaces dans l'accompagnement à l'externalisation sécurisée de la fonction Achat et plus globalement dans la gestion de la commande publique.<br> <br>

                Bienvenue à bord, <a href="#" class="text-sky-800 font-semibold">Rode MBOUALA !</a><br><br>

                Nous continuons à renforcer notre position en tant que Cabinet conseil dédié aux fonctions Achats et marchés publics et à fournir à nos clients, dans un environnement complexe, un accompagnement personnalisé au plus près de leur besoin. 

                Une question, un projet d'externalisation de la fonction Achat public ? 

                N'hésitez pas à nous écrire à <a href="#" class="text-sky-800 font-semibold">contact@nkakeconseil.com.</a><br><br>

                <a href="#" class="text-sky-800 font-semibold">hashtag#NouvelEmbauche hashtag#hiring hashtag#Collectivitepublique hashtag#Expertise hashtag#MarchePublic hashtag#Conseil hashtag#Croissance hashtag#CommandePublique.</a>
                
                Bienvenue à bord, <rode href="#" class="text-sky-800 font-semibold">Rode MBOUALA !<br> <br>
                
                Nous continuons à renforcer notre position en tant que Cabinet conseil dédié aux fonctions Achats et marchés publics et à fournir à nos clients, dans un environnement complexe, un accompagnement personnalisé au plus près de leur besoin. <br> <br>
                
                Une question, un projet d'externalisation de la fonction Achat public ? <br> <br>
                
                N'hésitez pas à nous écrire à contact@nkakeconseil.com.<br> <br>
                
                <a href="#" class="text-sky-800 font-semibold">hashtag#NouvelEmbauche hashtag#hiring hashtag#Collectivitepublique hashtag#Expertise hashtag#MarchePublic hashtag#Conseil hashtag#Croissance hashtag#CommandePublique</a><br><br>
                
                <img src="https://media.licdn.com/dms/image/v2/D4E22AQH3XyVme6IpUw/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1712308057909?e=1727308800&amp;v=beta&amp;t=iGZTmAIRYEBKz3Bgs57zqa6Tw1VHPbXZioIoYsmHrAc" class="w-full">

            </rode></div>

        </section>


        <!--- Last articles --->
        <section id="id" class="sticky top-4 w-[30%] flex flex-col justify-end items-end space-y-10 py-10 px-0">

            <div class="flex-1">
                <h1 class="pl-4 xl:pl-0 text-4xl font-bold text-black">
                    Recherche
                </h1>
            </div>

            <div class="w-full">
                <form class="flex-1 text-black flex flex-col justify-start gap-y-4">
                    <div class="w-full relative">
                        <input type="email" name="email" placeholder="Saississez votre email"
                            class="p-4 rounded-full w-full border-slate-300">
                        <button class="p-4 rounded-full absolute right-[0%] top-[1%] text-white bg-google-red/80">
                            <svg class="w-6 h-6 text-white-800 dark:text-white" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                                viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-width="2"
                                    d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"></path>
                            </svg>
                        </button>
                    </div>
                </form>
            </div>

            <div class="flex-1">
                <h1 class="pl-4 xl:pl-6 text-xl font-bold text-black">
                    Last posts
                </h1>
                <ul class="w-full flex flex-col justify-end items-end gap-y-2">
                    <?php $__currentLoopData = [0, 2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li
                            class="relative flex flex-row w-full xl:w-full 2xl:w-full border-2 flex-shrink-0 border-transparent cursor-pointer rounded-md hover:border-google-red/80 transition-all hover:shadow-black/50 hover:shadow-xl">
                            <div class="w-full">
                                <img src="https://images.squarespace-cdn.com/content/v1/641075275eac4c06e68a4bf7/1694606194980-XV2AXQFIL6GOLU7BBUAH/AdobeStock_549476621+12.png"
                                    class="w-16 h-16 object-cover border-4 border-white float-right">
                                <h1 class="relative font-medium text-sm text-black px-6 py-2">
                                    En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                                    test équipes.
                                </h1>
    
                                <div class="flex flex-row justify-between items-center px-6 py-2 text-sm text-gray-500">
    
                                    <div class="flex flex-row items-center gap-x-2 text-google-red">
                                        <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                            viewBox="0 0 24 24">
                                            <path
                                                d="M8.597 3.2A1 1 0 0 0 7.04 4.289a3.49 3.49 0 0 1 .057 1.795 3.448 3.448 0 0 1-.84 1.575.999.999 0 0 0-.077.094c-.596.817-3.96 5.6-.941 10.762l.03.049a7.73 7.73 0 0 0 2.917 2.602 7.617 7.617 0 0 0 3.772.829 8.06 8.06 0 0 0 3.986-.975 8.185 8.185 0 0 0 3.04-2.864c1.301-2.2 1.184-4.556.588-6.441-.583-1.848-1.68-3.414-2.607-4.102a1 1 0 0 0-1.594.757c-.067 1.431-.363 2.551-.794 3.431-.222-2.407-1.127-4.196-2.224-5.524-1.147-1.39-2.564-2.3-3.323-2.788a8.487 8.487 0 0 1-.432-.287Z">
                                            </path>
                                        </svg>
    
                                        1024 lus
                                    </div>
    
                                    <div class="flex flex-row items-center gap-x-2">
                                        <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                            viewBox="0 0 24 24">
                                            <path fill-rule="evenodd"
                                                d="M10 5a2 2 0 0 0-2 2v3h2.4A7.48 7.48 0 0 0 8 15.5a7.48 7.48 0 0 0 2.4 5.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1V7a4 4 0 1 1 8 0v1.15a7.446 7.446 0 0 0-1.943.685A.999.999 0 0 1 12 8.5V7a2 2 0 0 0-2-2Z"
                                                clip-rule="evenodd"></path>
                                            <path fill-rule="evenodd"
                                                d="M10 15.5a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm6.5-1.5a1 1 0 1 0-2 0v1.5a1 1 0 0 0 .293.707l1 1a1 1 0 0 0 1.414-1.414l-.707-.707V14Z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                        2 min
                                    </div>
    
                                </div>
                            </div>
    
    
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="flex-1">
                <h1 class="pl-8 xl:pl-6 text-xl font-bold text-black">
                    Last Comments
                </h1>

                <ul class="w-full flex flex-col justify-end items-end gap-y-2">
                    <?php $__currentLoopData = [0, 2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li
                            class="relative flex flex-row w-full xl:w-full 2xl:w-full border-2 flex-shrink-0 border-transparent cursor-pointer rounded-md hover:border-google-red/80 transition-all hover:shadow-black/50 hover:shadow-xl">
                            <div class="w-full">
                        
                                <h1 class="relative font-medium text-sm text-black px-6 py-2">
                                    En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                                    test équipes.
                                </h1>
    
                                <div class="flex flex-row justify-between items-center px-6 py-2 text-sm text-gray-500">
    
                                    <div class="flex flex-row items-center gap-x-2 text-google-red">
                                        <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                            viewBox="0 0 24 24">
                                            <path
                                                d="M8.597 3.2A1 1 0 0 0 7.04 4.289a3.49 3.49 0 0 1 .057 1.795 3.448 3.448 0 0 1-.84 1.575.999.999 0 0 0-.077.094c-.596.817-3.96 5.6-.941 10.762l.03.049a7.73 7.73 0 0 0 2.917 2.602 7.617 7.617 0 0 0 3.772.829 8.06 8.06 0 0 0 3.986-.975 8.185 8.185 0 0 0 3.04-2.864c1.301-2.2 1.184-4.556.588-6.441-.583-1.848-1.68-3.414-2.607-4.102a1 1 0 0 0-1.594.757c-.067 1.431-.363 2.551-.794 3.431-.222-2.407-1.127-4.196-2.224-5.524-1.147-1.39-2.564-2.3-3.323-2.788a8.487 8.487 0 0 1-.432-.287Z">
                                            </path>
                                        </svg>
    
                                        1024 lus
                                    </div>
    
                                </div>
                            </div>
    
    
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </section>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cellulegeek/Documents/akora-wordpress/storage/app/public/themes/default/show.blade.php ENDPATH**/ ?>