<script>
    function signIn() {
        gapi.auth2.getAuthInstance().signIn();
    }
</script>

<script type="text/javascript">
    $(document).ready(function() {

        $('#next').click(function(event) {
            event.preventDefault();
            $('#scroll-container').animate({
                scrollLeft: '+=150'
            }, 500);
        });


        $('#prev').click(function(event) {
            event.preventDefault();
            $('#scroll-container').animate({
                scrollLeft: '-=150'
            }, 500);
        });


    })
</script>

<script type="text/javascript">
    window.onload = function() {
        window.addEventListener("scroll", function(evt) {


            const header = document.getElementsByTagName('header')[0]
            const logo = document.getElementById('logo')
            if (window.scrollY > 70) {
                //header.classList.remove("bg-transparent")
                //header.classList.add("bg-white")
                header.classList.add("shadow-lg")
                //header.classList.add("text-slate-800")
                //header.classList.add("fixed")
                //header.style.backgroundColor = "white" 

                //logo.classList.remove("w-20")
                //logo.classList.add("w-10")

            } else {
                //header.classList.remove("bg-white")
                header.classList.remove("shadow-lg")
                //header.classList.remove("fixed")
                //header.classList.remove("text-slate-800")
                //header.style.backgroundColor = "rgba(0, 0, 0, 0.4)" 
                //header.classList.add("bg-transparent")

                //logo.classList.remove("w-20")
                //logo.classList.add("w-16")


            }
        })
    }
</script>

<script>
    // Mobile Menu Toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');

    mobileMenuButton.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });

    // Initialize Swiper
    const mainSwiper = new Swiper('.mainSwiper', {
        loop: true,
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });

    const testimonialSwiper = new Swiper('.testimonialSwiper', {
        slidesPerView: 1,
        spaceBetween: 30,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
            },
            1024: {
                slidesPerView: 3,
            },
        },
    });

    // Smooth Scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/flowbite@2.4.1/dist/flowbite.min.js"></script><?php /**PATH /Users/cellulegeek/Documents/akora-wordpress/storage/app/public/themes/default/scripts/footer.blade.php ENDPATH**/ ?>