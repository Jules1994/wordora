<?php $__env->startSection('page'); ?>
    <section
        class="relative w-full h-[65%] xl:h-[75%] bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

        <!--- Overlay --->
        <div
            class="absolute w-full h-full flex flex-col justify-center xl:justify-start items-center xl:items-start align-center top-62 px-0 xl:px-[20%] py-8 xl:py-[10%] left-0 gap-y-8 z-80 text-white bg-black/70">
            <h1 class="font-bold text-5xl xl:text-8xl">
                La propreté <br><em class="font-light text-5xl xl:text-6xl">est un</em> <span
                    class="text-google-green">pouvoir</span>
            </h1>
            <p class="text-md xl:text-lg text-white font-light text-left xl:pr-[25%] hidden xl:block">
                Gabon Nettoyage &amp; Multiservices est une entreprise de droit Gabonais qui offre des services
                professionnels aux entreprises et particuliers.<br>
                Engagée dans l'hygiène et l'assainissement, elle met en œuvre différentes compétences techniques au
                profit du bien-être de tous.
            </p>

            <div class="flex flex-row gap-x-4 mt-10 justify-start items-center">
                <div class="w-8 h-[2px] bg-[#ff1f1f]"></div>
                <h1 class="text-md xl:text-lg uppercase">NOUS SOMMES ECO-RESPONSABLE</h1>
            </div>
        </div>
    </section>

    <!--Nos offres-->
    <section
        class="w-full flex flex-col xs:gap-y-4 xl:flex-row justify-center items-center flex-wrap gap-x-10 px-4 xl:py-20 xl:px-20 2xl:px-72 pb-10">

        <div class="w-full text-center mt-4 xl:mt-0">

            <div class="w-full flex flex-col justify-center items-center">
                <h1 class="text-2xl xl:text-4xl text-black font-bold">
                    Notre offre
                </h1>
                <div class="w-full mt-4 flex flex-row justify-center items-center gap-x-2">
                    <div class="w-1/3 xl:w-1/6 h-1 bg-google-red rounded-full"></div>
                    <div class="w-4 h-1 bg-google-red rounded-full"></div>
                    <div class="w-4 h-1 bg-google-red rounded-full"></div>
                </div>
            </div>

            <p class="text-xl text-slate-700 xl:px-20 pt-10">
                Première entreprise experte en nettoyage éco responsable dédiée aux professionnels, Gabon Nettoyage
                est votre allié de confiance pour tous vos besoins en propreté.<br><br>
                Nous offrons une gamme complète de services sur mesure, conçus pour garantir un environnement sain,
                propre et respectueux de vos exigences.<br><br>
                Grâce à notre expertise et à notre savoir-faire, nous répondons avec précision à vos besoins les
                plus spécifiques, tout en respectant notre engagement envers l’écoresponsabilité.

            </p>

            <h1 class="text-2xl xl:text-4xl text-black font-bold mt-12">
                Découvrez nos catégories de services
            </h1>

        </div>

        <br><br>

        <div class="w-full flex flex-col xl:flex-row xl:flex-wrap justify-center items-center gap-4">

            <div
                class="group/item relative w-full xl:w-[24%] h-[35vh] xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2 justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5 bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">
                <div
                    class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                    <div class="w-full h-full flex flex-col justify-center items-center">
                        <h1 class="text-2xl font-bold">Nettoyage fin de bail</h1>
                        <br>
                        <p
                            class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                            Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                            vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                            authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                        </p>
                    </div>

                </div>
            </div>

            <div
                class="group/item relative w-full xl:w-[24%] h-[35vh]  xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2 justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                <div
                    class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                    <div class="w-full h-full flex flex-col justify-center items-center">
                        <h1 class="text-2xl font-bold">Nettoyage entrerien</h1>
                        <br>
                        <p
                            class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                            Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                            vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                            authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                        </p>
                    </div>

                </div>
            </div>

            <div
                class="group/item relative w-full xl:w-[24%] h-[35vh]  xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2  justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                <div
                    class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                    <div class="w-full h-full flex flex-col justify-center items-center">
                        <h1 class="text-2xl font-bold">Nettoyage ponctuel</h1>
                        <br>
                        <p
                            class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                            Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                            vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                            authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                        </p>
                    </div>

                </div>
            </div>

            <div
                class="group/item relative w-full xl:w-[24%] h-[35vh] xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2  justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                <div
                    class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                    <div class="w-full h-full flex flex-col justify-center items-center">
                        <h1 class="text-2xl font-bold">Remise en etat</h1>
                        <br>
                        <p
                            class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                            Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                            vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                            authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                        </p>
                    </div>

                </div>
            </div>

            <div
                class="group/item relative w-full xl:w-[24%] h-[35vh] xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2  justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                <div
                    class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                    <div class="w-full h-full flex flex-col justify-center items-center">
                        <h1 class="text-2xl font-bold">Desinfection locaux</h1>
                        <br>
                        <p
                            class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                            Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                            vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                            authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                        </p>
                    </div>

                </div>
            </div>

            <div
                class="group/item relative w-full xl:w-[24%] h-[35vh]  xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2 justify-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                <div
                    class="absolute top-0 left-0 p-4 w-full h-full bg-black/50 flex flex-col justify-center items-center hover:bg-black/80 gap-y-2">
                    <div class="w-full h-full flex flex-col justify-center items-center">
                        <h1 class="text-2xl font-bold">Entretien de parking</h1>
                        <p
                            class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                            Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                            vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                            authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                        </p>
                    </div>

                </div>
            </div>

        </div>
    </section>

    <!-- Nos services -->
    <section id="services" class="w-full flex flex-row justify-center items-center gap-x-10 py-[8%] bg-google-green/30">

        <div class="flex-1 text-left space-y-10 text-black/80 xl:px-[5%] 2xl:px-[10%]">

            <div class="w-full flex flex-col justify-center items-center">
                <h1 class="text-2xl xl:text-4xl text-black font-bold">
                    Pourquoi nous choisir ?
                </h1>
                <div class="w-full mt-4 flex flex-row justify-center items-center gap-x-2">
                    <div class="w-1/3 xl:w-1/6 h-1 bg-google-red rounded-full"></div>
                    <div class="w-4 h-1 bg-google-red rounded-full"></div>
                    <div class="w-4 h-1 bg-google-red rounded-full"></div>
                </div>
            </div>

            <p class="text-md text-center">
                Nous sommes à l’écoute de vos besoins et de vos exigences, pour vous fournir un service adapté et
                personnalisé. La propreté est notre métier et nos clients fidèles, issus des secteurs tertiaire,
                commercial ou industriel, le savent bien.
            </p>

            <div class="px-8 xl:px-0 w-full flex flex-col xl:flex-row justify-center flex-wrap gap-4">

                <div
                    class="group/item w-full xl:w-[24%] xl:h-[30vh] flex flex-col gap-y-2 justify-between p-8 bg-google-green/50 text-white font-light hover:bg-google-green/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5">
                    <h1 class="text-2xl">REACTIVITE</h1>
                    <p class="text-black">
                        Être proche de vous, c’est répondre au plus vite à vos demandes et aux imprévus.
                    </p>

                    <a href="./extmarche.html"
                        class="text-white flex flex-row gap-x-2 justify-start items-center group-hover/item:visible group-hover/item:ml-0 invisible -ml-5 transition-all duration-200">
                        <svg class="w-8 h-8" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                            height="24" fill="none" viewBox="0 0 24 24">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778">
                            </path>
                        </svg>
                        En savoir plus
                    </a>
                </div>

                <div
                    class="group/item w-full xl:w-[24%] xl:h-[30vh] flex flex-col gap-y-2 justify-between p-8 bg-google-green/50 text-white font-light hover:bg-google-green/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5">
                    <h1 class="text-2xl">RSE</h1>
                    <p class="text-black">
                        Les enjeux environnementaux et sociaux font partie intégrante de notre stratégie globale.
                    </p>

                    <a href="./amo.html"
                        class="text-white flex flex-row gap-x-2 justify-start items-center group-hover/item:visible group-hover/item:ml-0 invisible -ml-5 transition-all duration-200">
                        <svg class="w-8 h-8" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                            height="24" fill="none" viewBox="0 0 24 24">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778">
                            </path>
                        </svg>
                        En savoir plus
                    </a>
                </div>

                <div
                    class="group/item  w-full xl:w-[24%] xl:h-[30vh] flex flex-col gap-y-2 justify-between p-8 bg-google-green/50 text-white font-light hover:bg-google-green/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5">
                    <h1 class="text-2xl">INNOVATION</h1>
                    <p class="text-black">
                        Notre équipe s'engage à vous proposer des services toujours plus innovants.
                    </p>
                    <a href="./gescontract.html"
                        class="text-white flex flex-row  gap-x-2 justify-start items-center group-hover/item:visible group-hover/item:ml-0 invisible -ml-5 transition-all duration-200">
                        <svg class="w-8 h-8" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                            height="24" fill="none" viewBox="0 0 24 24">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778">
                            </path>
                        </svg>
                        En savoir plus
                    </a>
                </div>

            </div>
        </div>

    </section>


    <!---- Partner -->
    <section
        class="w-full flex flex-col justify-center items-center bg-[#f1f1f1] gap-y-4 px-8 xl:px-36 2xl:px-72 py-10 xl:py-20">


        <div class="w-full text-center mt-4 xl:mt-0">

            <div class="w-full flex flex-col justify-center items-center">
                <h1 class="text-2xl xl:text-4xl text-black font-bold">
                    Ceux qui nous font confiance
                </h1>
                <div class="w-full mt-4 flex flex-row justify-center items-center gap-x-2">
                    <div class="w-1/3 xl:w-1/6 h-1 bg-google-red rounded-full"></div>
                    <div class="w-4 h-1 bg-google-red rounded-full"></div>
                    <div class="w-4 h-1 bg-google-red rounded-full"></div>
                </div>
            </div>

            <p class="text-md text-slate-700 px-0 xl:px-20 pt-10">
                Nous sommes fiers de collaborer avec des entreprises et des partenaires de confiance qui partagent
                nos valeurs d’excellence, de respect de l’environnement et de préservation de la santé.<br>Notre
                clientèle variée inclut des grandes entreprises, des PME et des organisations
                gouvernementales.<br>
                À Gabon Nettoyage, chaque client est unique. Nous travaillons en étroite collaboration avec chacun
                pour comprendre leurs besoins spécifiques et proposer des solutions personnalisées, sans distinction
                entre nos plus grands et plus petits clients.<br> Tous bénéficient de la même qualité de service
                et
                d’une attention particulière.<br>
                En tant que leader en nettoyage éco responsable pour les professionnels, Gabon Nettoyage met à votre
                disposition une gamme complète de services sur mesure, conçus pour garantir un environnement
                impeccable et sain. Forte de son expertise et de son savoir-faire, notre équipe répond avec
                précision à vos exigences les plus pointues.
            </p>

            <h1 class="text-2xl xl:text-4xl text-black font-bold mt-12">
                Découvrez nos catégories de services
            </h1>

        </div>

        <br>

        <div class="w-full flex flex-row flex-wrap xl:flex-nowrap justify-center items-center gap-x-6 xl:mt-4">
            <img src="https://i0.wp.com/gabonnettoyage.ga/wp-content/uploads/2022/11/sogora-1.png?w=226&amp;ssl=1"
                class="w-1/2 xl:w-44 object-contain">
            <img src="https://i0.wp.com/gabonnettoyage.ga/wp-content/uploads/2022/11/comiloge.png?w=226&amp;ssl=1"
                class="w-1/2 xl:w-44 object-contain">
            <img src="https://i0.wp.com/gabonnettoyage.ga/wp-content/uploads/2022/11/cnss.png?w=226&amp;ssl=1"
                class="w-1/2 xl:w-44 object-contain">
            <img src="https://i0.wp.com/gabonnettoyage.ga/wp-content/uploads/2022/11/gendarmerie.png?w=226&amp;ssl=1"
                class="w-1/2 xl:w-44 object-contain">
            <img src="https://i0.wp.com/gabonnettoyage.ga/wp-content/uploads/2022/11/michel.png?w=226&amp;ssl=1"
                class="w-1/2 xl:w-44 object-contain">
            <img src="https://i0.wp.com/gabonnettoyage.ga/wp-content/uploads/2022/11/ministere.png?w=226&amp;ssl=1"
                class="w-1/2 xl:w-44 object-contain">
            <img src="https://i0.wp.com/gabonnettoyage.ga/wp-content/uploads/2022/11/minnin.png?w=226&amp;ssl=1"
                class="w-1/2 xl:w-44 object-contain">
        </div>

    </section>


    <!--- Articles --->
    <section
        class="w-full flex flex-col justify-start items-start bg-white flex-wrap gap-y-10 px-0 xl:px-8 2xl:px-72 py-10">

        <div class="w-full flex flex-col justify-center items-center">
            <h1 class="text-2xl xl:text-4xl text-black font-bold">
                Actualitées recentes
            </h1>
            <div class="w-full mt-4 flex flex-row justify-center items-center gap-x-2">
                <div class="w-1/3 xl:w-1/6 h-1 bg-google-red rounded-full"></div>
                <div class="w-4 h-1 bg-google-red rounded-full"></div>
                <div class="w-4 h-1 bg-google-red rounded-full"></div>
            </div>
        </div>

        <div id="categoriesSection"
            class="relative w-full flex flex-row text-black flex-wrap bg-white gap-2 px-2 2xl:px-0 top-0 left-0 border-b-0 transition-all border-slate-200">

            <ul id="scroll-container" class="w-full h-auto flex overflow-x-auto xl:overflow-x-hidden space-x-4">

                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-[#ff1f1f]/80 transition-all hover:shadow-black/50 hover:shadow-xl">


                    <div class="w-full flex rounded-b">
                        <img class="w-full h-44 object-cover rounded-t"
                            src="https://images.squarespace-cdn.com/content/v1/641075275eac4c06e68a4bf7/1694606194980-XV2AXQFIL6GOLU7BBUAH/AdobeStock_549476621+12.png"
                            alt="">
                    </div>

                    <p class="relative text-slate-500 px-6 py-4">
                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div
                        class="flex flex-row justify-between items-center px-6 py-4 border-t-2 border-slate-100 text-gray-500">

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-2 9a4 4 0 0 0-4 4v1a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1a4 4 0 0 0-4-4h-4Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            24
                        </div>

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M10 5a2 2 0 0 0-2 2v3h2.4A7.48 7.48 0 0 0 8 15.5a7.48 7.48 0 0 0 2.4 5.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1V7a4 4 0 1 1 8 0v1.15a7.446 7.446 0 0 0-1.943.685A.999.999 0 0 1 12 8.5V7a2 2 0 0 0-2-2Z"
                                    clip-rule="evenodd"></path>
                                <path fill-rule="evenodd"
                                    d="M10 15.5a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm6.5-1.5a1 1 0 1 0-2 0v1.5a1 1 0 0 0 .293.707l1 1a1 1 0 0 0 1.414-1.414l-.707-.707V14Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            2 min
                        </div>

                    </div>

                </li>

                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-[#ff1f1f]/80 transition-all hover:shadow-black/50 hover:shadow-xl">


                    <div class="w-full flex rounded-b">
                        <img class="w-full h-44 object-cover rounded-t"
                            src="https://images.squarespace-cdn.com/content/v1/641075275eac4c06e68a4bf7/1694606194980-XV2AXQFIL6GOLU7BBUAH/AdobeStock_549476621+12.png"
                            alt="">
                    </div>

                    <p class="relative text-slate-500 px-6 py-4">
                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div
                        class="flex flex-row justify-between items-center px-6 py-4 border-t-2 border-slate-100 text-gray-500">

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-2 9a4 4 0 0 0-4 4v1a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1a4 4 0 0 0-4-4h-4Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            24
                        </div>

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M10 5a2 2 0 0 0-2 2v3h2.4A7.48 7.48 0 0 0 8 15.5a7.48 7.48 0 0 0 2.4 5.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1V7a4 4 0 1 1 8 0v1.15a7.446 7.446 0 0 0-1.943.685A.999.999 0 0 1 12 8.5V7a2 2 0 0 0-2-2Z"
                                    clip-rule="evenodd"></path>
                                <path fill-rule="evenodd"
                                    d="M10 15.5a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm6.5-1.5a1 1 0 1 0-2 0v1.5a1 1 0 0 0 .293.707l1 1a1 1 0 0 0 1.414-1.414l-.707-.707V14Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            2 min
                        </div>

                    </div>

                </li>

                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-[#ff1f1f]/80 transition-all hover:shadow-black/50 hover:shadow-xl">


                    <div class="w-full flex rounded-b">
                        <img class="w-full h-44 object-cover rounded-t"
                            src="https://images.squarespace-cdn.com/content/v1/641075275eac4c06e68a4bf7/1694606194980-XV2AXQFIL6GOLU7BBUAH/AdobeStock_549476621+12.png"
                            alt="">
                    </div>

                    <p class="relative text-slate-500 px-6 py-4">
                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div
                        class="flex flex-row justify-between items-center px-6 py-4 border-t-2 border-slate-100 text-gray-500">

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-2 9a4 4 0 0 0-4 4v1a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1a4 4 0 0 0-4-4h-4Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            24
                        </div>

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M10 5a2 2 0 0 0-2 2v3h2.4A7.48 7.48 0 0 0 8 15.5a7.48 7.48 0 0 0 2.4 5.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1V7a4 4 0 1 1 8 0v1.15a7.446 7.446 0 0 0-1.943.685A.999.999 0 0 1 12 8.5V7a2 2 0 0 0-2-2Z"
                                    clip-rule="evenodd"></path>
                                <path fill-rule="evenodd"
                                    d="M10 15.5a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm6.5-1.5a1 1 0 1 0-2 0v1.5a1 1 0 0 0 .293.707l1 1a1 1 0 0 0 1.414-1.414l-.707-.707V14Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            2 min
                        </div>

                    </div>

                </li>

                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-[#ff1f1f]/80 transition-all hover:shadow-black/50 hover:shadow-xl">


                    <div class="w-full flex rounded-b">
                        <img class="w-full h-44 object-cover rounded-t"
                            src="https://images.squarespace-cdn.com/content/v1/641075275eac4c06e68a4bf7/1694606194980-XV2AXQFIL6GOLU7BBUAH/AdobeStock_549476621+12.png"
                            alt="">
                    </div>

                    <p class="relative text-slate-500 px-6 py-4">
                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div
                        class="flex flex-row justify-between items-center px-6 py-4 border-t-2 border-slate-100 text-gray-500">

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-2 9a4 4 0 0 0-4 4v1a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1a4 4 0 0 0-4-4h-4Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            24
                        </div>

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M10 5a2 2 0 0 0-2 2v3h2.4A7.48 7.48 0 0 0 8 15.5a7.48 7.48 0 0 0 2.4 5.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1V7a4 4 0 1 1 8 0v1.15a7.446 7.446 0 0 0-1.943.685A.999.999 0 0 1 12 8.5V7a2 2 0 0 0-2-2Z"
                                    clip-rule="evenodd"></path>
                                <path fill-rule="evenodd"
                                    d="M10 15.5a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm6.5-1.5a1 1 0 1 0-2 0v1.5a1 1 0 0 0 .293.707l1 1a1 1 0 0 0 1.414-1.414l-.707-.707V14Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            2 min
                        </div>

                    </div>

                </li>

                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-[#ff1f1f]/80 transition-all hover:shadow-black/50 hover:shadow-xl">


                    <div class="w-full flex rounded-b">
                        <img class="w-full h-44 object-cover rounded-t"
                            src="https://images.squarespace-cdn.com/content/v1/641075275eac4c06e68a4bf7/1694606194980-XV2AXQFIL6GOLU7BBUAH/AdobeStock_549476621+12.png"
                            alt="">
                    </div>

                    <p class="relative text-slate-500 px-6 py-4">
                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div
                        class="flex flex-row justify-between items-center px-6 py-4 border-t-2 border-slate-100 text-gray-500">

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-2 9a4 4 0 0 0-4 4v1a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1a4 4 0 0 0-4-4h-4Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            24
                        </div>

                        <div class="flex flex-row gap-x-2">
                            <svg class="w-6 h-6 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M10 5a2 2 0 0 0-2 2v3h2.4A7.48 7.48 0 0 0 8 15.5a7.48 7.48 0 0 0 2.4 5.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1V7a4 4 0 1 1 8 0v1.15a7.446 7.446 0 0 0-1.943.685A.999.999 0 0 1 12 8.5V7a2 2 0 0 0-2-2Z"
                                    clip-rule="evenodd"></path>
                                <path fill-rule="evenodd"
                                    d="M10 15.5a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm6.5-1.5a1 1 0 1 0-2 0v1.5a1 1 0 0 0 .293.707l1 1a1 1 0 0 0 1.414-1.414l-.707-.707V14Z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            2 min
                        </div>

                    </div>

                </li>

            </ul>


            <a href="#/" id="prev"
                class="p-2 xl:p-3 absolute rounded-full bg-sky-700 top-[35%] left-2 xl:left-[0%] z-[1000px] hover:shadow-xl transition-all duration-200 border-2 border-white">
                <svg class="w-6 h-6 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                    height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="m15 19-7-7 7-7"></path>
                </svg>

            </a>

            <a href="#/" id="next"
                class="p-2 xl:p-3 bg-sky-700 absolute rounded-full top-[35%] right-2 xl:-right-[2%] z-[1000px] hover:shadow-xl transition-all duration-200 border-2 border-white">

                <svg class="w-6 h-6 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                    height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="m9 5 7 7-7 7"></path>
                </svg>

            </a>

        </div>
    </section>

    <!-- Témoignages -->
    <section
        class="w-full flex flex-col justify-start items-start bg-white flex-wrap gap-x-10 px-0 xl:px-8 2xl:px-72 py-10">

        <br>

        <div class="w-full flex flex-col justify-center items-center">
            <h1 class="text-2xl xl:text-4xl text-black font-bold">
                Nos temoignages
            </h1>
            <div class="w-full mt-4 flex flex-row justify-center items-center gap-x-2">
                <div class="w-1/3 xl:w-1/6 h-1 bg-google-red rounded-full"></div>
                <div class="w-4 h-1 bg-google-red rounded-full"></div>
                <div class="w-4 h-1 bg-google-red rounded-full"></div>
            </div>
        </div>
        <br>
        <div id="categoriesSection"
            class="relative w-full flex flex-row text-black flex-wrap bg-white gap-2 px-2 2xl:px-0 top-0 left-0 border-b-0 transition-all border-slate-200">

            <ul id="scroll-container" class="w-full h-auto flex overflow-x-auto xl:overflow-x-hidden space-x-4">
                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-sky-700 transition-all hover:shadow-xl">

                    <p class="relative text-slate-500 px-6 py-4">
                        <span class="float-left text-sky-700 pr-2">
                            <svg class="w-10 h-10" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                                height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M10 11V8a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4H5m14-6V8a1 1 0 0 0-1-1h-3a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4h-1">
                                </path>
                            </svg>
                        </span>

                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div class="flex border-t-2 border-slate-100 px-6 py-4 bg-sky-700 rounded-b">
                        <img class="h-10 w-10 rounded-full"
                            src="https://jobs.samsic.com/generated_contents/images/recruiter_avatar/9dLyQE29-thierry-geffroy.jpg"
                            alt="">
                        <div class="ml-3 overflow-hidden">
                            <p class="text-md font-semibold text-white">Jacobe OBELE</p>
                            <p class="xl:text-sm text-[#f1f1f1] truncate">Président du Gabon Nettoyage </p>
                        </div>
                    </div>

                </li>
                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-sky-700 transition-all hover:shadow-xl">

                    <p class="relative text-slate-500 px-6 py-4">
                        <span class="float-left text-sky-700 pr-2">
                            <svg class="w-10 h-10" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                                height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M10 11V8a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4H5m14-6V8a1 1 0 0 0-1-1h-3a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4h-1">
                                </path>
                            </svg>
                        </span>

                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div class="flex border-t-2 border-slate-100 px-6 py-4 bg-sky-700 rounded-b">
                        <img class="h-10 w-10 rounded-full"
                            src="https://jobs.samsic.com/generated_contents/images/recruiter_avatar/9dLyQE29-thierry-geffroy.jpg"
                            alt="">
                        <div class="ml-3 overflow-hidden">
                            <p class="text-md font-semibold text-white">Jacobe OBELE</p>
                            <p class="xl:text-sm text-[#f1f1f1] truncate">Président du Gabon Nettoyage </p>
                        </div>
                    </div>

                </li>
                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-sky-700 transition-all hover:shadow-xl">

                    <p class="relative text-slate-500 px-6 py-4">
                        <span class="float-left text-sky-700 pr-2">
                            <svg class="w-10 h-10" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                                height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M10 11V8a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4H5m14-6V8a1 1 0 0 0-1-1h-3a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4h-1">
                                </path>
                            </svg>
                        </span>

                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div class="flex border-t-2 border-slate-100 px-6 py-4 bg-sky-700 rounded-b">
                        <img class="h-10 w-10 rounded-full"
                            src="https://jobs.samsic.com/generated_contents/images/recruiter_avatar/9dLyQE29-thierry-geffroy.jpg"
                            alt="">
                        <div class="ml-3 overflow-hidden">
                            <p class="text-md font-semibold text-white">Jacobe OBELE</p>
                            <p class="xl:text-sm text-[#f1f1f1] truncate">Président du Gabon Nettoyage </p>
                        </div>
                    </div>

                </li>
                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-sky-700 transition-all hover:shadow-xl">

                    <p class="relative text-slate-500 px-6 py-4">
                        <span class="float-left text-sky-700 pr-2">
                            <svg class="w-10 h-10" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                                height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M10 11V8a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4H5m14-6V8a1 1 0 0 0-1-1h-3a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4h-1">
                                </path>
                            </svg>
                        </span>

                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div class="flex border-t-2 border-slate-100 px-6 py-4 bg-sky-700 rounded-b">
                        <img class="h-10 w-10 rounded-full"
                            src="https://jobs.samsic.com/generated_contents/images/recruiter_avatar/9dLyQE29-thierry-geffroy.jpg"
                            alt="">
                        <div class="ml-3 overflow-hidden">
                            <p class="text-md font-semibold text-white">Jacobe OBELE</p>
                            <p class="xl:text-sm text-[#f1f1f1] truncate">Président du Gabon Nettoyage </p>
                        </div>
                    </div>

                </li>
                <li
                    class="relative w-72 xl:w-80 2xl:w-72 border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-sky-700 transition-all hover:shadow-xl">

                    <p class="relative text-slate-500 px-6 py-4">
                        <span class="float-left text-sky-700 pr-2">
                            <svg class="w-10 h-10" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                                height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M10 11V8a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4H5m14-6V8a1 1 0 0 0-1-1h-3a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1Zm0 0v2a4 4 0 0 1-4 4h-1">
                                </path>
                            </svg>
                        </span>

                        En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                        test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                    </p>

                    <div class="flex border-t-2 border-slate-100 px-6 py-4 bg-sky-700 rounded-b">
                        <img class="h-10 w-10 rounded-full"
                            src="https://jobs.samsic.com/generated_contents/images/recruiter_avatar/9dLyQE29-thierry-geffroy.jpg"
                            alt="">
                        <div class="ml-3 overflow-hidden">
                            <p class="text-md font-semibold text-white">Jacobe OBELE</p>
                            <p class="xl:text-sm text-[#f1f1f1] truncate">Président du Gabon Nettoyage </p>
                        </div>
                    </div>

                </li>
            </ul>


            <a href="#/" id="prev"
                class="p-2 xl:p-3 absolute rounded-full bg-sky-700 top-[35%] left-2 xl:left-[0%] z-[1000px] hover:shadow-xl transition-all duration-200 border-2 border-white">
                <svg class="w-6 h-6 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                    height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="m15 19-7-7 7-7"></path>
                </svg>

            </a>

            <a href="#/" id="next"
                class="p-2 xl:p-3 bg-sky-700 absolute rounded-full top-[35%] right-2 xl:-right-[2%] z-[1000px] hover:shadow-xl transition-all duration-200 border-2 border-white">

                <svg class="w-6 h-6 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                    height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="m9 5 7 7-7 7"></path>
                </svg>

            </a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('clean::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cellulegeek/Documents/akora-wordpress/storage/app/public/themes/clean/index.blade.php ENDPATH**/ ?>