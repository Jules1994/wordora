<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php if(isset($page)): ?>
        <title><?php echo e($page->title); ?></title>
    <?php endif; ?>
    <?php echo $__env->make('web.scripts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="font-sans antialiased bg-white">

    <?php echo $__env->make('web.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(isset($page)): ?>
        <?php echo $__env->make('web.components.head_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->yieldContent('page'); ?>
    <?php endif; ?>

    <?php echo $__env->make('web.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('web.scripts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /Users/cellulegeek/Documents/akora-wordpress/resources/views/web/layout.blade.php ENDPATH**/ ?>