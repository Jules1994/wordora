<footer class="bg-google-white text-black pt-16 pb-8 border-t-4 border-google-green">

    <div class="w-full px-4">

        <div class="w-full flex flex-col gap-y-4 xl:flex-row xl:gap-y-0 justify-around">
            <!-- Company Info -->
            <div>
                <h3 class="text-xl font-bold mb-4">Gabon Nettoyage</h3>
                <p class="text-gray-400 mb-4">
                    Leader dans le secteur du nettoyage écologique professionnel au Gabon.
                </p>
                <div class="flex space-x-4">
                    <a href="#" class="text-gray-400 hover:text-white transition-colors">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition-colors">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition-colors">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition-colors">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>

            <!-- Quick Links -->
            <div>
                <h3 class="text-xl font-bold mb-4">Liens Rapides</h3>
                <ul class="space-y-2">
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Accueil</a>
                    </li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Nos Agences</a>
                    </li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Nos
                            Services</a></li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Nos
                            Engagements</a>
                    </li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Carrière</a>
                    </li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">À Propos</a>
                    </li>
                </ul>
            </div>

            <!-- Services -->
            <div>
                <h3 class="text-xl font-bold mb-4">Nos Services</h3>
                <ul class="space-y-2">
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Nettoyage
                            Régulier</a>
                    </li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Nettoyage
                            Industriel</a></li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Nettoyage
                            Spécifique</a></li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Remise en
                            État</a></li>
                    <li><a href="#"
                            class="text-gray-400 hover:text-white transition-colors">Multiservice</a></li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Desinfection de
                            vos
                            locaux</a></li>
                    <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Nettoyage
                            entrerien</a>
                    </li>
                    <li><a href="#"
                            class="text-gray-400 hover:text-white transition-colors">Particuliers</a></li>
                </ul>
            </div>

            <!-- Contact -->
            <div>
                <h3 class="text-xl font-bold mb-4">Contact</h3>
                <ul class="space-y-2">
                    <li class="flex items-center text-gray-400">
                        <i class="fas fa-map-marker-alt mr-2"></i>
                        Libreville, Gabon
                    </li>
                    <li class="flex items-center text-gray-400">
                        <i class="fas fa-phone mr-2"></i>
                        +241 XX XX XX XX
                    </li>
                    <li class="flex items-center text-gray-400">
                        <i class="fas fa-envelope mr-2"></i>
                        contact@gabonnettoyage.com
                    </li>
                </ul>
            </div>
        </div>

        <!-- Copyright -->
        <div class="w-full border-t border-google-green mt-12 pt-8 text-center text-gray-400">
            <p>Designed and developed by AKORA © 2024 Gabon Nettoyage et Multiservices. Tous droits réservés.
            </p>
        </div>
    </div>

</footer><?php /**PATH /Users/cellulegeek/Documents/akora-wordpress/resources/views/web/components/footer.blade.php ENDPATH**/ ?>