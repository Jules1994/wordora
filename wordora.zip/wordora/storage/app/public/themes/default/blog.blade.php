@extends('default::layout')

@section('page')
    <div class="w-full flex flex-row gap-x-10 justify-start items-start bg-white xl:px-[16%]">

        <!--- Articles --->
        <section
            class="w-[70%] flex flex-col justify-start items-start flex-wrap gap-y-10 py-10">

            <div class="flex-1">
                <h1 class="pl-4 xl:pl-0 text-4xl font-bold text-black">
                    Nos articles
                </h1>
            </div>

            <div
                class="relative w-full flex flex-row text-black flex-wrap bg-white gap-2 px-2 2xl:px-0 top-0 left-0 border-b-0 transition-all border-slate-200">

                <ul class="w-full h-auto flex flex-wrap gap-4">

                    @foreach ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0] as $post)
                        <li
                            class="relative w-full xl:w-[32%] 2xl:w-[32%] border-2 flex-shrink-0 border-slate-100 rounded-md hover:border-google-red/80 transition-all hover:shadow-black/50 hover:shadow-xl">


                            <div class="w-full flex rounded-b">
                                <img class="w-full h-44 object-cover rounded-t"
                                    src="https://images.squarespace-cdn.com/content/v1/641075275eac4c06e68a4bf7/1694606194980-XV2AXQFIL6GOLU7BBUAH/AdobeStock_549476621+12.png"
                                    alt="">
                            </div>

                            <h1 class="relative font-bold text-slate-500 px-6 py-4">
                                En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le
                                modèle de
                                test équipes. Si elles ne se voient pas en toi, tu n'avances pas.
                            </h1>

                            <div
                                class="flex flex-row justify-between items-center px-6 py-4 border-t-2 border-slate-100 text-gray-500">

                                <div class="flex flex-row gap-x-2">
                                    <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                        xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                        viewBox="0 0 24 24">
                                        <path fill-rule="evenodd"
                                            d="M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-2 9a4 4 0 0 0-4 4v1a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1a4 4 0 0 0-4-4h-4Z"
                                            clip-rule="evenodd"></path>
                                    </svg>
                                    24
                                </div>

                                <div class="flex flex-row gap-x-2">
                                    <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                        xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                        viewBox="0 0 24 24">
                                        <path fill-rule="evenodd"
                                            d="M10 5a2 2 0 0 0-2 2v3h2.4A7.48 7.48 0 0 0 8 15.5a7.48 7.48 0 0 0 2.4 5.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1V7a4 4 0 1 1 8 0v1.15a7.446 7.446 0 0 0-1.943.685A.999.999 0 0 1 12 8.5V7a2 2 0 0 0-2-2Z"
                                            clip-rule="evenodd"></path>
                                        <path fill-rule="evenodd"
                                            d="M10 15.5a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm6.5-1.5a1 1 0 1 0-2 0v1.5a1 1 0 0 0 .293.707l1 1a1 1 0 0 0 1.414-1.414l-.707-.707V14Z"
                                            clip-rule="evenodd"></path>
                                    </svg>
                                    2 min
                                </div>

                            </div>

                        </li>
                    @endforeach

                </ul>
            </div>

            <div>
                <div class="flex flex-row gap-x-10 justify-center items-center">
                    <!-- Buttons -->
                    <div class="inline-flex mt-2 xs:mt-0">
                        <button
                            class="flex items-center justify-center px-4 h-10 text-base font-medium text-white bg-gray-800 rounded-s hover:bg-gray-900 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                            Prev
                        </button>
                        <button
                            class="flex items-center justify-center px-4 h-10 text-base font-medium text-white bg-gray-800 border-0 border-s border-gray-700 rounded-e hover:bg-gray-900 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                            Next
                        </button>
                    </div>

                    <!-- Help text -->
                    <span class="text-sm text-gray-700 dark:text-gray-400">
                        Showing <span class="font-semibold text-gray-900 dark:text-white">1</span> to <span
                            class="font-semibold text-gray-900 dark:text-white">10</span> of <span
                            class="font-semibold text-gray-900 dark:text-white">100</span> Entries
                    </span>
                </div>

            </div>

        </section>


        <!--- Last articles --->
        <section id="id" class="sticky top-4 w-[30%] flex flex-col justify-end items-end space-y-10 py-10 px-0">

            <div class="flex-1">
                <h1 class="pl-4 xl:pl-0 text-4xl font-bold text-black">
                    Recherche
                </h1>
            </div>

            <div class="w-full">
                <form class="flex-1 text-black flex flex-col justify-start gap-y-4">
                    <div class="w-full relative">
                        <input type="email" name="email" placeholder="Saississez votre email"
                            class="p-4 rounded-full w-full border-slate-300">
                        <button class="p-4 rounded-full absolute right-[0%] top-[1%] text-white bg-google-red/80">
                            <svg class="w-6 h-6 text-white-800 dark:text-white" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                                viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-width="2"
                                    d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"></path>
                            </svg>
                        </button>
                    </div>
                </form>
            </div>

            <div class="flex-1">
                <h1 class="pl-4 xl:pl-6 text-xl font-bold text-black">
                    Last posts
                </h1>
                <ul class="w-full flex flex-col justify-end items-end gap-y-2">
                    @foreach ([0, 2, 3] as $post)
                        <li
                            class="relative flex flex-row w-full xl:w-full 2xl:w-full border-2 flex-shrink-0 border-transparent cursor-pointer rounded-md hover:border-google-red/80 transition-all hover:shadow-black/50 hover:shadow-xl">
                            <div class="w-full">
                                <img src="https://images.squarespace-cdn.com/content/v1/641075275eac4c06e68a4bf7/1694606194980-XV2AXQFIL6GOLU7BBUAH/AdobeStock_549476621+12.png"
                                    class="w-16 h-16 object-cover border-4 border-white float-right">
                                <h1 class="relative font-medium text-sm text-black px-6 py-2">
                                    En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                                    test équipes.
                                </h1>
    
                                <div class="flex flex-row justify-between items-center px-6 py-2 text-sm text-gray-500">
    
                                    <div class="flex flex-row items-center gap-x-2 text-google-red">
                                        <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                            viewBox="0 0 24 24">
                                            <path
                                                d="M8.597 3.2A1 1 0 0 0 7.04 4.289a3.49 3.49 0 0 1 .057 1.795 3.448 3.448 0 0 1-.84 1.575.999.999 0 0 0-.077.094c-.596.817-3.96 5.6-.941 10.762l.03.049a7.73 7.73 0 0 0 2.917 2.602 7.617 7.617 0 0 0 3.772.829 8.06 8.06 0 0 0 3.986-.975 8.185 8.185 0 0 0 3.04-2.864c1.301-2.2 1.184-4.556.588-6.441-.583-1.848-1.68-3.414-2.607-4.102a1 1 0 0 0-1.594.757c-.067 1.431-.363 2.551-.794 3.431-.222-2.407-1.127-4.196-2.224-5.524-1.147-1.39-2.564-2.3-3.323-2.788a8.487 8.487 0 0 1-.432-.287Z">
                                            </path>
                                        </svg>
    
                                        1024 lus
                                    </div>
    
                                    <div class="flex flex-row items-center gap-x-2">
                                        <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                            viewBox="0 0 24 24">
                                            <path fill-rule="evenodd"
                                                d="M10 5a2 2 0 0 0-2 2v3h2.4A7.48 7.48 0 0 0 8 15.5a7.48 7.48 0 0 0 2.4 5.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1V7a4 4 0 1 1 8 0v1.15a7.446 7.446 0 0 0-1.943.685A.999.999 0 0 1 12 8.5V7a2 2 0 0 0-2-2Z"
                                                clip-rule="evenodd"></path>
                                            <path fill-rule="evenodd"
                                                d="M10 15.5a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm6.5-1.5a1 1 0 1 0-2 0v1.5a1 1 0 0 0 .293.707l1 1a1 1 0 0 0 1.414-1.414l-.707-.707V14Z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                        2 min
                                    </div>
    
                                </div>
                            </div>
    
    
                        </li>
                    @endforeach
                </ul>
            </div>

            <div class="flex-1">
                <h1 class="pl-8 xl:pl-6 text-xl font-bold text-black">
                    Last Comments
                </h1>

                <ul class="w-full flex flex-col justify-end items-end gap-y-2">
                    @foreach ([0, 2, 3] as $post)
                        <li
                            class="relative flex flex-row w-full xl:w-full 2xl:w-full border-2 flex-shrink-0 border-transparent cursor-pointer rounded-md hover:border-google-red/80 transition-all hover:shadow-black/50 hover:shadow-xl">
                            <div class="w-full">
                        
                                <h1 class="relative font-medium text-sm text-black px-6 py-2">
                                    En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le modèle de
                                    test équipes.
                                </h1>
    
                                <div class="flex flex-row justify-between items-center px-6 py-2 text-sm text-gray-500">
    
                                    <div class="flex flex-row items-center gap-x-2 text-google-red">
                                        <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                            viewBox="0 0 24 24">
                                            <path
                                                d="M8.597 3.2A1 1 0 0 0 7.04 4.289a3.49 3.49 0 0 1 .057 1.795 3.448 3.448 0 0 1-.84 1.575.999.999 0 0 0-.077.094c-.596.817-3.96 5.6-.941 10.762l.03.049a7.73 7.73 0 0 0 2.917 2.602 7.617 7.617 0 0 0 3.772.829 8.06 8.06 0 0 0 3.986-.975 8.185 8.185 0 0 0 3.04-2.864c1.301-2.2 1.184-4.556.588-6.441-.583-1.848-1.68-3.414-2.607-4.102a1 1 0 0 0-1.594.757c-.067 1.431-.363 2.551-.794 3.431-.222-2.407-1.127-4.196-2.224-5.524-1.147-1.39-2.564-2.3-3.323-2.788a8.487 8.487 0 0 1-.432-.287Z">
                                            </path>
                                        </svg>
    
                                        1024 lus
                                    </div>
    
                                </div>
                            </div>
    
    
                        </li>
                    @endforeach
                </ul>
            </div>

        </section>

    </div>
@endsection
