<nav class="sticky shadow-lg w-full z-50 bg-white border-b-4 border-blue-500">
    <div class="max-w-7xl mx-auto px-4">
        <div class="flex justify-between items-center h-20">
            <!-- Logo -->
            <div class="flex-shrink-0">
                <a href="#">
                    <!-- <img src="https://gabonnettoyage.com/logo.jpg" alt="Logo" class="h-12 w-auto"> -->
                    <a href="/" class="flex flex-col">
                        <label class="text-md xl:text-xl font-bold text-google-yellow cursor-pointer">WORD AKORA</label>
                        <label class="text-xs text-gray-600 cursor-pointer">&amp; Technologies & AI</label>
                    </a>
                </a>
            </div>

            <!-- Desktop Menu -->
            <div class="hidden md:flex space-x-8">

                @foreach ($menu['items'] as $item)
                    <a href="{{ $item['link'] }}" class="text-gray-700 hover:text-google-red transition-colors">
                        {{ $item['name'] }}
                    </a>
                @endforeach
                <a href="#" class="text-gray-700 hover:text-google-red transition-colors">
                    <svg class="w-6 h-6 text-gray-700" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0 0a8.949 8.949 0 0 0 4.951-1.488A3.987 3.987 0 0 0 13 16h-2a3.987 3.987 0 0 0-3.951 3.512A8.948 8.948 0 0 0 12 21Zm3-11a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z">
                        </path>
                    </svg>
                </a>
                <a href="#" class="text-gray-700 hover:text-google-red transition-colors">
                    <svg class="w-6 h-6 text-g dark:text-gray-700" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m13 19 3.5-9 3.5 9m-6.125-2h5.25M3 7h7m0 0h2m-2 0c0 1.63-.793 3.926-2.239 5.655M7.5 6.818V5m.261 7.655C6.79 13.82 5.521 14.725 4 15m3.761-2.345L5 10m2.761 2.655L10.2 15">
                        </path>
                    </svg>
                </a>
            </div>

            <!-- Mobile Menu Button -->
            <div class="md:hidden flex flex-row gap-x-4 justify-center">
                <svg class="w-7 h-7 text-google-red" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                    width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0 0a8.949 8.949 0 0 0 4.951-1.488A3.987 3.987 0 0 0 13 16h-2a3.987 3.987 0 0 0-3.951 3.512A8.948 8.948 0 0 0 12 21Zm3-11a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z">
                    </path>
                </svg>
                <svg class="w-7 h-7 text-google-red" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                    width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="m13 19 3.5-9 3.5 9m-6.125-2h5.25M3 7h7m0 0h2m-2 0c0 1.63-.793 3.926-2.239 5.655M7.5 6.818V5m.261 7.655C6.79 13.82 5.521 14.725 4 15m3.761-2.345L5 10m2.761 2.655L10.2 15">
                    </path>
                </svg>

                <button id="mobile-menu-button" class="text-google-red hover:text-google-blue focus:outline-none">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden pb-4">
            <div class="flex flex-col space-y-4">
                <a href="#" class="text-gray-700 hover:text-google-blue transition-colors">Accueil</a>
                <a href="#" class="text-gray-700 hover:text-google-blue transition-colors">Nos Agences</a>
                <a href="#" class="text-gray-700 hover:text-google-blue transition-colors">Nos Services</a>
                <a href="#" class="text-gray-700 hover:text-google-blue transition-colors">Nos
                    Engagements</a>
                <a href="#" class="text-gray-700 hover:text-google-blue transition-colors">Carrière</a>
            </div>
        </div>
    </div>
</nav>
