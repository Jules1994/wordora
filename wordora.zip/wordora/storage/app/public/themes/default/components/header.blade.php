@include('default::components.nav')
<!--<header
    class="w-full sticky font-medium text-slate-600 flex flex-row sm:justify-center sm:items-center xl:flex-row top-0 left-0 z-10 xl:px-4 border-b-0 border-slate-100 bg transition-all bg-blue-500 shadow-lg"
    style=" z-index: 99999999999999999999999999999999999;">

    
    <div
        class="w-full hidden xl:w-full px-4 xl:px-0 xl:flex flex-row justify-end 2xl:justify-center 2xl:pl-0 items-center">

        <ul class="w-full flex flex-row text-white justify-end 2xl:justify-center items-center gap-x-6">


            <li class="group/mega-menu hover:text-[#e1db2b] py-0 xl:py-2">
                <a href="/" class="flex flex-row gap-x-2 justify-center items-center py-2">
                    Accueil
                </a>
            </li>

            <li class="hover:text-[#e1db2b] py-0 xl:py-2">

                <a href="https://gabonnettoyage.com/agences#"
                    class="flex flex-row gap-x-2 justify-center items-center py-2">
                    Particuliers
                </a>
            </li>

            <li class="group/mega-menu hover:text-[#e1db2b] py-0 xl:py-2">
                <a href="https://gabonnettoyage.com/services#"
                    class="flex flex-row gap-x-2 justify-center items-center py-2">
                    Nettoyage entrerien
                </a>

            </li>

            <li class="group/mega-menu hover:text-[#e1db2b] relative py-0 xl:py-2">

                <a href="https://gabonnettoyage.com/engagements#"
                    class="flex flex-row gap-x-2 justify-center items-center py-2">
                    Nettoyage ponctuel
                </a>
            </li>

            <li class="hover:text-[#e1db2b] py-0 xl:py-2">

                <a href="https://gabonnettoyage.com/carriere#"
                    class="flex flex-row gap-x-2 justify-center items-center py-2">
                    Multiservice
                </a>
            </li>


            <li class="hover:text-[#e1db2b] py-0 xl:py-2">

                <a href="https://gabonnettoyage.com/about#"
                    class="flex flex-row gap-x-2 justify-center items-center py-2">
                    Remise en etat
                </a>

            </li>

            <li class="hover:text-[#e1db2b] py-0 xl:py-2">

                <a href="https://gabonnettoyage.com/about#"
                    class="flex flex-row gap-x-2 justify-center items-center py-2">
                    Desinfection de vos locaux
                </a>
            </li>

            <li class="hover:text-[#e1db2b] py-0 xl:py-2">

                <a href="https://gabonnettoyage.com/about#"
                    class="flex flex-row gap-x-2 justify-center items-center py-2">
                    Desinfection de vos locaux
                </a>
            </li>

        </ul>

    </div>

</header>-->
