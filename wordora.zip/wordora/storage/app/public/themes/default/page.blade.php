@extends('default::layout')

@section('page')

@endsection