@extends('default::layout')

@section('page')
    <div class="w-full flex flex-row gap-x-10 justify-start items-start bg-white xl:px-[16%]">

        <!--- Articles --->
        <section class="w-[70%] flex flex-col justify-start items-start flex-wrap gap-y-10 py-10">

            <div class="relative w-full bg-cover rounded">
                <img class="w-full xl:h-80 object-cover object-center rounded"
                    src="https://www.ece.fr/wp-content/uploads/sites/2/2024/04/ai-technology-brain-background-digital-transformation-concept.jpg?w=1480&h=800&crop=1" />
                <!--- Overlay --->
                <div
                    class="absolute w-full h-full flex flex-col justify-center xl:justify-start items-center xl:items-start align-center rounded top-0 px-0 xl:px-[5%] py-8 xl:py-[5%] left-0 gap-y-8 z-80 text-white bg-black/70">
                    <h1 class="font-bold text-2xl xl:text-5xl">
                        La technologie <br><em class="font-light text-2xl xl:text-3xl">est un le futur</em> <span
                            class="text-google-red">pouvoir</span>
                    </h1>
                    <p class="text-md xl:text-lg text-white font-light text-left xl:pr-[5%] hidden xl:block">
                        Akora technologie &amp; est une entreprise technologique de droit Gabonais qui offre des services
                        professionnels aux entreprises et particuliers.

                    <div class="flex flex-row gap-x-4 justify-start items-center">
                        <div class="w-8 h-[2px] bg-[#ff1f1f]"></div>
                        <h1 class="text-md xl:text-lg capitalize">nous croyon en l'avenir</h1>
                    </div>
                </div>
            </div>



            <div
                class="w-full flex flex-col xs:gap-y-4 xl:flex-row justify-center items-center flex-wrap gap-x-10 px-4">

                <div class="w-full text-center mt-4 xl:mt-0">

                    <div class="w-full flex flex-col justify-center items-center">
                        <h1 class="text-2xl xl:text-2xl text-black font-bold">
                           Qui somme nous ?
                        </h1>
                    </div>

                    <p class="text-xl text-slate-700 pt-10">
                        L'une des entreprise pionière et experte en developpement technologique et de solution logiciel et application dédiée aux professionnels, AKORA
                        est votre allié de confiance pour tous vos technologique et informatique.
                    </p>

                    <h1 class="text-2xl xl:text-2xl text-black font-bold mt-12">
                        Découvrez nos catégories de services
                    </h1>

                </div>

                <br><br>

                <div class="w-full flex flex-col xl:flex-row xl:flex-wrap justify-center items-center gap-4">

                    <div
                        class="group/item relative w-full xl:w-[49%] h-[35vh] xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2 justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5 bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">
                        <div
                            class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                            <div class="w-full h-full flex flex-col justify-center items-center">
                                <h1 class="text-2xl font-bold">Nettoyage fin de bail</h1>
                                <br>
                                <p
                                    class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                                    Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                                    vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                                    authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                                </p>
                            </div>

                        </div>
                    </div>

                    <div
                        class="group/item relative w-full xl:w-[49%] h-[35vh]  xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2 justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                        <div
                            class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                            <div class="w-full h-full flex flex-col justify-center items-center">
                                <h1 class="text-2xl font-bold">Nettoyage entrerien</h1>
                                <br>
                                <p
                                    class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                                    Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                                    vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                                    authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                                </p>
                            </div>

                        </div>
                    </div>

                    <div
                        class="group/item relative w-full xl:w-[49%] h-[35vh]  xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2  justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                        <div
                            class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                            <div class="w-full h-full flex flex-col justify-center items-center">
                                <h1 class="text-2xl font-bold">Nettoyage ponctuel</h1>
                                <br>
                                <p
                                    class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                                    Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                                    vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                                    authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                                </p>
                            </div>

                        </div>
                    </div>

                    <div
                        class="group/item relative w-full xl:w-[49%] h-[35vh] xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2  justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                        <div
                            class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                            <div class="w-full h-full flex flex-col justify-center items-center">
                                <h1 class="text-2xl font-bold">Remise en etat</h1>
                                <br>
                                <p
                                    class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                                    Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                                    vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                                    authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                                </p>
                            </div>

                        </div>
                    </div>

                    <div
                        class="group/item relative w-full xl:w-[49%] h-[35vh] xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2  justify-center items-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                        <div
                            class="absolute top-0 left-0 p-8 w-full h-full flex flex-col justify-center items-center bg-black/50 hover:bg-black/80 gap-y-2">
                            <div class="w-full h-full flex flex-col justify-center items-center">
                                <h1 class="text-2xl font-bold">Desinfection locaux</h1>
                                <br>
                                <p
                                    class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                                    Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                                    vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                                    authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                                </p>
                            </div>

                        </div>
                    </div>

                    <div
                        class="group/item relative w-full xl:w-[49%] h-[35vh]  xl:h-[30vh] 2xl:h-[30vh] flex flex-col gap-y-2 justify-center cursor-pointer p-8 bg-black/50 text-white font-light hover:bg-black/80 duration-200 hover:-translate-x-1.5 hover:-translate-y-1.5  bg-cover bg-bottom bg-[url(https://lh3.googleusercontent.com/pw/AP1GczNFnI0fCYxRrSa2JzDbWy7imWu59zFrOPDnh2vSsckQdDLCVazFb7pBjeT0_KsIHkwDHKE-YFaxr7DqKdF6C8JJTC3O6oGpzBfxrABDWaYOHq8gODppquI71LSe-ibvyadCa8GYJvXt7PKVS-L7DB3XNg=w1080-h717-s-no-gm?authuser=0)]">

                        <div
                            class="absolute top-0 left-0 p-4 w-full h-full bg-black/50 flex flex-col justify-center items-center hover:bg-black/80 gap-y-2">
                            <div class="w-full h-full flex flex-col justify-center items-center">
                                <h1 class="text-2xl font-bold">Entretien de parking</h1>
                                <p
                                    class="hidden group-hover/item:block group-hover/item:opacity-100 group-hover/item:translate-y-0 -translate-y-10 opacity-0 transition-all">
                                    Plume experte en communication politique, ma capacité à comprendre les enjeux derrière
                                    vos besoins rédactionnels me permet de m’ adapter afin de restituer des contenus
                                    authentiques qu’il s ’agisse de discours, d’ouvrage ou de documents techniques.
                                </p>
                            </div>

                        </div>
                    </div>

                </div>
            </div>


        </section>


        <!--- Last articles --->
        <section id="id" class="sticky top-4 w-[30%] flex flex-col justify-end items-start space-y-10 py-10 px-0">

            <div class="flex-1">
                <h1 class="pl-4 xl:pl-0 text-xl font-bold text-black">
                    Recherche
                </h1>
            </div>

            <div class="w-full">
                <form class="flex-1 text-black flex flex-col justify-start gap-y-4">
                    <div class="w-full relative">
                        <input type="email" name="email" placeholder="Saississez votre email"
                            class="p-2 rounded w-full border-slate-300">
                        <button class="p-2 rounded absolute right-[0%] top-[1.5%] text-white bg-google-red/80">
                            <svg class="w-6 h-6 text-white-800 dark:text-white" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                                viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-width="2"
                                    d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"></path>
                            </svg>
                        </button>
                    </div>
                </form>
            </div>

            <div class="flex-1">
                <h1 class="pl-4 xl:pl-6 text-xl font-bold text-black">
                    Last posts
                </h1>
                <ul class="w-full flex flex-col justify-end items-end gap-y-2">
                    @foreach ([0, 1] as $post)
                        <li
                            class="relative flex flex-row w-full xl:w-full 2xl:w-full border-2 flex-shrink-0 border-transparent cursor-pointer rounded-md hover:border-google-red/80 transition-all hover:shadow-black/50 hover:shadow-xl">
                            <div class="w-full">
                                <img src="https://images.squarespace-cdn.com/content/v1/641075275eac4c06e68a4bf7/1694606194980-XV2AXQFIL6GOLU7BBUAH/AdobeStock_549476621+12.png"
                                    class="w-16 h-16 object-cover border-4 border-white float-right">
                                <h1 class="relative font-medium text-sm text-black px-6 py-2">
                                    En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le
                                    modèle de
                                    test équipes.
                                </h1>

                                <div class="flex flex-row justify-between items-center px-6 py-2 text-sm text-gray-500">

                                    <div class="flex flex-row items-center gap-x-2 text-google-red">
                                        <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            fill="currentColor" viewBox="0 0 24 24">
                                            <path
                                                d="M8.597 3.2A1 1 0 0 0 7.04 4.289a3.49 3.49 0 0 1 .057 1.795 3.448 3.448 0 0 1-.84 1.575.999.999 0 0 0-.077.094c-.596.817-3.96 5.6-.941 10.762l.03.049a7.73 7.73 0 0 0 2.917 2.602 7.617 7.617 0 0 0 3.772.829 8.06 8.06 0 0 0 3.986-.975 8.185 8.185 0 0 0 3.04-2.864c1.301-2.2 1.184-4.556.588-6.441-.583-1.848-1.68-3.414-2.607-4.102a1 1 0 0 0-1.594.757c-.067 1.431-.363 2.551-.794 3.431-.222-2.407-1.127-4.196-2.224-5.524-1.147-1.39-2.564-2.3-3.323-2.788a8.487 8.487 0 0 1-.432-.287Z">
                                            </path>
                                        </svg>

                                        1024 lus
                                    </div>

                                    <div class="flex flex-row items-center gap-x-2">
                                        <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            fill="currentColor" viewBox="0 0 24 24">
                                            <path fill-rule="evenodd"
                                                d="M10 5a2 2 0 0 0-2 2v3h2.4A7.48 7.48 0 0 0 8 15.5a7.48 7.48 0 0 0 2.4 5.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1V7a4 4 0 1 1 8 0v1.15a7.446 7.446 0 0 0-1.943.685A.999.999 0 0 1 12 8.5V7a2 2 0 0 0-2-2Z"
                                                clip-rule="evenodd"></path>
                                            <path fill-rule="evenodd"
                                                d="M10 15.5a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm6.5-1.5a1 1 0 1 0-2 0v1.5a1 1 0 0 0 .293.707l1 1a1 1 0 0 0 1.414-1.414l-.707-.707V14Z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                        2 min
                                    </div>

                                </div>
                            </div>


                        </li>
                    @endforeach
                </ul>
            </div>

            <div class="flex-1">
                <h1 class="pl-8 xl:pl-6 text-xl font-bold text-black">
                    Last Comments
                </h1>

                <ul class="w-full flex flex-col justify-end items-end gap-y-2">
                    @foreach ([0, 1] as $post)
                        <li
                            class="relative flex flex-row w-full xl:w-full 2xl:w-full border-2 flex-shrink-0 border-transparent cursor-pointer rounded-md hover:border-google-red/80 transition-all hover:shadow-black/50 hover:shadow-xl">
                            <div class="w-full">

                                <h1 class="relative font-medium text-sm text-black px-6 py-2">
                                    En tant que Directeur d'établissement, tu te dois d'être le chef d'orchestre et le
                                    modèle de
                                    test équipes.
                                </h1>

                                <div class="flex flex-row justify-between items-center px-6 py-2 text-sm text-gray-500">

                                    <div class="flex flex-row items-center gap-x-2 text-google-red">
                                        <svg class="w-6 h-6 dark:text-white" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            fill="currentColor" viewBox="0 0 24 24">
                                            <path
                                                d="M8.597 3.2A1 1 0 0 0 7.04 4.289a3.49 3.49 0 0 1 .057 1.795 3.448 3.448 0 0 1-.84 1.575.999.999 0 0 0-.077.094c-.596.817-3.96 5.6-.941 10.762l.03.049a7.73 7.73 0 0 0 2.917 2.602 7.617 7.617 0 0 0 3.772.829 8.06 8.06 0 0 0 3.986-.975 8.185 8.185 0 0 0 3.04-2.864c1.301-2.2 1.184-4.556.588-6.441-.583-1.848-1.68-3.414-2.607-4.102a1 1 0 0 0-1.594.757c-.067 1.431-.363 2.551-.794 3.431-.222-2.407-1.127-4.196-2.224-5.524-1.147-1.39-2.564-2.3-3.323-2.788a8.487 8.487 0 0 1-.432-.287Z">
                                            </path>
                                        </svg>

                                        1024 lus
                                    </div>

                                </div>
                            </div>


                        </li>
                    @endforeach
                </ul>
            </div>

        </section>

    </div>
@endsection
