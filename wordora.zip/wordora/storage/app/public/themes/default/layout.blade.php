<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @isset($page)
        <title>{{ $page->title }}</title>
    @endisset
    @include('default::scripts.head')
</head>

<body class="font-sans antialiased bg-white">

    @include('default::components.header')

    @if(isset($page))
        @include('default::components.head_page')
    @else
        @yield('page')
    @endif

    @include('default::components.footer')
    @include('default::scripts.footer')
</body>

</html>
