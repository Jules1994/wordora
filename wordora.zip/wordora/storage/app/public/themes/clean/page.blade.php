@extends('clean::layout')

@section('page')

@endsection