<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @isset($page)
        <title>{{ $page->title }}</title>
    @endisset
    @include('clean::scripts.head')
</head>

<body class="font-sans antialiased bg-white">

    @include('clean::components.header')

    @if(isset($page))
        @include('clean::components.head_page')
    @else
        @yield('page')
    @endif

    @include('clean::components.footer')
    @include('clean::scripts.footer')
</body>

</html>
