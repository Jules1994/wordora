const p = {
    "sections": [
        {
            "title": "Section 1",
            "layout": "row",
            "fields": [
                {
                    "type": "input",
                    "name": "username",
                    "label": "Username"
                },
                {
                    "type": "select",
                    "name": "country",
                    "label": "Country",
                    "source": {
                        "type": "url",
                        "url": "https://api.example.com/countries"
                    }
                }
            ]
        },
        {
            "title": "Section 2",
            "layout": "column",
            "fields": [
                {
                    "type": "select",
                    "name": "category",
                    "label": "Category",
                    "source": {
                        "type": "json",
                        "data": [
                            { "label": "Technology", "value": "tech" },
                            { "label": "Science", "value": "science" }
                        ]
                    }
                },
                {
                    "type": "select",
                    "name": "languages",
                    "label": "Languages",
                    "source": {
                        "type": "csv",
                        "file": "/path/to/languages.csv"
                    }
                }
            ]
        }
    ]
}

const u = {
    "sections": [
        {
            "title": "Media Section",
            "layout": "row",
            "fields": [
                {
                    "type": "image",
                    "name": "profilePicture",
                    "label": "Profile Picture"
                },
                {
                    "type": "video",
                    "name": "introductionVideo",
                    "label": "Introduction Video"
                }
            ]
        }
    ]
}

const y = {
    "sections": [
        {
            "title": "Section 1",
            "layout": "row",
            "fields": [
                {
                    "type": "input",
                    "name": "username",
                    "label": "Username"
                },
                {
                    "type": "radio",
                    "name": "gender",
                    "label": "Gender",
                    "options": [
                        { "label": "Male", "value": "male" },
                        { "label": "Female", "value": "female" }
                    ]
                }
            ]
        },
        {
            "title": "Section 2",
            "layout": "column",
            "fields": [
                {
                    "type": "select",
                    "name": "country",
                    "label": "Country",
                    "options": [
                        { "label": "USA", "value": "usa" },
                        { "label": "Canada", "value": "canada" }
                    ]
                },
                {
                    "type": "imagePicker",
                    "name": "profilePicture",
                    "label": "Profile Picture"
                }
            ]
        }
    ]
}


