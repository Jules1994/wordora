import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import path from 'path';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.tsx'],
            refresh: true,
        }),
    ],

    /*resolve: {
        alias: {
          '~': path.resolve(__dirname, 'resources/js'), // Alias "~" vers le dossier "src"
          '~layouts': path.resolve(__dirname, 'resources/js/layouts'),
          '~component': path.resolve(__dirname, 'resources/js/components'),
          '~screens': path.resolve(__dirname, 'resources/js/screen'),
          '~libs': path.resolve(__dirname, 'resources/js/libs'),
          '~contexts': path.resolve(__dirname, 'resources/js/contexts'),
        },
        extensions: ['.ts', '.tsx', '.js', '.jsx'],
      },*/
});
